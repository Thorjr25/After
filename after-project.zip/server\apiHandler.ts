// Server-side HTTP API Route Handler for AFTER

import type { IncomingMessage, ServerResponse } from 'http';
import { llmClient } from './ai/client';
import { afterAnalyzer } from './ai/analyzer';

export async function handleApiRequest(req: IncomingMessage, res: ServerResponse): Promise<boolean> {
  const url = req.url || '';

  // 1. GET /api/status
  if (url === '/api/status' || url.startsWith('/api/status?')) {
    if (req.method !== 'GET') {
      res.writeHead(405, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Method Not Allowed' }));
      return true;
    }

    const info = llmClient.getModelInfo();
    const isConfigured = llmClient.isConfigured();

    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    });
    res.end(JSON.stringify({
      mode: isConfigured ? 'REAL_AI' : 'DEMO',
      configured: isConfigured,
      provider: info.provider,
      model: info.model,
      message: isConfigured
        ? `Real LLM integration active using ${info.provider} (${info.model}).`
        : 'Demo mode active. To activate Real LLM, set AI_API_KEY in .env or configure in System Telemetry.'
    }));
    return true;
  }

  // 2. POST /api/configure
  if (url === '/api/configure') {
    if (req.method !== 'POST') {
      res.writeHead(405, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Method Not Allowed' }));
      return true;
    }

    const bodyStr = await readRequestBody(req);
    try {
      const data = JSON.parse(bodyStr);
      if (data.apiKey !== undefined) {
        llmClient.updateConfig({
          apiKey: data.apiKey,
          provider: data.provider || undefined,
          model: data.model || undefined
        });
      }

      const info = llmClient.getModelInfo();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        configured: llmClient.isConfigured(),
        provider: info.provider,
        model: info.model
      }));
    } catch (e) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Invalid JSON body' }));
    }
    return true;
  }

  // 3. POST /api/analyze
  if (url === '/api/analyze') {
    if (req.method !== 'POST') {
      res.writeHead(405, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Method Not Allowed' }));
      return true;
    }

    const bodyStr = await readRequestBody(req);
    let body: any = {};
    try {
      body = JSON.parse(bodyStr || '{}');
    } catch {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Malformed JSON payload' }));
      return true;
    }

    if (!body.headline || typeof body.headline !== 'string' || !body.headline.trim()) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Missing required field: headline' }));
      return true;
    }

    try {
      const analysis = await afterAnalyzer.analyzeEvent({
        headline: body.headline,
        summary: body.summary,
        source: body.source,
        category: body.category,
        primaryAssetHint: body.primaryAssetHint,
        currentPriceHint: body.currentPriceHint
      });

      if (!analysis.success) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: analysis.error || 'AI ANALYSIS UNAVAILABLE: AFTER could not reach the reasoning model. Market data remains available, but no AI interpretation was generated.',
          mode: 'UNAVAILABLE'
        }));
        return true;
      }

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        data: analysis.result
      }));
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: `AI ANALYSIS UNAVAILABLE: ${msg}. Market data remains available, but no AI interpretation was generated.`
      }));
    }
    return true;
  }

  return false;
}

function readRequestBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();
      if (body.length > 2e6) {
        // Max 2MB limit
        req.destroy();
        reject(new Error('Request entity too large'));
      }
    });
    req.on('end', () => resolve(body));
    req.on('error', (err) => reject(err));
  });
}
