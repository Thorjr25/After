import React from 'react';
import { Play, ShieldCheck, ArrowUpRight, Github } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';

interface AfterFooterProps {
  onOpenDemo: () => void;
  onOpenRunRecords: () => void;
}

export const AfterFooter: React.FC<AfterFooterProps> = ({
  onOpenDemo,
  onOpenRunRecords,
}) => {
  return (
    <footer className="b-brutal-t bg-[#09090B] pt-20 pb-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-16">
        {/* Massive Typographic Statement */}
        <div className="space-y-2">
          <div className="overflow-hidden">
            <h2 className="font-display font-black uppercase text-[clamp(2.4rem,8vw,7.5rem)] leading-[0.9] text-muted-foreground/60 tracking-tighter">
              THE MARKET CLOSES.
            </h2>
          </div>
          <div className="overflow-hidden">
            <h2 className="font-display font-black uppercase text-[clamp(2.4rem,8vw,7.5rem)] leading-[0.9] text-foreground tracking-tighter">
              AFTER KEEPS WATCHING.
            </h2>
          </div>
        </div>

        {/* CTA Banner */}
        <div className="flex flex-wrap items-center gap-4 pt-4">
          <button
            onClick={() => {
              terminalAudio.playClick(1100);
              onOpenDemo();
            }}
            className="flex items-center space-x-3 px-8 py-5 bg-accent text-accent-foreground font-display font-black text-sm sm:text-base tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all active:scale-[0.98]"
          >
            <Play size={18} fill="currentColor" />
            <span>RUN AFTER (DEMO)</span>
          </button>

          <button
            onClick={() => {
              terminalAudio.playClick();
              onOpenRunRecords();
            }}
            className="flex items-center space-x-2 px-8 py-5 b-brutal bg-muted-surface text-foreground font-display font-bold text-sm sm:text-base tracking-wider hover:bg-white hover:text-black hover:border-white transition-all active:scale-[0.98]"
          >
            <ShieldCheck size={18} />
            <span>VIEW RUN RECORDS</span>
            <ArrowUpRight size={18} />
          </button>
        </div>

        {/* Bottom Metadata & Legal Disclaimer */}
        <div className="pt-12 b-brutal-t grid grid-cols-1 md:grid-cols-3 gap-8 text-xs font-mono text-muted-foreground">
          <div>
            <span className="font-display font-black text-lg text-foreground block mb-2">
              AFTER<span className="text-accent">®</span>
            </span>
            <p className="font-sans leading-relaxed text-muted-foreground">
              Autonomous after-hours information pricing terminal. Designed for US equities, index futures, and tokenized-equity markets.
            </p>
          </div>

          <div>
            <span className="text-foreground font-bold uppercase block mb-2">
              System Safeguards
            </span>
            <ul className="space-y-1 font-sans">
              <li>• Non-custodial simulated paper execution</li>
              <li>• 8-point automated pre-trade risk gate</li>
              <li>• Transparent explainability & invalidation triggers</li>
              <li>• Immutable cryptographically audited Run Records</li>
            </ul>
          </div>

          <div>
            <span className="text-foreground font-bold uppercase block mb-2">
              Research & Compliance
            </span>
            <p className="font-sans leading-relaxed text-muted-foreground">
              AFTER is an experimental computational financial intelligence prototype. Simulated metrics and model estimations do not constitute investment advice.
            </p>
            <div className="mt-4 text-[11px] text-accent font-bold">
              © 2026 AFTER INTELLIGENCE AGENTS INC.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
