import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Menu, X, Play, Cpu, Key } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';
import { SystemAiStatus } from '../../services/aiService';

interface AfterNavProps {
  aiStatus: SystemAiStatus;
  onOpenDemo: () => void;
  onOpenStatus: () => void;
  onSelectSection: (sectionId: string) => void;
}

export const AfterNav: React.FC<AfterNavProps> = ({
  aiStatus,
  onOpenDemo,
  onOpenStatus,
  onSelectSection,
}) => {
  const [soundOn, setSoundOn] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [clockStr, setClockStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setClockStr(
        now.toLocaleTimeString('en-US', {
          timeZone: 'America/New_York',
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }) + ' EST'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSoundToggle = () => {
    const newState = terminalAudio.toggleSound();
    setSoundOn(newState);
    if (newState) {
      terminalAudio.playClick(900);
    }
  };

  const navLinks = [
    { label: 'TERMINAL', id: 'terminal' },
    { label: 'OPPORTUNITIES', id: 'opportunities' },
    { label: 'HOW IT WORKS', id: 'how-it-works' },
    { label: 'CATALYSTS', id: 'catalysts' },
    { label: 'RUN RECORDS', id: 'run-records' },
  ];

  const handleNavClick = (id: string) => {
    terminalAudio.playClick();
    onSelectSection(id);
    setMobileMenuOpen(false);
    const elem = document.getElementById(id);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-[#09090B] b-brutal-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => {
              terminalAudio.playClick(1000);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center space-x-2 text-left focus:outline-none focus:ring-2 focus:ring-accent"
          >
            <span className="font-display font-black text-2xl tracking-tighter text-foreground hover:text-accent transition-colors">
              AFTER<span className="text-accent text-sm align-super">®</span>
            </span>
          </button>
          
          <div className="hidden xl:flex items-center px-2 py-0.5 b-brutal text-[11px] font-mono font-bold text-muted-foreground bg-muted-surface">
            <span className="inline-block w-2 h-2 bg-red-500 mr-2 animate-pulse" />
            NYSE/NASDAQ: CLOSED ({clockStr})
          </div>

          {/* AI Mode Pill */}
          <button
            onClick={() => {
              terminalAudio.playClick();
              onOpenStatus();
            }}
            className={`flex items-center px-2 py-0.5 b-brutal text-[10px] font-mono font-black transition-colors ${
              aiStatus.configured
                ? 'bg-accent text-accent-foreground border-accent'
                : 'bg-muted-surface text-amber-300 border-amber-500/50 hover:border-accent'
            }`}
            title="Click to view AI status & configuration"
          >
            <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${aiStatus.configured ? 'bg-black animate-ping' : 'bg-amber-400'}`} />
            <span>{aiStatus.configured ? `REAL AI: ${aiStatus.model}` : 'DEMO MODE'}</span>
          </button>
        </div>

        {/* Center Nav Links - Desktop */}
        <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 font-display text-xs font-bold tracking-wider">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className="px-3 py-1.5 text-muted-foreground hover:text-foreground hover:bg-muted-surface transition-colors focus:outline-none focus:ring-2 focus:ring-accent"
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Right Controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Audio toggle */}
          <button
            onClick={handleSoundToggle}
            title={soundOn ? 'Mute terminal audio' : 'Enable terminal audio'}
            className="p-2 b-brutal bg-muted-surface text-muted-foreground hover:text-accent transition-colors focus:outline-none"
            aria-label="Toggle audio"
          >
            {soundOn ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>

          {/* System status button */}
          <button
            onClick={() => {
              terminalAudio.playClick();
              onOpenStatus();
            }}
            className="hidden sm:flex items-center space-x-1.5 px-2.5 py-1.5 b-brutal bg-muted-surface text-[11px] font-mono font-bold text-muted-foreground hover:text-foreground hover:border-accent transition-all"
          >
            <Cpu size={13} className="text-accent" />
            <span>CONFIG</span>
          </button>

          {/* Primary CTA: Run Agent Demo */}
          <button
            onClick={() => {
              terminalAudio.playClick(1100);
              onOpenDemo();
            }}
            className="flex items-center space-x-1.5 px-3 sm:px-4 py-1.5 bg-accent text-accent-foreground font-display font-black text-xs tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all active:translate-y-0.5"
          >
            <Play size={13} fill="currentColor" />
            <span>RUN AGENT</span>
          </button>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 b-brutal bg-muted-surface text-foreground"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden b-brutal-t bg-[#09090B] px-6 py-6 space-y-4">
          <div className="flex items-center justify-between pb-3 b-brutal-b text-xs font-mono text-muted-foreground">
            <span>NYSE/NASDAQ: CLOSED</span>
            <span className="text-accent">{clockStr}</span>
          </div>
          <div className="p-3 b-brutal bg-muted-surface text-xs font-mono">
            <span className="text-muted-foreground block text-[10px]">AI ENGINE STATUS:</span>
            <span className="font-bold text-foreground block mt-0.5">
              {aiStatus.configured ? `REAL AI (${aiStatus.provider} / ${aiStatus.model})` : 'DEMO MODE (SYNTHETIC DATA)'}
            </span>
          </div>
          <div className="flex flex-col space-y-2 font-display text-lg font-bold">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className="text-left py-2 px-3 hover:bg-muted-surface text-foreground hover:text-accent transition-colors"
              >
                {link.label}
              </button>
            ))}
          </div>
          <div className="pt-4 b-brutal-t flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenStatus();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 b-brutal bg-muted-surface text-xs font-mono font-bold text-center"
            >
              SYSTEM TELEMETRY & API CONFIG
            </button>
            <button
              onClick={() => {
                onOpenDemo();
                setMobileMenuOpen(false);
              }}
              className="w-full py-3 bg-accent text-accent-foreground font-display font-black text-sm text-center b-brutal border-accent"
            >
              RUN AFTER AGENT DEMO
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
