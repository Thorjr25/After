// Multi-Provider Server-Side LLM Client for AFTER

import { AFTER_SYSTEM_PROMPT } from './prompts';
import { StructuredLLMOutput, validateStructuredLLMOutput } from './schemas';

export interface LLMConfig {
  provider: 'gemini' | 'openai' | 'groq' | 'openrouter' | 'anthropic';
  model: string;
  apiKey: string;
  baseUrl?: string;
}

export class LLMClient {
  private config: LLMConfig;

  constructor(customConfig?: Partial<LLMConfig>) {
    const provider = (customConfig?.provider || process.env.AI_PROVIDER || 'gemini').toLowerCase() as LLMConfig['provider'];
    
    // Choose sensible default model based on provider
    let defaultModel = 'gemini-2.5-flash';
    if (provider === 'openai') defaultModel = 'gpt-4o-mini';
    else if (provider === 'groq') defaultModel = 'llama-3.3-70b-versatile';
    else if (provider === 'anthropic') defaultModel = 'claude-3-5-haiku-20241022';
    else if (provider === 'openrouter') defaultModel = 'meta-llama/llama-3.3-70b-instruct';

    this.config = {
      provider,
      model: customConfig?.model || process.env.AI_MODEL || defaultModel,
      apiKey: customConfig?.apiKey || process.env.AI_API_KEY || process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY || '',
      baseUrl: customConfig?.baseUrl || process.env.AI_BASE_URL
    };
  }

  public isConfigured(): boolean {
    return Boolean(this.config.apiKey && this.config.apiKey.trim().length > 0);
  }

  public getModelInfo(): { provider: string; model: string; configured: boolean } {
    return {
      provider: this.config.provider,
      model: this.config.model,
      configured: this.isConfigured()
    };
  }

  public updateConfig(newConfig: Partial<LLMConfig>) {
    this.config = {
      ...this.config,
      ...newConfig
    };
  }

  public async generateStructuredAnalysis(userPrompt: string): Promise<{
    success: boolean;
    data?: StructuredLLMOutput;
    rawText?: string;
    modelName: string;
    provider: string;
    error?: string;
  }> {
    if (!this.isConfigured()) {
      return {
        success: false,
        modelName: this.config.model,
        provider: this.config.provider,
        error: 'AI_API_KEY is not configured on server. Please configure an API key in .env or system status.'
      };
    }

    try {
      let rawResponseText = '';

      if (this.config.provider === 'gemini') {
        rawResponseText = await this.callGemini(userPrompt);
      } else if (this.config.provider === 'anthropic') {
        rawResponseText = await this.callAnthropic(userPrompt);
      } else {
        // OpenAI / Groq / OpenRouter / Custom compatible API
        rawResponseText = await this.callOpenAICompatible(userPrompt);
      }

      // Sanitize JSON text: remove markdown code fences if present
      const cleanJson = this.extractCleanJson(rawResponseText);
      let parsedObj: unknown;
      try {
        parsedObj = JSON.parse(cleanJson);
      } catch (err) {
        return {
          success: false,
          modelName: this.config.model,
          provider: this.config.provider,
          rawText: rawResponseText,
          error: `Model response was not valid JSON: ${(err as Error).message}`
        };
      }

      // Validate against AFTER structured schema
      const validation = validateStructuredLLMOutput(parsedObj);
      if (!validation.valid || !validation.data) {
        return {
          success: false,
          modelName: this.config.model,
          provider: this.config.provider,
          rawText: rawResponseText,
          error: `Output failed validation: ${validation.error}`
        };
      }

      return {
        success: true,
        data: validation.data,
        rawText: rawResponseText,
        modelName: this.config.model,
        provider: this.config.provider
      };
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      return {
        success: false,
        modelName: this.config.model,
        provider: this.config.provider,
        error: `LLM API Error: ${errorMsg}`
      };
    }
  }

  private async callGemini(userPrompt: string): Promise<string> {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${this.config.model}:generateContent?key=${this.config.apiKey}`;
    
    const body = {
      system_instruction: {
        parts: [{ text: AFTER_SYSTEM_PROMPT }]
      },
      contents: [
        {
          role: 'user',
          parts: [{ text: userPrompt }]
        }
      ],
      generationConfig: {
        temperature: 0.2,
        response_mime_type: 'application/json'
      }
    };

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);

    try {
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal
      });

      if (!resp.ok) {
        const errorBody = await resp.text();
        throw new Error(`Google Gemini returned status ${resp.status}: ${errorBody}`);
      }

      const json = await resp.json() as any;
      const candidate = json.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!candidate) {
        throw new Error('No candidate content returned by Gemini');
      }
      return candidate;
    } finally {
      clearTimeout(timeout);
    }
  }

  private async callOpenAICompatible(userPrompt: string): Promise<string> {
    let endpoint = 'https://api.openai.com/v1/chat/completions';
    if (this.config.baseUrl) {
      endpoint = `${this.config.baseUrl.replace(/\/$/, '')}/chat/completions`;
    } else if (this.config.provider === 'groq') {
      endpoint = 'https://api.groq.com/openai/v1/chat/completions';
    } else if (this.config.provider === 'openrouter') {
      endpoint = 'https://openrouter.ai/api/v1/chat/completions';
    }

    const body = {
      model: this.config.model,
      messages: [
        { role: 'system', content: AFTER_SYSTEM_PROMPT },
        { role: 'user', content: userPrompt }
      ],
      temperature: 0.2,
      response_format: { type: 'json_object' }
    };

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);

    try {
      const resp = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`
        },
        body: JSON.stringify(body),
        signal: controller.signal
      });

      if (!resp.ok) {
        const errorBody = await resp.text();
        throw new Error(`${this.config.provider} returned status ${resp.status}: ${errorBody}`);
      }

      const json = await resp.json() as any;
      const text = json.choices?.[0]?.message?.content;
      if (!text) {
        throw new Error(`Empty completion content returned by ${this.config.provider}`);
      }
      return text;
    } finally {
      clearTimeout(timeout);
    }
  }

  private async callAnthropic(userPrompt: string): Promise<string> {
    const endpoint = 'https://api.anthropic.com/v1/messages';

    const body = {
      model: this.config.model,
      max_tokens: 2048,
      system: AFTER_SYSTEM_PROMPT,
      messages: [
        { role: 'user', content: userPrompt }
      ],
      temperature: 0.2
    };

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);

    try {
      const resp = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': this.config.apiKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify(body),
        signal: controller.signal
      });

      if (!resp.ok) {
        const errorBody = await resp.text();
        throw new Error(`Anthropic returned status ${resp.status}: ${errorBody}`);
      }

      const json = await resp.json() as any;
      const text = json.content?.[0]?.text;
      if (!text) {
        throw new Error('Empty message content returned by Anthropic');
      }
      return text;
    } finally {
      clearTimeout(timeout);
    }
  }

  private extractCleanJson(text: string): string {
    let clean = text.trim();
    if (clean.startsWith('```json')) {
      clean = clean.replace(/^```json\s*/, '').replace(/```\s*$/, '');
    } else if (clean.startsWith('```')) {
      clean = clean.replace(/^```\s*/, '').replace(/```\s*$/, '');
    }
    // Find the first { and the last }
    const firstBrace = clean.indexOf('{');
    const lastBrace = clean.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      clean = clean.slice(firstBrace, lastBrace + 1);
    }
    return clean;
  }
}

export const llmClient = new LLMClient();
