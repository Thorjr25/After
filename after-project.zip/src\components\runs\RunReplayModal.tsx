import React, { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, ArrowRight, ArrowLeft, CheckCircle2, ShieldAlert, Zap, Clock } from 'lucide-react';
import { RunRecord } from '../../types/after';
import { terminalAudio } from '../../services/audioService';

interface RunReplayModalProps {
  run: RunRecord | null;
  onClose: () => void;
  onCompareWith?: (run: RunRecord) => void;
}

export const RunReplayModal: React.FC<RunReplayModalProps> = ({
  run,
  onClose,
  onCompareWith,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  useEffect(() => {
    setCurrentStepIndex(0);
    setIsPlaying(false);
  }, [run]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying && run) {
      if (currentStepIndex < run.steps.length - 1) {
        timer = setTimeout(() => {
          terminalAudio.playClick(900 + currentStepIndex * 50);
          setCurrentStepIndex((prev) => prev + 1);
        }, 1400);
      } else {
        setIsPlaying(false);
        terminalAudio.playSignalAlert();
      }
    }
    return () => clearTimeout(timer);
  }, [isPlaying, currentStepIndex, run]);

  if (!run) return null;

  const currentStep = run.steps[currentStepIndex] || run.steps[0];
  const progressPercent = ((currentStepIndex + 1) / run.steps.length) * 100;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85"
      onClick={() => {
        terminalAudio.playClick(600);
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto b-brutal bg-[#09090B] p-6 sm:p-8 text-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-4 b-brutal-b gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-muted-foreground mb-1">
              <span className="text-accent font-bold">RUN ID: #{run.id}</span>
              <span>•</span>
              <span>{run.timeStr}</span>
              <span>•</span>
              <span className="px-2 py-0.5 b-brutal bg-muted-surface text-[10px] text-foreground font-bold uppercase">
                TRIGGER: {run.trigger}
              </span>
            </div>
            <h2 className="font-display font-black text-2xl sm:text-3xl uppercase tracking-tight flex items-center gap-3">
              <span>{run.primaryAsset}</span>
              <span className="text-muted-foreground text-base sm:text-xl font-normal font-sans">
                {run.eventHeadline}
              </span>
            </h2>
          </div>

          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="p-2 b-brutal bg-muted-surface hover:bg-accent hover:text-accent-foreground transition-colors shrink-0"
            aria-label="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Progress Bar & Scrubber Controls */}
        <div className="py-6 b-brutal-b space-y-4">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-muted-foreground uppercase">
              REPLAY PROGRESS: STEP {currentStepIndex + 1} OF {run.steps.length}
            </span>
            <span className="text-accent font-bold">
              PHASE: {currentStep.phase}
            </span>
          </div>

          {/* Scrub Track */}
          <div className="w-full h-3 bg-muted-surface b-brutal relative overflow-hidden">
            <div
              className="h-full bg-accent transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Scrubber Navigation Buttons */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => {
                  terminalAudio.playClick(1000);
                  setIsPlaying(!isPlaying);
                }}
                className="px-4 py-2 bg-accent text-accent-foreground font-display font-black text-xs tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-colors flex items-center space-x-1.5"
              >
                {isPlaying ? <Pause size={14} /> : <Play size={14} fill="currentColor" />}
                <span>{isPlaying ? 'PAUSE' : 'AUTO REPLAY'}</span>
              </button>

              <button
                onClick={() => {
                  terminalAudio.playClick(700);
                  setCurrentStepIndex(0);
                  setIsPlaying(false);
                }}
                className="p-2 b-brutal bg-muted-surface text-muted-foreground hover:text-foreground transition-colors"
                title="Reset to start"
              >
                <RotateCcw size={14} />
              </button>
            </div>

            <div className="flex items-center space-x-2">
              <button
                disabled={currentStepIndex === 0}
                onClick={() => {
                  terminalAudio.playClick(750);
                  setCurrentStepIndex((prev) => Math.max(0, prev - 1));
                  setIsPlaying(false);
                }}
                className="px-3 py-1.5 b-brutal bg-muted-surface text-xs font-mono font-bold disabled:opacity-30 disabled:cursor-not-allowed hover:text-foreground"
              >
                <ArrowLeft size={14} className="inline mr-1" /> PREV
              </button>

              <button
                disabled={currentStepIndex === run.steps.length - 1}
                onClick={() => {
                  terminalAudio.playClick(850);
                  setCurrentStepIndex((prev) => Math.min(run.steps.length - 1, prev + 1));
                  setIsPlaying(false);
                }}
                className="px-3 py-1.5 b-brutal bg-muted-surface text-xs font-mono font-bold disabled:opacity-30 disabled:cursor-not-allowed hover:text-foreground"
              >
                NEXT <ArrowRight size={14} className="inline ml-1" />
              </button>
            </div>
          </div>
        </div>

        {/* Current Active Replay Step Highlight Box */}
        <div className="py-6 b-brutal-b">
          <div className="p-6 b-brutal bg-muted-surface/30 border-accent">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 b-brutal-b">
              <div className="flex items-center space-x-3">
                <span className="p-2 b-brutal bg-accent text-accent-foreground font-mono font-bold text-xs">
                  {currentStep.timeStr}
                </span>
                <h3 className="font-display font-black text-xl sm:text-2xl text-foreground uppercase tracking-tight">
                  {currentStep.title}
                </h3>
              </div>

              {currentStep.metricHighlight && (
                <span className="px-3 py-1 b-brutal bg-black text-accent font-mono font-bold text-xs tracking-wider">
                  {currentStep.metricHighlight}
                </span>
              )}
            </div>

            <p className="pt-4 text-sm sm:text-base text-foreground font-sans leading-relaxed">
              {currentStep.detail}
            </p>
          </div>
        </div>

        {/* Full 10-Step Timeline Scroller (Clickable) */}
        <div className="py-6 b-brutal-b">
          <span className="text-xs font-mono text-muted-foreground uppercase block mb-3 font-bold">
            FULL EXECUTION LIFECYCLE CHRONOLOGY:
          </span>
          <div className="space-y-2">
            {run.steps.map((st, idx) => {
              const isSelected = idx === currentStepIndex;
              const isPast = idx < currentStepIndex;

              return (
                <div
                  key={st.stepIndex}
                  onClick={() => {
                    terminalAudio.playClick(800 + idx * 40);
                    setCurrentStepIndex(idx);
                    setIsPlaying(false);
                  }}
                  className={`p-3 b-brutal font-mono text-xs cursor-pointer transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-accent text-accent-foreground border-accent font-black'
                      : isPast
                      ? 'bg-muted-surface/20 text-muted-foreground hover:text-foreground'
                      : 'bg-transparent text-zinc-600 hover:text-foreground'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="font-bold">{st.timeStr}</span>
                    <span>{st.title}</span>
                  </div>
                  <span className="text-[10px] uppercase font-bold">{st.phase}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Post-Event Market Outcome (When Available) */}
        {run.outcome && (
          <div className="py-6 b-brutal-b">
            <span className="text-xs font-mono text-accent font-bold uppercase block mb-2">
              WHAT THE MARKET DID AFTERWARD (VALIDATION OUTCOME):
            </span>
            <div className="p-4 b-brutal bg-muted-surface grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase">Post-Event Move</span>
                <span className={`font-display font-black text-2xl block mt-0.5 ${
                  run.outcome.postEventMove >= 0 ? 'text-accent' : 'text-red-400'
                }`}>
                  {run.outcome.postEventMove >= 0 ? `+${run.outcome.postEventMove}%` : `${run.outcome.postEventMove}%`}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase">Model Accuracy</span>
                <span className="font-display font-black text-2xl text-foreground block mt-0.5">
                  {run.outcome.accuracy}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase">Verification Notes</span>
                <span className="text-xs text-muted-foreground block mt-0.5 font-sans">
                  {run.outcome.notes}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="pt-6 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="px-5 py-2.5 b-brutal bg-muted-surface text-xs font-mono font-bold hover:text-foreground"
          >
            CLOSE REPLAY
          </button>

          {onCompareWith && (
            <button
              onClick={() => {
                terminalAudio.playClick(1000);
                onCompareWith(run);
              }}
              className="px-5 py-2.5 b-brutal bg-white text-black font-display font-bold text-xs tracking-wider hover:bg-accent transition-colors"
            >
              COMPARE WITH ANOTHER RUN
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
