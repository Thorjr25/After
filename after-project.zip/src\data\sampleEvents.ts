import { AfterEvent, Opportunity } from '../types/after';

export const SAMPLE_EVENTS: AfterEvent[] = [
  {
    id: 'evt-001',
    timestamp: Date.now() - 1000 * 60 * 18,
    timeStr: '18:32:04 EST',
    asset: 'AAPL',
    assetName: 'Apple Inc.',
    category: 'EARNINGS',
    headline: 'Q4 Services Revenue Beats by 14.2%; Greater China iPhone Gross Margin Expands 210 bps',
    fullSummary: 'Apple posted record after-hours fiscal Q4 results with gross revenue of $94.9B vs $89.4B estimated. High-margin Services surged to $24.97B (+14.2% beat), driving consolidated gross margin to 46.2%. Greater China channel inventories normalized faster than Street model.',
    impact: 91,
    surprise: 82,
    relevance: 96,
    confidence: 88,
    status: 'DISLOCATED',
    whyMatters: 'Services margin expansion provides structural valuation re-rating. While primary US markets are closed, Nasdaq 100 futures and technology proxies have rallied, but tokenized and after-hours equity books are lagging by 310 bps.',
    sources: ['SEC 8-K Filing (18:31:02)', 'Apple IR Wire', 'Bloomberg Terminal Feed'],
    sector: 'Technology / Consumer Hardware',
    relatedAssets: ['QQQ', 'XLK', 'TSM', 'QCOM', 'ARM'],
    indexExposure: ['Nasdaq 100 (9.1%)', 'S&P 500 (7.2%)'],
    tokenizedExposure: 'AAPL-USD 24/7 Perpetual (Hyperliquid / dYdX)',
    expectedReaction: {
      direction: 'POSITIVE',
      expectedMove: 4.1,
      expectedMoveRange: [3.8, 4.6],
      confidence: 88,
      rationale: 'Earnings exceeded expectations, strengthening the fundamental narrative. Related technology instruments are already reacting positively, increasing the probability of a positive reopening reaction.',
      references: [
        { symbol: 'NQ1! (Nasdaq Futures)', name: 'E-mini Nasdaq 100', type: 'FUTURES', movePercent: 1.1, description: 'Broad tech index overnight rally confirming sentiment' },
        { symbol: 'XLK', name: 'Technology Select Sector', type: 'ETF', movePercent: 0.8, description: 'Large-cap sector ETF pricing basket repricing' },
        { symbol: 'TSM.US', name: 'Taiwan Semi ADR', type: 'SECTOR', movePercent: 1.4, description: 'Core foundry supplier up on robust wafer demand' },
        { symbol: 'AAPL-PERP', name: 'Tokenized Apple Equity', type: 'TOKENIZED', movePercent: 0.2, description: 'Off-exchange 24/7 book lagging primary move' }
      ],
      dislocation: {
        level: 'HIGH',
        minPercent: 0.6,
        maxPercent: 0.9,
        summary: 'Primary tech proxies up +0.8% to +1.4%, while tokenized AAPL equity remains pinned at +0.2%. Implied fair value gap of ~330 bps.'
      }
    }
  },
  {
    id: 'evt-002',
    timestamp: Date.now() - 1000 * 60 * 42,
    timeStr: '18:08:19 EST',
    asset: 'NVDA',
    assetName: 'NVIDIA Corporation',
    category: 'CORPORATE',
    headline: 'Hyperscaler Custom Silicon Delayed to 2027; Blackwell Production Yield Exceeds 92%',
    fullSummary: 'Supply chain audit from major Taiwanese packaging facility confirms Blackwell Ultra B200 rack yields have hit 92% ahead of schedule, while competitor custom ASIC programs face 14-month packaging bottlenecks.',
    impact: 86,
    surprise: 74,
    relevance: 94,
    confidence: 84,
    status: 'ANALYZED',
    whyMatters: 'Removes immediate competitive overhang from cloud internal ASIC substitution. Reinforces dominant pricing power across FY26 enterprise AI infrastructure capex cycles.',
    sources: ['TrendForce Supply Intelligence', 'DigiTimes Asia (Overnight Edition)'],
    sector: 'Semiconductors',
    relatedAssets: ['SMH', 'SOXX', 'AMD', 'AVGO', 'MSFT'],
    indexExposure: ['Nasdaq 100 (8.4%)', 'S&P 500 (6.8%)'],
    tokenizedExposure: 'NVDA-PERP (Drift / Binance TradFi)',
    expectedReaction: {
      direction: 'POSITIVE',
      expectedMove: 3.4,
      expectedMoveRange: [2.8, 3.9],
      confidence: 84,
      rationale: 'Overnight foundry data eliminates execution delay fears. Asian semiconductor suppliers in Taipei already bidding up +2.1%.',
      references: [
        { symbol: 'SOXX.F', name: 'Semiconductor Index Proxy', type: 'ETF', movePercent: 1.6, description: 'Semiconductor ETF overnight pricing' },
        { symbol: 'TSMC (2330.TW)', name: 'TSMC Taipei Regular', type: 'SECTOR', movePercent: 2.1, description: 'Lead packaging partner trading live in Asia session' },
        { symbol: 'NVDA-PERP', name: 'Tokenized NVDA', type: 'TOKENIZED', movePercent: 1.1, description: 'Partial repricing underway but still trailing spot fair value' }
      ],
      dislocation: {
        level: 'MEDIUM',
        minPercent: 0.4,
        maxPercent: 0.7,
        summary: 'Asian supply chain proxies imply +2.1% minimum reopening impulse; US after-hours indicative print shows only +1.1%.'
      }
    }
  },
  {
    id: 'evt-003',
    timestamp: Date.now() - 1000 * 60 * 75,
    timeStr: '17:35:50 EST',
    asset: 'TSLA',
    assetName: 'Tesla, Inc.',
    category: 'ANALYST',
    headline: 'Tier-1 Brokerage Cuts Q1 Delivery Target by 19% Citing EU Subsidies Phase-Out',
    fullSummary: 'Goldman automotive research team issued an unscheduled overnight downgrade to Sell, trimming global vehicle deliveries from 445k to 360k units. Operating margins modeled at 6.1% vs 8.4% consensus.',
    impact: 79,
    surprise: 68,
    relevance: 89,
    confidence: 76,
    status: 'DISLOCATED',
    whyMatters: 'Delivery forecast cut directly undermines the volume acceleration thesis. European automotive peers are already down -1.8% in early Frankfurt pre-market.',
    sources: ['Institutional Equity Research Note', 'FirstCall Consensus Update'],
    sector: 'Automotive / Clean Tech',
    relatedAssets: ['XLY', 'RIVN', 'LCID', 'BYD'],
    indexExposure: ['Nasdaq 100 (3.8%)', 'S&P 500 (1.9%)'],
    tokenizedExposure: 'TSLA Synthetic 24/7',
    expectedReaction: {
      direction: 'NEGATIVE',
      expectedMove: -3.8,
      expectedMoveRange: [-4.5, -3.1],
      confidence: 76,
      rationale: 'Institutional downgrades with hard delivery downward revisions trigger automated liquidation at 09:30 cash open. European auto proxies confirm drag.',
      references: [
        { symbol: 'XLY', name: 'Consumer Discretionary ETF', type: 'ETF', movePercent: -0.6, description: 'Sector proxy showing mild weakness' },
        { symbol: 'DAX Autos (VOW3.DE)', name: 'European EV Basket', type: 'SECTOR', movePercent: -1.8, description: 'German autos selling off in Frankfurt pre-session' },
        { symbol: 'TSLA-PERP', name: 'Tokenized TSLA', type: 'TOKENIZED', movePercent: -0.9, description: 'Offshore token contract only down -0.9%, underpricing revision' }
      ],
      dislocation: {
        level: 'MEDIUM',
        minPercent: 0.5,
        maxPercent: 0.8,
        summary: 'Offshore synthetic markets are pricing a modest -0.9% drift, whereas European sector peers and institutional flow modeling anticipate a -3.8% re-rate.'
      }
    }
  },
  {
    id: 'evt-004',
    timestamp: Date.now() - 1000 * 60 * 110,
    timeStr: '17:00:12 EST',
    asset: 'MSFT',
    assetName: 'Microsoft Corporation',
    category: 'SEC',
    headline: 'Form 8-K Details $12B Additional Sovereign Cloud Infrastructure Commitments in Gulf Region',
    fullSummary: 'Microsoft entered into a binding 10-year sovereign cloud infrastructure expansion with UAE and Saudi investment authorities, guaranteeing minimum datacenter capacity off-take at fixed enterprise margins.',
    impact: 74,
    surprise: 62,
    relevance: 85,
    confidence: 82,
    status: 'PRICED_IN',
    whyMatters: 'Validates sovereign AI compute demand outside OECD economies. Highly accretive to Azure enterprise ARR with zero capital dilution.',
    sources: ['SEC EDGAR 8-K', 'US-UAE Bilateral Tech Accord Registry'],
    sector: 'Cloud & Enterprise Software',
    relatedAssets: ['IGV', 'ORCL', 'AMZN', 'GOOGL'],
    indexExposure: ['Nasdaq 100 (8.8%)', 'S&P 500 (6.9%)'],
    expectedReaction: {
      direction: 'POSITIVE',
      expectedMove: 1.5,
      expectedMoveRange: [1.2, 1.8],
      confidence: 82,
      rationale: 'Sovereign contracts offer long-term margin stability, but capital deployment will occur over 36 months, mitigating immediate cash flow surprise.',
      references: [
        { symbol: 'IGV', name: 'Software ETF', type: 'ETF', movePercent: 0.5, description: 'Enterprise software ETF stable overnight' },
        { symbol: 'ORCL', name: 'Oracle ADR', type: 'SECTOR', movePercent: 0.7, description: 'Co-cloud infrastructure partner' }
      ],
      dislocation: {
        level: 'LOW',
        minPercent: 0.1,
        maxPercent: 0.2,
        summary: 'Information is mostly priced in across extended hours matching observed peer multiples.'
      }
    }
  },
  {
    id: 'evt-005',
    timestamp: Date.now() - 1000 * 60 * 155,
    timeStr: '16:15:30 EST',
    asset: 'SPY',
    assetName: 'Macro / Fed Policy',
    category: 'MACRO',
    headline: 'Overnight Basel III Final Endgame Rules Ease Capital Surcharges for G-SIBs by $115B',
    fullSummary: 'Federal Reserve Vice Chair for Supervision announced calibrated revisions to US Basel III endgame proposals. CET1 tier-1 capital buffer requirements for top 8 US banks reduced by ~550 bps from initial 2023 draft.',
    impact: 88,
    surprise: 79,
    relevance: 95,
    confidence: 89,
    status: 'ANALYZED',
    whyMatters: 'Unlocks immediate share buyback authorization capacity and dividends for JPM, BAC, MS, GS while expanding liquidity available to repo markets.',
    sources: ['Federal Reserve Board Press Release', 'FDIC Interagency Docket'],
    sector: 'Financials / Macro Liquidity',
    relatedAssets: ['XLF', 'KBE', 'JPM', 'GS', 'BAC'],
    indexExposure: ['S&P 500 (13.4%)'],
    expectedReaction: {
      direction: 'POSITIVE',
      expectedMove: 2.6,
      expectedMoveRange: [2.2, 3.1],
      confidence: 89,
      rationale: 'Substantial capital relief frees immediate equity return mechanisms. Eurodollar and SOFR futures showing liquidity repricing.',
      references: [
        { symbol: 'XLF', name: 'Financial Select SPDR', type: 'ETF', movePercent: 1.2, description: 'Financials ETF indicative overnight pricing' },
        { symbol: 'JPM.N', name: 'JPMorgan Chase Post-Mkt', type: 'SECTOR', movePercent: 1.8, description: 'Lead global systemically important bank' }
      ],
      dislocation: {
        level: 'MEDIUM',
        minPercent: 0.3,
        maxPercent: 0.6,
        summary: 'S&P 500 futures have not yet factored in the +75 bps index earnings contribution from expanded buybacks.'
      }
    }
  }
];

export const SAMPLE_OPPORTUNITIES: Opportunity[] = [
  {
    id: 'opp-001',
    rank: 1,
    symbol: 'AAPL',
    name: 'Apple Inc.',
    opportunityScore: 93,
    expectedMove: 4.1,
    currentImpliedMove: 0.8,
    confidence: 88,
    informationStrength: 91,
    riskLevel: 'MEDIUM',
    dislocationRange: '+0.6% to +0.9%',
    whyTrade: 'Earnings exceeded expectations by 14.2% on record Services margins. Technology proxies (NQ futures +1.1%, XLK +0.8%, TSM +1.4%) are already repricing upward, while tokenized and offshore equity exposure remains comparatively unchanged at +0.2%. AFTER estimates that the information has not been fully reflected.',
    invalidationTriggers: [
      'Unexpected negative revision in subsequent CFO earnings call commentary',
      'Reversal in E-mini Nasdaq 100 futures below prior session VWAP (20,120)',
      'Severe illiquidity spike widening after-hours bid-ask spread beyond 45 bps',
      'Sudden macro dollar index (DXY) spike > +0.7%'
    ],
    eventId: 'evt-001',
    primaryAction: 'LONG',
    currentPrice: 228.40
  },
  {
    id: 'opp-002',
    rank: 2,
    symbol: 'NVDA',
    name: 'NVIDIA Corporation',
    opportunityScore: 78,
    expectedMove: 3.4,
    currentImpliedMove: 1.1,
    confidence: 84,
    informationStrength: 86,
    riskLevel: 'MEDIUM',
    dislocationRange: '+0.4% to +0.7%',
    whyTrade: 'Foundry packaging yield data removes competitive threat from hyperscaler custom ASIC projects. Asian supply chain proxies (TSMC Taipei +2.1%) confirm institutional follow-through that US retail after-hours order book has not caught up to.',
    invalidationTriggers: [
      'Conflicting Taiwanese commercial press retraction before 04:00 EST',
      'Broader semiconductor supply-chain export control rhetoric from US Commerce',
      'Option dealer gamma pinning at $145 strike'
    ],
    eventId: 'evt-002',
    primaryAction: 'LONG',
    currentPrice: 142.15
  },
  {
    id: 'opp-003',
    rank: 3,
    symbol: 'TSLA',
    name: 'Tesla, Inc.',
    opportunityScore: 74,
    expectedMove: -3.8,
    currentImpliedMove: -0.9,
    confidence: 76,
    informationStrength: 79,
    riskLevel: 'HIGH',
    dislocationRange: '-0.5% to -0.8%',
    whyTrade: 'Tier-1 automotive delivery downgrade directly undermines delivery volume guidance. European automotive peers are down -1.8% in Frankfurt pre-market, yet offshore tokenized TSLA is only discounting -0.9%.',
    invalidationTriggers: [
      'CEO social media post announcing accelerated Full Self-Driving rollout in China',
      'Short squeeze in heavily shorted EV supplier basket',
      'Wider market risk-on impulse overpowering single-stock fundamental downgrade'
    ],
    eventId: 'evt-003',
    primaryAction: 'SHORT',
    currentPrice: 216.50
  }
];
