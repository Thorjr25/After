import React, { useState } from 'react';
import { X, CheckCircle2, RotateCcw, Activity, ShieldCheck, Database, Zap, Cpu, Key, AlertCircle } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';
import { aiService, SystemAiStatus } from '../../services/aiService';

interface SystemStatusModalProps {
  onClose: () => void;
  onResetData: () => void;
}

export const SystemStatusModal: React.FC<SystemStatusModalProps> = ({
  onClose,
  onResetData,
}) => {
  const [aiStatus, setAiStatus] = useState<SystemAiStatus>(aiService.getStatus());
  const [activeTab, setActiveTab] = useState<'TELEMETRY' | 'CONFIG'>('TELEMETRY');

  // Config Form
  const [provider, setProvider] = useState<string>(aiStatus.provider || 'gemini');
  const [model, setModel] = useState<string>(aiStatus.model || 'gemini-2.5-flash');
  const [apiKey, setApiKey] = useState<string>('');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!apiKey.trim()) return;
    setIsSaving(true);
    setSaveStatus(null);
    terminalAudio.playClick(1000);

    const res = await aiService.configureAi({
      apiKey: apiKey.trim(),
      provider,
      model: model.trim()
    });

    setIsSaving(false);
    if (res.success) {
      terminalAudio.playSignalAlert();
      setSaveStatus('API KEY CONFIGURED SUCCESSFULLY. REAL AI MODE ACTIVE.');
      setAiStatus(aiService.getStatus());
    } else {
      terminalAudio.playRiskBlocked();
      setSaveStatus(`CONFIGURATION FAILED: ${res.error}`);
    }
  };

  const subsystems = [
    {
      name: 'EVENT INGESTION ENGINE',
      status: 'ONLINE',
      latency: '210ms',
      detail: 'SEC EDGAR Crawler, Bloomberg Wire, PR Newswire, & Social Signals',
      icon: <Zap size={16} className="text-accent" />
    },
    {
      name: 'CROSS-ASSET MARKET DATA',
      status: 'ONLINE',
      latency: '14ms',
      detail: 'CME E-mini Futures, Extended ECNs (Arca, INET), Hyperliquid & dYdX 24/7 Perps',
      icon: <Activity size={16} className="text-accent" />
    },
    {
      name: 'LLM REASONING CORE',
      status: aiStatus.configured ? 'REAL AI ACTIVE' : 'DEMO MODE',
      latency: aiStatus.configured ? '480ms' : '0ms (Synthetic)',
      detail: aiStatus.configured
        ? `Connected to ${aiStatus.provider.toUpperCase()} (${aiStatus.model}). Generating structured after-hours intelligence.`
        : 'API key not yet set. Serving deterministic synthetic baseline data.',
      icon: <Cpu size={16} className="text-accent" />
    },
    {
      name: 'ZERO-TRUST RISK GATE',
      status: 'ONLINE',
      latency: '<1ms',
      detail: '8 automated pre-trade safety policies enforced on all proposals',
      icon: <ShieldCheck size={16} className="text-accent" />
    },
    {
      name: 'PERMANENT AUDIT LEDGER',
      status: 'ONLINE',
      latency: '12ms',
      detail: 'Cryptographically hashed sequential Run Records stored in persistent state',
      icon: <Database size={16} className="text-accent" />
    },
    {
      name: 'EXECUTION GATEWAY',
      status: 'PAPER MODE',
      latency: '35ms',
      detail: 'Strict non-custodial paper trading simulation environment active',
      icon: <CheckCircle2 size={16} className="text-accent" />
    }
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85"
      onClick={() => {
        terminalAudio.playClick(600);
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto b-brutal bg-[#09090B] p-6 sm:p-8 text-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-start justify-between pb-4 b-brutal-b gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <span className={`w-2 h-2 ${aiStatus.configured ? 'bg-accent' : 'bg-amber-400'} inline-block`} />
              <span>SYSTEM DIAGNOSTICS & TELEMETRY</span>
              <span>/</span>
              <span className="text-accent font-bold">
                {aiStatus.configured ? `REAL AI (${aiStatus.model})` : 'DEMO MODE'}
              </span>
            </div>
            <h2 className="font-display font-black text-2xl sm:text-3xl uppercase tracking-tight">
              SYSTEM STATUS & AI CONFIG
            </h2>
          </div>

          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="p-2 b-brutal bg-muted-surface hover:bg-accent hover:text-accent-foreground transition-colors shrink-0"
            aria-label="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Toggle */}
        <div className="flex items-center space-x-2 pt-4 pb-2 border-b border-[#3F3F46] text-xs font-mono">
          <button
            onClick={() => {
              terminalAudio.playClick();
              setActiveTab('TELEMETRY');
            }}
            className={`px-4 py-2 b-brutal font-bold uppercase transition-colors ${
              activeTab === 'TELEMETRY'
                ? 'bg-accent text-accent-foreground border-accent'
                : 'bg-muted-surface text-muted-foreground hover:text-foreground'
            }`}
          >
            SUBSYSTEM TELEMETRY
          </button>
          <button
            onClick={() => {
              terminalAudio.playClick();
              setActiveTab('CONFIG');
            }}
            className={`px-4 py-2 b-brutal font-bold uppercase transition-colors flex items-center space-x-1.5 ${
              activeTab === 'CONFIG'
                ? 'bg-accent text-accent-foreground border-accent'
                : 'bg-muted-surface text-muted-foreground hover:text-foreground'
            }`}
          >
            <Key size={13} />
            <span>LLM PROVIDER CONFIGURATION</span>
          </button>
        </div>

        {activeTab === 'TELEMETRY' ? (
          /* Subsystems List */
          <div className="py-6 b-brutal-b space-y-3 font-mono text-xs">
            {subsystems.map((sub, idx) => (
              <div
                key={idx}
                className="p-4 b-brutal bg-muted-surface/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-start space-x-3">
                  <div className="mt-0.5">{sub.icon}</div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-foreground">{sub.name}</span>
                      <span className="text-muted-foreground text-[10px]">({sub.latency})</span>
                    </div>
                    <p className="text-muted-foreground text-[11px] font-sans mt-0.5">
                      {sub.detail}
                    </p>
                  </div>
                </div>

                <div className={`p-1.5 b-brutal font-black text-[11px] text-center shrink-0 min-w-[110px] ${
                  sub.status.includes('REAL AI') || sub.status === 'ONLINE'
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-muted-surface text-amber-300'
                }`}>
                  {sub.status}
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Real LLM Provider Configuration Form */
          <div className="py-6 b-brutal-b space-y-5">
            <div className="p-4 b-brutal bg-muted-surface text-xs font-mono space-y-1">
              <span className="font-bold text-foreground block">SERVER-SIDE API KEY INTEGRATION</span>
              <p className="text-muted-foreground font-sans">
                Keys configured here are sent over HTTPS to the local server process and used strictly server-side. 
                They are never logged, never stored in client bundles, and never exposed in the browser.
                Alternatively, you can set <code className="text-accent font-mono">AI_API_KEY</code> in your <code className="text-accent font-mono">.env</code> file.
              </p>
            </div>

            <form onSubmit={handleSaveConfig} className="space-y-4 font-mono text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-muted-foreground uppercase block mb-1 font-bold">
                    SELECT PROVIDER:
                  </label>
                  <select
                    value={provider}
                    onChange={(e) => {
                      const p = e.target.value;
                      setProvider(p);
                      if (p === 'gemini') setModel('gemini-2.5-flash');
                      else if (p === 'openai') setModel('gpt-4o-mini');
                      else if (p === 'groq') setModel('llama-3.3-70b-versatile');
                      else if (p === 'anthropic') setModel('claude-3-5-haiku-20241022');
                      else if (p === 'openrouter') setModel('meta-llama/llama-3.3-70b-instruct');
                    }}
                    className="w-full p-2.5 b-brutal bg-muted-surface text-foreground font-bold focus:outline-none focus:border-accent"
                  >
                    <option value="gemini">Google Gemini (Recommended)</option>
                    <option value="openai">OpenAI (GPT-4o / GPT-4o-mini)</option>
                    <option value="groq">Groq Cloud (Fast Llama 3.3)</option>
                    <option value="anthropic">Anthropic (Claude 3.5)</option>
                    <option value="openrouter">OpenRouter (Universal)</option>
                  </select>
                </div>

                <div>
                  <label className="text-muted-foreground uppercase block mb-1 font-bold">
                    MODEL NAME:
                  </label>
                  <input
                    type="text"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="e.g. gemini-2.5-flash"
                    className="w-full p-2.5 b-brutal bg-muted-surface text-foreground font-bold focus:outline-none focus:border-accent"
                  />
                </div>
              </div>

              <div>
                <label className="text-muted-foreground uppercase block mb-1 font-bold">
                  API KEY (SERVER-SIDE ONLY):
                </label>
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder={aiStatus.configured ? '•••••••••••••••••••••••• (Configured on server)' : 'Paste your API key here...'}
                  className="w-full p-2.5 b-brutal bg-muted-surface text-foreground font-mono focus:outline-none focus:border-accent"
                />
              </div>

              {saveStatus && (
                <div className={`p-3 b-brutal text-xs font-mono ${
                  saveStatus.includes('SUCCESSFULLY') ? 'bg-accent/20 border-accent text-accent' : 'bg-red-950/40 border-red-500 text-red-300'
                }`}>
                  {saveStatus}
                </div>
              )}

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={isSaving || !apiKey.trim()}
                  className="flex items-center space-x-2 px-6 py-2.5 bg-accent text-accent-foreground font-display font-black text-xs tracking-wider b-brutal border-accent hover:bg-white hover:text-black disabled:opacity-40"
                >
                  <Key size={14} />
                  <span>{isSaving ? 'VALIDATING...' : 'ACTIVATE REAL AI ENGINE'}</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Reset / Actions */}
        <div className="pt-6 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => {
              terminalAudio.playClick(700);
              onResetData();
            }}
            className="flex items-center space-x-2 px-4 py-2 b-brutal bg-muted-surface text-xs font-mono font-bold text-muted-foreground hover:text-foreground hover:border-red-400 transition-colors"
          >
            <RotateCcw size={13} />
            <span>RESET TO SYNTHETIC DEFAULTS</span>
          </button>

          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="px-6 py-2.5 bg-accent text-accent-foreground font-display font-bold text-xs tracking-wider b-brutal border-accent hover:bg-white hover:text-black"
          >
            CLOSE DIAGNOSTICS
          </button>
        </div>
      </div>
    </div>
  );
};
