import React, { useState, useEffect } from 'react';
import { AfterNav } from './components/navigation/AfterNav';
import { AfterHero } from './components/hero/AfterHero';
import { KineticMarquee } from './components/hero/KineticMarquee';
import { LiveTerminal } from './components/terminal/LiveTerminal';
import { EventDetailModal } from './components/terminal/EventDetailModal';
import { LiveAiAnalyzerModal } from './components/terminal/LiveAiAnalyzerModal';
import { OpportunityRadar } from './components/radar/OpportunityRadar';
import { WhyThisTradeModal } from './components/radar/WhyThisTradeModal';
import { StickyStorySection } from './components/storytelling/StickyStorySection';
import { CatalystCalendar } from './components/catalysts/CatalystCalendar';
import { RiskGateModal } from './components/execution/RiskGateModal';
import { PaperExecutionModal } from './components/execution/PaperExecutionModal';
import { RunRecordsList } from './components/runs/RunRecordsList';
import { RunReplayModal } from './components/runs/RunReplayModal';
import { RunComparisonModal } from './components/runs/RunComparisonModal';
import { LiveAgentDemoModal } from './components/demo/LiveAgentDemoModal';
import { SystemStatusModal } from './components/status/SystemStatusModal';
import { AfterFooter } from './components/footer/AfterFooter';

import { runStore } from './services/runStore';
import { aiService, SystemAiStatus, AnalyzeEventPayload } from './services/aiService';
import { AfterEvent, Opportunity, RunRecord } from './types/after';

export const App: React.FC = () => {
  // Store reactive state
  const [events, setEvents] = useState<AfterEvent[]>(runStore.getEvents());
  const [opportunities, setOpportunities] = useState<Opportunity[]>(runStore.getOpportunities());
  const [catalysts, setCatalysts] = useState(runStore.getCatalysts());
  const [runRecords, setRunRecords] = useState<RunRecord[]>(runStore.getRunRecords());
  const [aiStatus, setAiStatus] = useState<SystemAiStatus>(aiService.getStatus());

  // Modal dialog states
  const [selectedEvent, setSelectedEvent] = useState<AfterEvent | null>(null);
  const [selectedWhyTradeOpp, setSelectedWhyTradeOpp] = useState<Opportunity | null>(null);
  const [riskGateTarget, setRiskGateTarget] = useState<Opportunity | AfterEvent | null>(null);
  const [executionTarget, setExecutionTarget] = useState<Opportunity | AfterEvent | null>(null);
  const [replayRun, setReplayRun] = useState<RunRecord | null>(null);
  const [comparisonInitialRun, setComparisonInitialRun] = useState<RunRecord | null>(null);
  const [isComparing, setIsComparing] = useState<boolean>(false);
  const [isDemoOpen, setIsDemoOpen] = useState<boolean>(false);
  const [isStatusOpen, setIsStatusOpen] = useState<boolean>(false);

  // Live AI analysis payload
  const [liveAiPayload, setLiveAiPayload] = useState<AnalyzeEventPayload | null>(null);

  // Subscribe to persistent store updates and AI status
  useEffect(() => {
    const unsubStore = runStore.subscribe(() => {
      setEvents(runStore.getEvents());
      setOpportunities(runStore.getOpportunities());
      setCatalysts(runStore.getCatalysts());
      setRunRecords(runStore.getRunRecords());
    });

    const unsubAi = aiService.subscribe((st) => {
      setAiStatus(st);
    });

    return () => {
      unsubStore();
      unsubAi();
    };
  }, []);

  // Marquee 1: High-Speed Market Intelligence Ticker
  const marqueeFastItems = [
    { label: 'NQ1! NASDAQ FUTURES', value: '+1.1%', type: 'CME', highlight: true },
    { label: 'XLK TECH SELECT', value: '+0.8%', type: 'ETF' },
    { label: 'AAPL Q4 SERVICES BEAT', value: '+14.2%', type: '8-K', highlight: true },
    { label: 'NVDA BLACKWELL YIELD', value: '>92%', type: 'SUPPLY' },
    { label: 'TSLA DELIVERY CUT', value: '-19%', type: 'ANALYST' },
    { label: 'AAPL-PERP 24/7', value: '+0.2% (LAG)', type: 'TOKENIZED', highlight: true },
    { label: 'TSMC TAIPEI AUCTION', value: '+1.4%', type: 'TWSE' },
    { label: 'SPY S&P 500 FUTURES', value: '+0.4%', type: 'CME' },
    { label: 'SOXX SEMIS ETF', value: '+1.6%', type: 'ETF' },
  ];

  // Marquee 2: Slower Information & Catalyst Stream
  const marqueeSlowItems = [
    { label: '19:15 EST — FED GOV WALLER SPEECH AT IIB', type: 'MONETARY' },
    { label: '20:30 EST — JAPAN WAGE & HOUSEHOLD EARNINGS YoY', type: 'MACRO' },
    { label: '22:00 EST — CHINA CAIXIN MANUFACTURING PMI', type: 'CHINA' },
    { label: '23:30 EST — TOKYO STOCK EXCHANGE CASH BELL', type: 'ASIA' },
    { label: '03:00 EST — EUROPEAN CASH OPEN (DAX/FTSE)', type: 'EUROPE' },
    { label: '08:30 EST — US CORE CPI YoY & ADVANCE RETAIL', type: 'US' },
    { label: 'AFTER-HOURS SURVEILLANCE RUNNING ON 17 ASSETS', type: 'AI AGENT', highlight: true },
  ];

  const handleOpenTerminal = () => {
    const elem = document.getElementById('terminal');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenSampleRun = () => {
    const sample = runRecords.find((r) => r.id === 'AF-00291') || runRecords[0];
    if (sample) {
      setReplayRun(sample);
    }
  };

  const handleOpenRiskGate = (target: Opportunity | AfterEvent) => {
    setSelectedEvent(null);
    setSelectedWhyTradeOpp(null);
    setRiskGateTarget(target);
  };

  const handleProceedToExecution = (target: Opportunity | AfterEvent) => {
    setRiskGateTarget(null);
    setExecutionTarget(target);
  };

  const handleRunCreated = (run: RunRecord) => {
    setExecutionTarget(null);
    setLiveAiPayload(null);
    setReplayRun(run);
  };

  const handleCompareRuns = (run: RunRecord) => {
    setComparisonInitialRun(run);
    setIsComparing(true);
  };

  const handleResetData = () => {
    runStore.resetToDefaults();
    setIsStatusOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#09090B] text-foreground flex flex-col selection:bg-accent selection:text-accent-foreground font-sans">
      {/* 1. Global Brutalist Top Navigation with AI Status Pill */}
      <AfterNav
        aiStatus={aiStatus}
        onOpenDemo={() => setIsDemoOpen(true)}
        onOpenStatus={() => setIsStatusOpen(true)}
        onSelectSection={(id) => {
          const elem = document.getElementById(id);
          if (elem) elem.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* 2. Fast Market Intelligence Marquee */}
      <KineticMarquee speed="fast" items={marqueeFastItems} />

      {/* 3. Hero Section (Poster Scale Typography) */}
      <AfterHero
        onOpenTerminal={handleOpenTerminal}
        onOpenSampleRun={handleOpenSampleRun}
        onOpenDemo={() => setIsDemoOpen(true)}
      />

      {/* 4. Slower Catalyst Stream Marquee (Reverse) */}
      <KineticMarquee speed="slow" reverse items={marqueeSlowItems} />

      {/* 5. Live After-Hours Terminal with Real LLM Ingestion Desk */}
      <LiveTerminal
        events={events}
        isRealAiActive={aiStatus.configured}
        onSelectEvent={(evt) => setSelectedEvent(evt)}
        onAnalyzeWithAi={(payload) => setLiveAiPayload(payload)}
      />

      {/* 6. Opportunity Radar (Ranked Asymmetric Mispricings) */}
      <OpportunityRadar
        opportunities={opportunities}
        onOpenWhyTrade={(opp) => setSelectedWhyTradeOpp(opp)}
        onOpenRiskGate={(opp) => handleOpenRiskGate(opp)}
      />

      {/* 7. Sticky Storytelling Section ("HOW AFTER THINKS") */}
      <StickyStorySection />

      {/* 8. Catalyst Calendar (Overnight Chronological Timeline) */}
      <CatalystCalendar
        catalysts={catalysts}
        onSelectAsset={(sym) => {
          const matchedEvt = events.find((e) => e.asset === sym);
          if (matchedEvt) {
            setSelectedEvent(matchedEvt);
          } else {
            handleOpenTerminal();
          }
        }}
      />

      {/* 9. Permanent Run Records (Immutable Audit Ledger) */}
      <RunRecordsList
        runs={runRecords}
        onSelectRun={(run) => setReplayRun(run)}
        onCompareRuns={(run) => handleCompareRuns(run)}
      />

      {/* 10. Editorial Footer */}
      <AfterFooter
        onOpenDemo={() => setIsDemoOpen(true)}
        onOpenRunRecords={() => {
          const elem = document.getElementById('run-records');
          if (elem) elem.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* MODAL DIALOGS */}

      {/* Live AI Analysis Modal (Triggered by Breaking News or Event Card) */}
      {liveAiPayload && (
        <LiveAiAnalyzerModal
          initialPayload={liveAiPayload}
          onClose={() => setLiveAiPayload(null)}
          onRunCreated={handleRunCreated}
          onOpenConfig={() => setIsStatusOpen(true)}
        />
      )}

      {/* Event Intelligence Modal */}
      {selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          onExecuteTrade={(evt) => handleOpenRiskGate(evt)}
        />
      )}

      {/* Why This Trade Modal */}
      {selectedWhyTradeOpp && (
        <WhyThisTradeModal
          opportunity={selectedWhyTradeOpp}
          onClose={() => setSelectedWhyTradeOpp(null)}
          onOpenRiskGate={(opp) => handleOpenRiskGate(opp)}
        />
      )}

      {/* Pre-Trade Risk Gate Check Modal */}
      {riskGateTarget && (
        <RiskGateModal
          target={riskGateTarget}
          onClose={() => setRiskGateTarget(null)}
          onProceedToExecution={handleProceedToExecution}
        />
      )}

      {/* Paper Execution Modal */}
      {executionTarget && (
        <PaperExecutionModal
          target={executionTarget}
          onClose={() => setExecutionTarget(null)}
          onRunCreated={handleRunCreated}
        />
      )}

      {/* Run Replay Modal */}
      {replayRun && (
        <RunReplayModal
          run={replayRun}
          onClose={() => setReplayRun(null)}
          onCompareWith={(run) => {
            setReplayRun(null);
            handleCompareRuns(run);
          }}
        />
      )}

      {/* Run Comparison Modal */}
      {isComparing && (
        <RunComparisonModal
          runs={runRecords}
          initialRunA={comparisonInitialRun}
          onClose={() => setIsComparing(false)}
        />
      )}

      {/* One-Click Hackathon Live Agent Demo Modal */}
      {isDemoOpen && (
        <LiveAgentDemoModal
          onClose={() => setIsDemoOpen(false)}
          onViewRun={(run) => {
            setIsDemoOpen(false);
            setReplayRun(run);
          }}
        />
      )}

      {/* System Status & Diagnostics Modal with API Config Tab */}
      {isStatusOpen && (
        <SystemStatusModal
          onClose={() => setIsStatusOpen(false)}
          onResetData={handleResetData}
        />
      )}
    </div>
  );
};

export default App;
