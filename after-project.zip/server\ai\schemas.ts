// Schema definitions and validation for AFTER Structured LLM Intelligence

export interface StructuredLLMOutput {
  event_type: 'earnings' | 'macro' | 'sec' | 'geopolitical' | 'analyst' | 'corporate' | 'tokenized';
  event_summary: string;
  primary_asset: string;
  related_assets: string[];
  direction: 'bullish' | 'bearish' | 'neutral';
  impact_score: number;       // 0 to 100
  surprise_score: number;     // 0 to 100
  relevance_score: number;    // 0 to 100
  confidence_score: number;   // 0 to 100
  expected_direction: 'up' | 'down' | 'flat';
  expected_move_reason: string;
  key_drivers: string[];
  risks: string[];
  invalidations: string[];
  analysis_summary: string;
}

export function validateStructuredLLMOutput(data: unknown): { valid: boolean; data?: StructuredLLMOutput; error?: string } {
  if (!data || typeof data !== 'object') {
    return { valid: false, error: 'Output is not an object' };
  }

  const obj = data as Record<string, unknown>;

  // Validate event_type
  const validTypes = ['earnings', 'macro', 'sec', 'geopolitical', 'analyst', 'corporate', 'tokenized'];
  const event_type = typeof obj.event_type === 'string' && validTypes.includes(obj.event_type.toLowerCase())
    ? obj.event_type.toLowerCase() as StructuredLLMOutput['event_type']
    : 'corporate';

  // Validate strings
  const event_summary = typeof obj.event_summary === 'string' && obj.event_summary.trim()
    ? obj.event_summary.trim()
    : 'Overnight market information parsed by AFTER agent.';

  const primary_asset = typeof obj.primary_asset === 'string' && obj.primary_asset.trim()
    ? obj.primary_asset.trim().toUpperCase().slice(0, 8)
    : 'SPY';

  // Validate related assets
  const related_assets = Array.isArray(obj.related_assets)
    ? obj.related_assets.map(a => String(a).toUpperCase().trim()).filter(Boolean).slice(0, 6)
    : ['QQQ', 'SPY'];

  // Direction
  const dirStr = String(obj.direction || 'neutral').toLowerCase();
  const direction: StructuredLLMOutput['direction'] = 
    dirStr.includes('bull') || dirStr.includes('pos') || dirStr.includes('up') ? 'bullish' :
    dirStr.includes('bear') || dirStr.includes('neg') || dirStr.includes('down') ? 'bearish' : 'neutral';

  const expDirStr = String(obj.expected_direction || 'flat').toLowerCase();
  const expected_direction: StructuredLLMOutput['expected_direction'] =
    expDirStr.includes('up') || expDirStr.includes('bull') ? 'up' :
    expDirStr.includes('down') || expDirStr.includes('bear') ? 'down' : 'flat';

  // Scores (0-100 clamping)
  const clampScore = (val: unknown, fallback: number): number => {
    const num = typeof val === 'number' ? val : parseFloat(String(val));
    if (isNaN(num)) return fallback;
    return Math.max(0, Math.min(100, Math.round(num)));
  };

  const impact_score = clampScore(obj.impact_score, 75);
  const surprise_score = clampScore(obj.surprise_score, 70);
  const relevance_score = clampScore(obj.relevance_score, 85);
  const confidence_score = clampScore(obj.confidence_score, 80);

  const expected_move_reason = typeof obj.expected_move_reason === 'string' && obj.expected_move_reason.trim()
    ? obj.expected_move_reason.trim()
    : 'Fundamental shock alters relative valuation envelope ahead of cash market open.';

  const key_drivers = Array.isArray(obj.key_drivers) && obj.key_drivers.length > 0
    ? obj.key_drivers.map(d => String(d).trim()).filter(Boolean)
    : ['Fundamental margin & revenue deviations', 'Consensus estimate surprise'];

  const risks = Array.isArray(obj.risks) && obj.risks.length > 0
    ? obj.risks.map(r => String(r).trim()).filter(Boolean)
    : ['After-hours illiquidity', 'Overnight futures reversal'];

  const invalidations = Array.isArray(obj.invalidations) && obj.invalidations.length > 0
    ? obj.invalidations.map(i => String(i).trim()).filter(Boolean)
    : ['Sudden management retraction', 'Contradictory regulatory announcement', 'Index futures reversal'];

  const analysis_summary = typeof obj.analysis_summary === 'string' && obj.analysis_summary.trim()
    ? obj.analysis_summary.trim()
    : `${primary_asset} evaluated as ${direction} with impact score ${impact_score}/100.`;

  return {
    valid: true,
    data: {
      event_type,
      event_summary,
      primary_asset,
      related_assets,
      direction,
      impact_score,
      surprise_score,
      relevance_score,
      confidence_score,
      expected_direction,
      expected_move_reason,
      key_drivers,
      risks,
      invalidations,
      analysis_summary
    }
  };
}
