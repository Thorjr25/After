import React, { useState, useEffect } from 'react';
import { X, Play, RotateCcw, CheckCircle2, Zap, ArrowRight, ShieldCheck, Cpu } from 'lucide-react';
import confetti from 'canvas-confetti';
import { terminalAudio } from '../../services/audioService';
import { runStore } from '../../services/runStore';
import { RunRecord } from '../../types/after';

interface LiveAgentDemoModalProps {
  onClose: () => void;
  onViewRun: (run: RunRecord) => void;
}

export const LiveAgentDemoModal: React.FC<LiveAgentDemoModalProps> = ({
  onClose,
  onViewRun,
}) => {
  const [activeStage, setActiveStage] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(true);

  const demoStages = [
    {
      stage: 1,
      name: 'US CASH EQUITIES CLOSED',
      loadingText: 'MONITORING OVERNIGHT SATELLITE & ELECTRONIC ORDER BOOKS...',
      headline: 'NYSE & NASDAQ CASH TRADING: HALTED',
      detail: 'Standard trading session closed at 16:00 EST. Traditional participants are inactive. Electronic communication networks (ECNs), index futures, and 24/7 tokenized perpetual markets remain active.',
      highlight: 'MARKET STATUS: CLOSED (18:42 EST)',
      metric: '09:30 EST CASH OPEN IN: 14h 48m'
    },
    {
      stage: 2,
      name: 'BREAKING INFORMATION ARRIVES',
      loadingText: 'INGESTING UNSTRUCTURED FILING IN 180MS...',
      headline: 'INBOUND SEC 8-K: APPLE SERVICES REVENUE SURGES +14.2%',
      detail: 'SEC EDGAR crawler node detected filing #0000320193. Apple Inc. reported record Services revenue of $24.97B, expanding consolidated gross margin to 46.2% (+210 bps).',
      highlight: 'INGESTION LATENCY: 210MS',
      metric: 'REVENUE BEAT: +$5.5B CONSENSUS'
    },
    {
      stage: 3,
      name: 'EVENT CLASSIFIED & ASSET IDENTIFIED',
      loadingText: 'CLASSIFYING EVENT & ISOLATING EXPOSURE TREE...',
      headline: 'PRIMARY: AAPL.US // SECTOR: TECHNOLOGY HARDWARE',
      detail: 'NLP categorization maps entity to Apple Inc. Correlated exposures linked: QQQ (9.1% index weight), XLK (14.2% tech ETF weight), Taiwan Semi (TSM foundry supplier), and AAPL-PERP 24/7 contract.',
      highlight: 'ENTITY: AAPL',
      metric: 'CONFIDENCE: 98% MAPPING'
    },
    {
      stage: 4,
      name: 'INFORMATION PRICING SCORED',
      loadingText: 'EVALUATING HISTORICAL DRIFT MULTIPLES...',
      headline: 'IMPACT: 91 / 100 // SURPRISE: 82 / 100 // RELEVANCE: 96',
      detail: 'Multi-factor quantitative information model computes fundamental impact score. High gross margin expansion yields high structural valuation re-rating potential.',
      highlight: 'IMPACT SCORE: 91 / 100',
      metric: 'AI CERTAINTY: 88%'
    },
    {
      stage: 5,
      name: 'REFERENCE MARKETS CHECKED',
      loadingText: 'PROBING NASDAQ FUTURES & CROSS-ASSET PROXIES...',
      headline: 'NQ FUTURES +1.1% // XLK +0.8% // TOKENIZED PERP +0.2%',
      detail: 'E-mini Nasdaq 100 futures and tech ETFs have already begun repricing upward (+0.8% to +1.1%). However, offshore and retail tokenized equity books remain lagging at only +0.2%.',
      highlight: 'PROXY CONFIRMATION: +1.1%',
      metric: 'TOKENIZED LAG: +0.2% ONLY'
    },
    {
      stage: 6,
      name: 'PRICING DISLOCATION FOUND',
      loadingText: 'COMPUTING EXPECTED VS CURRENT IMPLIED DISLOCATION...',
      headline: 'ASYMMETRIC PRICING GAP DETECTED: +0.6% TO +0.9%',
      detail: 'AFTER’s Expected Reaction Engine forecasts a fundamental reopening move of +4.1%. Comparing against current implied extended-hours pricing reveals a clear informational dislocation.',
      highlight: 'GAP: +0.6% TO +0.9%',
      metric: 'EXPECTED MOVE: +4.1%'
    },
    {
      stage: 7,
      name: 'OPPORTUNITY RANKED #1',
      loadingText: 'SORTING CROSS-MARKET OPPORTUNITY MATRIX...',
      headline: 'OPPORTUNITY SCORE 93 / 100 // CONVICTION: HIGH',
      detail: 'Synthesized Opportunity Rank #1 for the overnight session. Risk/reward profile favors overnight long positioning ahead of Asia cash open and European tech ADR follow-through.',
      highlight: 'RANK: 01 / 17',
      metric: 'ALPHA SCORE: 93'
    },
    {
      stage: 8,
      name: 'PRE-TRADE RISK GATE AUDITED',
      loadingText: 'RUNNING 8-POINT AUTOMATED SAFETY POLICY...',
      headline: 'RISK CHECK: PASSED (8/8 SAFETY CONSTRAINTS)',
      detail: 'Liquidity depth verified ($42.4M), ATR volatility envelope verified (1.4x), news conflict check verified (0 retractions), position sizing capped at $10,000, and structural stop floor locked at $224.50.',
      highlight: '8 / 8 CHECKS PASSED',
      metric: 'GATE: UNLOCKED'
    },
    {
      stage: 9,
      name: 'PAPER ORDER EXECUTED',
      loadingText: 'DISPATCHING SIMULATED PAPER FILL...',
      headline: 'PAPER BUY: 43.78 AAPL @ $228.40 ($10,000 NOTIONAL)',
      detail: 'Order filled on simulated electronic paper execution desk. Non-custodial simulated position active with automated stop at $224.50 and profit target at $237.75.',
      highlight: 'EXECUTION: PAPER SUBMITTED',
      metric: 'FILL: $228.40'
    },
    {
      stage: 10,
      name: 'RUN RECORD PERMANENTLY COMMITTED',
      loadingText: 'FINALIZING AUDIT TRAIL & CONVERGENCE METRICS...',
      headline: 'RUN #AF-00295 SERIALIZED TO AUDIT LEDGER',
      detail: 'The complete 10-stage causal lifecycle has been serialized into an immutable Run Record. In subsequent cash market opening, AAPL gapped up +3.7%, confirming the detected information gap!',
      highlight: 'STATUS: RUN RECORD CREATED',
      metric: 'OUTCOME: +3.7% CONFIRMED'
    }
  ];

  // Auto progression timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRunning) {
      if (activeStage < demoStages.length - 1) {
        timer = setTimeout(() => {
          terminalAudio.playClick(900 + activeStage * 40);
          setActiveStage((prev) => prev + 1);
        }, 2200);
      } else {
        setIsRunning(false);
        terminalAudio.playSignalAlert();
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#DFE104', '#FAFAFA', '#27272A']
        });
      }
    }
    return () => clearTimeout(timer);
  }, [isRunning, activeStage, demoStages.length]);

  const current = demoStages[activeStage];
  const progressPercent = ((activeStage + 1) / demoStages.length) * 100;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-none"
      onClick={() => {
        terminalAudio.playClick(600);
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto b-brutal bg-[#09090B] p-6 sm:p-8 text-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-start justify-between pb-4 b-brutal-b gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <span className="w-2 h-2 bg-accent inline-block animate-ping" />
              <span>AFTER AGENT REAL-TIME SIMULATION</span>
              <span>/</span>
              <span className="text-accent font-bold">THE OVERNIGHT JOURNEY</span>
            </div>
            <h2 className="font-display font-black text-2xl sm:text-4xl uppercase tracking-tight">
              DEMO: “RUN AFTER”
            </h2>
          </div>

          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="p-2 b-brutal bg-muted-surface hover:bg-accent hover:text-accent-foreground transition-colors shrink-0"
            aria-label="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Progress Track */}
        <div className="py-5 b-brutal-b space-y-3">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-muted-foreground uppercase">
              STAGE {activeStage + 1} OF {demoStages.length}: {current.name}
            </span>
            <span className="text-accent font-bold font-mono">
              {Math.round(progressPercent)}% COMPLETE
            </span>
          </div>

          <div className="w-full h-3 bg-muted-surface b-brutal relative overflow-hidden">
            <div
              className="h-full bg-accent transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Kinetic textual loader indicator */}
          <div className="text-[11px] font-mono text-muted-foreground flex items-center space-x-2">
            <Cpu size={13} className="text-accent animate-spin" />
            <span className="font-bold text-accent uppercase">{current.loadingText}</span>
          </div>
        </div>

        {/* Big Stage Presentation Box */}
        <div className="py-6 b-brutal-b">
          <div className="p-6 sm:p-8 b-brutal bg-muted-surface/30 border-accent">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 b-brutal-b">
              <span className="px-3 py-1 b-brutal bg-accent text-accent-foreground font-display font-black text-xs sm:text-sm tracking-wider">
                {current.highlight}
              </span>

              <span className="font-mono text-xs sm:text-sm text-foreground font-bold">
                {current.metric}
              </span>
            </div>

            <div className="pt-5 space-y-3">
              <h3 className="font-display font-black text-2xl sm:text-3xl uppercase tracking-tight text-foreground">
                {current.headline}
              </h3>

              <p className="text-sm sm:text-base text-muted-foreground leading-relaxed font-sans font-normal pt-1">
                {current.detail}
              </p>
            </div>
          </div>
        </div>

        {/* Sequence Scrubber Dots / Tabs */}
        <div className="py-4 b-brutal-b grid grid-cols-5 sm:grid-cols-10 gap-1.5 font-mono text-[10px]">
          {demoStages.map((st, idx) => (
            <button
              key={st.stage}
              onClick={() => {
                terminalAudio.playClick(800 + idx * 40);
                setActiveStage(idx);
                setIsRunning(false);
              }}
              className={`p-2 b-brutal text-center font-bold transition-all ${
                activeStage === idx
                  ? 'bg-accent text-accent-foreground border-accent font-black scale-105'
                  : idx < activeStage
                  ? 'bg-muted-surface text-muted-foreground'
                  : 'bg-transparent text-zinc-700'
              }`}
            >
              0{st.stage}
            </button>
          ))}
        </div>

        {/* Footer Actions */}
        <div className="pt-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                terminalAudio.playClick();
                setIsRunning(!isRunning);
              }}
              className="px-4 py-2.5 b-brutal bg-muted-surface text-xs font-mono font-bold hover:text-foreground"
            >
              {isRunning ? 'PAUSE DEMO' : 'RESUME DEMO'}
            </button>

            <button
              onClick={() => {
                terminalAudio.playClick();
                setActiveStage(0);
                setIsRunning(true);
              }}
              className="p-2.5 b-brutal bg-muted-surface text-muted-foreground hover:text-foreground"
              title="Restart"
            >
              <RotateCcw size={15} />
            </button>
          </div>

          <div className="flex items-center space-x-3">
            {activeStage === demoStages.length - 1 ? (
              <button
                onClick={() => {
                  terminalAudio.playClick(1100);
                  const sampleRun = runStore.getRunById('AF-00291') || runStore.getRunRecords()[0];
                  if (sampleRun) {
                    onViewRun(sampleRun);
                  }
                }}
                className="flex items-center space-x-2 px-6 py-3 bg-accent text-accent-foreground font-display font-black text-xs sm:text-sm tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all"
              >
                <span>OPEN GENERATED RUN RECORD</span>
                <ArrowRight size={16} />
              </button>
            ) : (
              <button
                onClick={() => {
                  terminalAudio.playClick(850);
                  setActiveStage((prev) => Math.min(demoStages.length - 1, prev + 1));
                  setIsRunning(false);
                }}
                className="flex items-center space-x-2 px-5 py-2.5 bg-accent text-accent-foreground font-display font-bold text-xs tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-colors"
              >
                <span>NEXT STEP</span>
                <ArrowRight size={14} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
