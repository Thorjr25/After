import React from 'react';
import { X, ShieldAlert, ArrowUpRight, HelpCircle, AlertOctagon, CheckCircle2 } from 'lucide-react';
import { Opportunity } from '../../types/after';
import { terminalAudio } from '../../services/audioService';

interface WhyThisTradeModalProps {
  opportunity: Opportunity | null;
  onClose: () => void;
  onOpenRiskGate: (opp: Opportunity) => void;
}

export const WhyThisTradeModal: React.FC<WhyThisTradeModalProps> = ({
  opportunity,
  onClose,
  onOpenRiskGate,
}) => {
  if (!opportunity) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85"
      onClick={() => {
        terminalAudio.playClick(600);
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto b-brutal bg-[#09090B] p-6 sm:p-8 text-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-start justify-between pb-4 b-brutal-b gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <span>OPPORTUNITY RANK #{opportunity.rank}</span>
              <span>•</span>
              <span className="text-accent font-bold">DISLOCATION: {opportunity.dislocationRange}</span>
            </div>
            <h2 className="font-display font-black text-2xl sm:text-3xl uppercase tracking-tight flex items-center gap-3">
              <span className="px-2.5 py-0.5 bg-accent text-accent-foreground">
                {opportunity.primaryAction} {opportunity.symbol}
              </span>
              <span className="text-muted-foreground text-xl sm:text-2xl font-normal">
                {opportunity.name}
              </span>
            </h2>
          </div>

          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="p-2 b-brutal bg-muted-surface hover:bg-accent hover:text-accent-foreground transition-colors shrink-0"
            aria-label="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Spread Comparison Visual: Expected vs Implied */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 py-6 b-brutal-b font-mono text-xs">
          <div className="p-3.5 b-brutal bg-muted-surface">
            <span className="text-muted-foreground block text-[10px] uppercase">Expected Move</span>
            <span className={`font-display font-black text-3xl block mt-1 ${
              opportunity.expectedMove >= 0 ? 'text-accent' : 'text-red-400'
            }`}>
              {opportunity.expectedMove >= 0 ? `+${opportunity.expectedMove}%` : `${opportunity.expectedMove}%`}
            </span>
            <span className="text-[10px] text-muted-foreground block mt-0.5">Model fundamental estimate</span>
          </div>

          <div className="p-3.5 b-brutal bg-muted-surface">
            <span className="text-muted-foreground block text-[10px] uppercase">Current Implied Move</span>
            <span className="font-display font-black text-3xl text-foreground block mt-1">
              {opportunity.currentImpliedMove >= 0 ? `+${opportunity.currentImpliedMove}%` : `${opportunity.currentImpliedMove}%`}
            </span>
            <span className="text-[10px] text-muted-foreground block mt-0.5">Offshore / after-hours book</span>
          </div>

          <div className="p-3.5 b-brutal bg-accent text-accent-foreground col-span-2 sm:col-span-1">
            <span className="block text-[10px] uppercase font-bold">Unpriced Dislocation</span>
            <span className="font-display font-black text-3xl block mt-1">
              {opportunity.dislocationRange}
            </span>
            <span className="text-[10px] block mt-0.5 font-sans font-medium">Asymmetric edge</span>
          </div>
        </div>

        {/* Why Long / Why Short Section */}
        <div className="py-6 b-brutal-b">
          <div className="flex items-center space-x-2 text-xs font-mono text-accent font-bold uppercase mb-2">
            <HelpCircle size={15} />
            <span>WHY {opportunity.primaryAction}? (EXPLAINABLE THESIS)</span>
          </div>
          <p className="text-sm sm:text-base text-foreground font-sans leading-relaxed p-4 b-brutal bg-muted-surface/30">
            {opportunity.whyTrade}
          </p>
        </div>

        {/* What Could Invalidate This? (Crucial for Trust!) */}
        <div className="py-6 b-brutal-b">
          <div className="flex items-center space-x-2 text-xs font-mono text-red-400 font-bold uppercase mb-2">
            <AlertOctagon size={15} />
            <span>WHAT COULD INVALIDATE THIS? (INSPECTION GATES)</span>
          </div>
          <p className="text-xs text-muted-foreground mb-3 font-sans">
            AFTER continuously monitors the following risk invalidation vectors. If any condition trips, the agent immediately issues an alert or closes the paper position:
          </p>
          <div className="space-y-2">
            {opportunity.invalidationTriggers.map((trig, idx) => (
              <div key={idx} className="flex items-start space-x-2.5 p-3 b-brutal bg-[#18181B] text-xs font-mono">
                <span className="text-accent font-bold">#{idx + 1}</span>
                <span className="text-foreground">{trig}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Modal Actions */}
        <div className="pt-6 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="px-5 py-2.5 b-brutal bg-muted-surface text-xs font-mono font-bold hover:text-foreground"
          >
            DISMISS
          </button>

          <button
            onClick={() => {
              terminalAudio.playClick(1100);
              onOpenRiskGate(opportunity);
            }}
            className="flex items-center space-x-2 px-6 py-3 bg-accent text-accent-foreground font-display font-black text-xs sm:text-sm tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all active:scale-[0.98]"
          >
            <ShieldAlert size={16} />
            <span>PROCEED TO RISK GATE CHECK</span>
            <ArrowUpRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};
