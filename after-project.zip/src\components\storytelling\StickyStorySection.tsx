import React, { useState } from 'react';
import { Layers, CheckCircle2, ArrowRight, Eye, Brain, LineChart, Split, ShieldCheck, Zap } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';

interface StoryCard {
  step: string;
  title: string;
  subtitle: string;
  detail: string;
  icon: React.ReactNode;
  metricLabel: string;
  metricValue: string;
  dataPoints: string[];
}

export const StickyStorySection: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(0);

  const steps: StoryCard[] = [
    {
      step: '01',
      title: 'INFORMATION ARRIVES',
      subtitle: 'Continuous Unstructured Overnight Ingestion',
      detail: 'Traditional US exchanges close at 16:00 EST. AFTER’s crawler mesh ingests SEC 8-K filings, conference call audio streams, sovereign announcements, Asia morning trade flows, and breaking micro-events in sub-300ms.',
      icon: <Eye className="text-accent" size={28} />,
      metricLabel: 'SURVEILLANCE LATENCY',
      metricValue: '210ms',
      dataPoints: ['SEC EDGAR Filings', 'Taiwan Foundry Logs', 'Off-Exchange ECN Feeds', 'Macro Leaks']
    },
    {
      step: '02',
      title: 'INTERPRETATION & ENTITY MAPPING',
      subtitle: 'Dissecting Shock Sign & Magnitude',
      detail: 'The AI parses the news payload against 15 years of quarterly filings. It scores fundamental Impact (0-100), Surprise relative to consensus, and Relevance to the primary issuer while isolating indirect sector fallout.',
      icon: <Brain className="text-accent" size={28} />,
      metricLabel: 'NLP CONVICTION',
      metricValue: '91/100',
      dataPoints: ['Services Margin Beat', 'Channel Inventory Norm', 'Gross Margin +210bps', 'Entity: AAPL']
    },
    {
      step: '03',
      title: 'EXPECTED MOVE ENGINE',
      subtitle: 'Simulating Fundamental Equilibrium',
      detail: 'The agent computes the quantitative fair-value directional repricing. It does not output a vague sentiment label; it predicts an explicit expected move percentage with confidence bounds.',
      icon: <LineChart className="text-accent" size={28} />,
      metricLabel: 'EXPECTED MOVE',
      metricValue: '+4.1%',
      dataPoints: ['Confidence: 88%', 'Target Range: 3.8%–4.6%', 'Historical Beta Fit', 'Peer Weighting']
    },
    {
      step: '04',
      title: 'MARKET COMPARISON',
      subtitle: 'Cross-Examining Live 24/7 Proxies',
      detail: 'While the underlying cash stock is closed, correlated markets are actively quoting. AFTER queries E-mini Nasdaq futures (+1.1%), tech ETFs (+0.8%), Asian ADRs (+1.4%), and 24/7 tokenized perpetuals (+0.2%).',
      icon: <Split className="text-accent" size={28} />,
      metricLabel: 'NQ FUTURES MOVE',
      metricValue: '+1.1%',
      dataPoints: ['Nasdaq Futures: +1.1%', 'Tech ETF XLK: +0.8%', 'TSMC Taipei: +1.4%', 'Token Perp: +0.2%']
    },
    {
      step: '05',
      title: 'DISLOCATION DETECTION',
      subtitle: 'Isolating the Information-Pricing Gap',
      detail: 'When expected fundamental repricing (+4.1%) deviates substantially from observed extended-hours price discovery (+0.8%), an asymmetric information pricing gap exists. AFTER quantifies the dislocation magnitude.',
      icon: <Zap className="text-accent" size={28} />,
      metricLabel: 'DETECTED GAP',
      metricValue: '+0.6%–0.9%',
      dataPoints: ['Asymmetric Upside', 'Unconverged Spread', 'Overnight Lag Alert', 'Alpha Conviction: 93']
    },
    {
      step: '06',
      title: 'RISK GATE EVALUATION',
      subtitle: 'Strict Pre-Action Safeguards',
      detail: 'Before any signal can be proposed or executed, the trade must clear 8 hard safety gates: after-hours book depth, multi-source consistency, ATR volatility limits, proxy confirmation, and hard stop-loss definitions.',
      icon: <ShieldCheck className="text-accent" size={28} />,
      metricLabel: 'RISK GATE',
      metricValue: 'PASSED (8/8)',
      dataPoints: ['Liquidity > $15M', 'Confidence >= 75%', 'Conflict Check: Clean', 'Hard Stop Defined']
    },
    {
      step: '07',
      title: 'ACTION & RUN RECORDING',
      subtitle: 'Deterministic Audit Trail',
      detail: 'The signal is converted into a paper order execution with defined entry, position sizing, and invalidation criteria. Every microsecond of the decision lifecycle is committed to a permanent, replayable Run Record.',
      icon: <CheckCircle2 className="text-accent" size={28} />,
      metricLabel: 'AUDIT LEDGER',
      metricValue: '#AF-00291',
      dataPoints: ['Paper Long AAPL', 'Entry: $228.40', 'Stop: $224.50', 'Lifecycle Hash Recorded']
    }
  ];

  return (
    <section id="how-it-works" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      {/* Section Header */}
      <div className="mb-12 b-brutal bg-[#09090B] p-6 sm:p-8">
        <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
          <Layers size={15} className="text-accent" />
          <span>COGNITIVE ARCHITECTURE</span>
          <span>/</span>
          <span className="text-accent font-bold">END-TO-END REASONING PIPELINE</span>
        </div>
        <h2 className="font-display font-black text-3xl sm:text-5xl text-foreground tracking-tighter uppercase">
          HOW AFTER THINKS
        </h2>
        <p className="pt-3 text-sm sm:text-base text-muted-foreground font-sans max-w-3xl">
          AFTER never behaves like an opaque black box. Watch how the agent transforms raw after-hours 
          information into quantified, risk-gated market opportunities.
        </p>
      </div>

      {/* Interactive Sticky Step Experience */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Interactive Step Selector / Navigation */}
        <div className="lg:col-span-4 space-y-2 sticky top-24 z-20">
          <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider block mb-3">
            COGNITIVE STAGES (SELECT TO SCRUB)
          </span>
          {steps.map((s, idx) => {
            const isActive = activeStep === idx;
            return (
              <button
                key={s.step}
                onClick={() => {
                  terminalAudio.playClick(800 + idx * 60);
                  setActiveStep(idx);
                }}
                className={`w-full text-left p-3.5 b-brutal transition-all flex items-center justify-between ${
                  isActive
                    ? 'bg-accent text-accent-foreground border-accent font-black shadow-none translate-x-1.5'
                    : 'bg-muted-surface/40 text-muted-foreground hover:text-foreground hover:bg-muted-surface'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <span className="font-display font-bold text-sm tracking-tight">{s.step}</span>
                  <span className="font-display font-bold text-xs uppercase tracking-wider">{s.title}</span>
                </div>
                {isActive && <ArrowRight size={16} />}
              </button>
            );
          })}
        </div>

        {/* Right Column: Active Card Display (Sticky / Stacking Visual) */}
        <div className="lg:col-span-8">
          <div className="b-brutal bg-[#09090B] p-6 sm:p-10 border-accent relative min-h-[500px] flex flex-col justify-between">
            {/* Top Stage Indicator */}
            <div>
              <div className="flex items-center justify-between pb-6 b-brutal-b">
                <div className="flex items-center space-x-3">
                  <div className="p-3 b-brutal bg-muted-surface text-accent">
                    {steps[activeStep].icon}
                  </div>
                  <div>
                    <span className="text-xs font-mono text-accent font-bold">
                      STAGE {steps[activeStep].step} OF 07
                    </span>
                    <h3 className="font-display font-black text-2xl sm:text-4xl text-foreground uppercase tracking-tight">
                      {steps[activeStep].title}
                    </h3>
                  </div>
                </div>

                <div className="text-right p-3 b-brutal bg-muted-surface min-w-[120px]">
                  <span className="text-[9px] font-mono text-muted-foreground uppercase block">
                    {steps[activeStep].metricLabel}
                  </span>
                  <span className="font-display font-black text-2xl sm:text-3xl text-accent block mt-0.5">
                    {steps[activeStep].metricValue}
                  </span>
                </div>
              </div>

              {/* Subtitle & Narrative */}
              <div className="py-6">
                <h4 className="font-mono text-xs font-bold text-accent uppercase tracking-wider mb-2">
                  // {steps[activeStep].subtitle}
                </h4>
                <p className="text-base sm:text-lg text-foreground leading-relaxed font-sans font-normal bg-muted-surface/20 p-5 b-brutal">
                  {steps[activeStep].detail}
                </p>
              </div>

              {/* Data Points Grid */}
              <div className="pt-2">
                <span className="text-[11px] font-mono text-muted-foreground uppercase block mb-2">
                  VERIFIED EVIDENCE & TELEMETRY:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                  {steps[activeStep].dataPoints.map((dp, i) => (
                    <div key={i} className="p-2.5 b-brutal bg-muted-surface/40 text-foreground font-bold">
                      {dp}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Stepper Footer Controls */}
            <div className="pt-8 b-brutal-t flex items-center justify-between mt-8">
              <button
                disabled={activeStep === 0}
                onClick={() => {
                  terminalAudio.playClick();
                  setActiveStep((prev) => Math.max(0, prev - 1));
                }}
                className="px-4 py-2 b-brutal bg-muted-surface text-xs font-mono font-bold disabled:opacity-30 disabled:cursor-not-allowed hover:text-foreground"
              >
                ← PREVIOUS STAGE
              </button>

              <div className="text-xs font-mono text-muted-foreground">
                STAGE {activeStep + 1} / {steps.length}
              </div>

              <button
                disabled={activeStep === steps.length - 1}
                onClick={() => {
                  terminalAudio.playClick(900);
                  setActiveStep((prev) => Math.min(steps.length - 1, prev + 1));
                }}
                className="px-4 py-2 bg-accent text-accent-foreground font-display font-bold text-xs tracking-wider b-brutal border-accent disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white hover:text-black"
              >
                NEXT STAGE →
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
