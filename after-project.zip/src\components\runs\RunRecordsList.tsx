import React, { useState } from 'react';
import { RunRecord } from '../../types/after';
import { ShieldCheck, ArrowUpRight, RotateCcw, ArrowLeftRight, Database, Play } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';

interface RunRecordsListProps {
  runs: RunRecord[];
  onSelectRun: (run: RunRecord) => void;
  onCompareRuns: (run: RunRecord) => void;
}

export const RunRecordsList: React.FC<RunRecordsListProps> = ({
  runs,
  onSelectRun,
  onCompareRuns,
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const filtered =
    filterStatus === 'ALL'
      ? runs
      : runs.filter((r) => r.finalStatus === filterStatus);

  return (
    <section id="run-records" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Section Header */}
      <div className="mb-8 b-brutal bg-[#09090B] p-6 sm:p-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 b-brutal-b">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <Database size={15} className="text-accent" />
              <span>PERMANENT AGENT AUDIT TRAIL</span>
              <span>/</span>
              <span className="text-accent font-bold">STRUCTURED LIFECYCLE LEDGER</span>
            </div>
            <h2 className="font-display font-black text-3xl sm:text-5xl text-foreground tracking-tighter uppercase">
              RUN RECORDS
            </h2>
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono">
            {['ALL', 'COMPLETED', 'BLOCKED'].map((st) => (
              <button
                key={st}
                onClick={() => {
                  terminalAudio.playClick(900);
                  setFilterStatus(st);
                }}
                className={`px-3 py-1.5 b-brutal uppercase font-bold transition-colors ${
                  filterStatus === st
                    ? 'bg-accent text-accent-foreground border-accent'
                    : 'bg-muted-surface text-muted-foreground hover:text-foreground'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <p className="pt-4 text-sm text-muted-foreground font-sans max-w-3xl">
          Every meaningful agent operation creates an immutable Run Record capturing the complete causal sequence: 
          information ingestion, NLP scoring, proxy comparison, dislocation detection, risk evaluation, paper execution, and subsequent cash market validation.
        </p>
      </div>

      {/* Table of Runs */}
      <div className="b-brutal overflow-x-auto bg-[#09090B]">
        <table className="w-full text-left text-xs font-mono">
          <thead className="bg-muted-surface b-brutal-b text-muted-foreground">
            <tr>
              <th className="p-3">RUN ID</th>
              <th className="p-3">TIME</th>
              <th className="p-3">TRIGGER</th>
              <th className="p-3">ASSET</th>
              <th className="p-3">IMPACT</th>
              <th className="p-3">OPP SCORE</th>
              <th className="p-3">EXP MOVE</th>
              <th className="p-3">RISK GATE</th>
              <th className="p-3">STATUS</th>
              <th className="p-3 text-right">ACTIONS</th>
            </tr>
          </thead>
          <tbody className="divide-y-2 divide-[#3F3F46]">
            {filtered.map((run) => {
              const isPositive = run.expectedMove >= 0;

              return (
                <tr
                  key={run.id}
                  className="hover:bg-muted-surface/40 transition-colors group"
                >
                  <td className="p-3 font-bold text-accent">#{run.id}</td>
                  <td className="p-3 text-muted-foreground">{run.timeStr.split(' ')[0]}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 b-brutal bg-muted-surface text-[10px] text-muted-foreground uppercase font-bold">
                      {run.trigger}
                    </span>
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 bg-white text-black font-display font-black text-xs">
                      {run.primaryAsset}
                    </span>
                  </td>
                  <td className="p-3 font-bold text-foreground">{run.impactScore}</td>
                  <td className="p-3 font-black text-accent">{run.opportunityScore}</td>
                  <td
                    className={`p-3 font-black ${
                      isPositive ? 'text-accent' : 'text-red-400'
                    }`}
                  >
                    {run.expectedMove >= 0 ? `+${run.expectedMove}%` : `${run.expectedMove}%`}
                  </td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold ${
                        run.riskStatus === 'PASSED'
                          ? 'bg-accent text-accent-foreground'
                          : 'bg-red-500 text-white'
                      }`}
                    >
                      {run.riskStatus}
                    </span>
                  </td>
                  <td className="p-3 text-muted-foreground">{run.finalStatus}</td>
                  <td className="p-3 text-right space-x-2 whitespace-nowrap">
                    <button
                      onClick={() => {
                        terminalAudio.playClick(1000);
                        onSelectRun(run);
                      }}
                      className="px-2.5 py-1 bg-accent text-accent-foreground font-display font-black text-[11px] tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-colors"
                      title="Replay step-by-step lifecycle"
                    >
                      <Play size={10} className="inline mr-1" fill="currentColor" />
                      REPLAY
                    </button>
                    <button
                      onClick={() => {
                        terminalAudio.playClick();
                        onCompareRuns(run);
                      }}
                      className="px-2 py-1 b-brutal bg-muted-surface text-muted-foreground hover:text-foreground text-[11px] font-mono font-bold transition-colors"
                      title="Compare with another run"
                    >
                      <ArrowLeftRight size={11} className="inline" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
};
