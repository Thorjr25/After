import React, { useState, useEffect } from 'react';
import { X, Cpu, Zap, CheckCircle2, AlertTriangle, ArrowRight, ShieldCheck, Play, Key, RefreshCw } from 'lucide-react';
import { aiService, SystemAiStatus, AnalyzeEventPayload } from '../../services/aiService';
import { CompleteAfterAnalysisResult } from '../../../server/ai/analyzer';
import { terminalAudio } from '../../services/audioService';
import { runStore } from '../../services/runStore';
import { RunRecord } from '../../types/after';

interface LiveAiAnalyzerModalProps {
  initialPayload: AnalyzeEventPayload | null;
  onClose: () => void;
  onRunCreated: (run: RunRecord) => void;
  onOpenConfig: () => void;
}

export const LiveAiAnalyzerModal: React.FC<LiveAiAnalyzerModalProps> = ({
  initialPayload,
  onClose,
  onRunCreated,
  onOpenConfig,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isProcessing, setIsProcessing] = useState<boolean>(true);
  const [analysisResult, setAnalysisResult] = useState<CompleteAfterAnalysisResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [aiStatus, setAiStatus] = useState<SystemAiStatus>(aiService.getStatus());

  const processingSteps = [
    'INGESTING INFORMATION',
    'CLASSIFYING EVENT',
    'IDENTIFYING ASSETS',
    'ASSESSING IMPACT',
    'CHECKING RELATED MARKETS',
    'BUILDING THESIS',
    'RUNNING RISK CHECK',
    'RUN COMPLETE'
  ];

  useEffect(() => {
    const unsub = aiService.subscribe((st) => setAiStatus(st));
    return unsub;
  }, []);

  useEffect(() => {
    if (!initialPayload) return;

    let isMounted = true;
    setIsProcessing(true);
    setCurrentStepIndex(0);
    setErrorMsg(null);
    setAnalysisResult(null);

    // Realistic step progression while awaiting server response
    const stepTimer = setInterval(() => {
      setCurrentStepIndex((prev) => {
        if (prev < 5) return prev + 1;
        return prev;
      });
    }, 450);

    // Call server-side LLM endpoint
    aiService.analyzeEvent(initialPayload)
      .then((res) => {
        if (!isMounted) return;
        clearInterval(stepTimer);

        if (res.success && res.data) {
          setCurrentStepIndex(6);
          setTimeout(() => {
            if (!isMounted) return;
            setCurrentStepIndex(7);
            setIsProcessing(false);
            setAnalysisResult(res.data!);
            terminalAudio.playSignalAlert();

            // Commit generated run record to local store
            const record = res.data!.runRecord as unknown as RunRecord;
            runStore.addRunRecord(record);
          }, 400);
        } else {
          setIsProcessing(false);
          setErrorMsg(res.error || 'AI ANALYSIS UNAVAILABLE: AFTER could not reach the reasoning model. Market data remains available, but no AI interpretation was generated.');
          terminalAudio.playRiskBlocked();
        }
      })
      .catch((err) => {
        if (!isMounted) return;
        clearInterval(stepTimer);
        setIsProcessing(false);
        setErrorMsg(`AI ANALYSIS UNAVAILABLE: ${err.message}. Market data remains available, but no AI interpretation was generated.`);
        terminalAudio.playRiskBlocked();
      });

    return () => {
      isMounted = false;
      clearInterval(stepTimer);
    };
  }, [initialPayload]);

  if (!initialPayload) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-none"
      onClick={() => {
        if (!isProcessing) {
          terminalAudio.playClick(600);
          onClose();
        }
      }}
    >
      <div
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto b-brutal bg-[#09090B] p-6 sm:p-8 text-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="flex items-start justify-between pb-4 b-brutal-b gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-muted-foreground mb-1">
              <span className={`px-2 py-0.5 b-brutal font-black ${aiStatus.configured ? 'bg-accent text-accent-foreground' : 'bg-amber-400 text-black'}`}>
                {aiStatus.configured ? `REAL AI: ${aiStatus.provider.toUpperCase()} (${aiStatus.model})` : 'DEMO MODE (API KEY UNCONFIGURED)'}
              </span>
              <span>•</span>
              <span className="text-foreground font-bold">REASONING PIPELINE</span>
            </div>
            <h2 className="font-display font-black text-xl sm:text-3xl uppercase tracking-tight">
              {initialPayload.headline}
            </h2>
          </div>

          {!isProcessing && (
            <button
              onClick={() => {
                terminalAudio.playClick(600);
                onClose();
              }}
              className="p-2 b-brutal bg-muted-surface hover:bg-accent hover:text-accent-foreground transition-colors shrink-0"
              aria-label="Close modal"
            >
              <X size={20} />
            </button>
          )}
        </div>

        {/* Processing Sequence Indicator */}
        {isProcessing && (
          <div className="py-8 space-y-6">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-muted-foreground uppercase">
                AUTHENTIC REASONING STAGE: {processingSteps[currentStepIndex]}
              </span>
              <span className="text-accent font-bold">
                {Math.round(((currentStepIndex + 1) / processingSteps.length) * 100)}%
              </span>
            </div>

            {/* Step Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
              {processingSteps.map((st, i) => (
                <div
                  key={st}
                  className={`p-2.5 b-brutal text-center font-bold transition-all ${
                    currentStepIndex === i
                      ? 'bg-accent text-accent-foreground border-accent scale-105'
                      : i < currentStepIndex
                      ? 'bg-muted-surface text-foreground'
                      : 'bg-transparent text-zinc-700'
                  }`}
                >
                  <span className="text-[10px] block opacity-75">STAGE 0{i + 1}</span>
                  <span className="text-[11px] block truncate">{st}</span>
                </div>
              ))}
            </div>

            <div className="p-6 b-brutal bg-muted-surface/30 flex items-center space-x-4">
              <Cpu size={28} className="text-accent animate-spin shrink-0" />
              <div>
                <span className="text-xs font-mono text-accent font-bold uppercase block">
                  SERVER-SIDE LLM REASONING IN PROGRESS...
                </span>
                <p className="text-sm font-sans text-muted-foreground mt-0.5">
                  Sending unstructured event payload to {aiStatus.provider} ({aiStatus.model}). Parsing causal implications, extracting asset exposure, and generating structured JSON response.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Error State */}
        {!isProcessing && errorMsg && (
          <div className="py-8 space-y-6">
            <div className="p-6 b-brutal border-red-500 bg-red-950/20 text-red-300 space-y-3">
              <div className="flex items-center space-x-3">
                <AlertTriangle size={24} className="text-red-400 shrink-0" />
                <h3 className="font-display font-black text-xl uppercase">
                  AI ANALYSIS UNAVAILABLE
                </h3>
              </div>
              <p className="text-sm font-mono leading-relaxed">
                {errorMsg}
              </p>
            </div>

            <div className="p-4 b-brutal bg-muted-surface flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs font-mono">
              <div>
                <span className="font-bold text-foreground block">WANT TO ACTIVATE REAL LLM REASONING?</span>
                <span className="text-muted-foreground">Configure your Gemini, OpenAI, or Groq API key in system telemetry or in your .env file.</span>
              </div>
              <button
                onClick={() => {
                  terminalAudio.playClick(1000);
                  onOpenConfig();
                }}
                className="px-4 py-2.5 bg-accent text-accent-foreground font-display font-black tracking-wider b-brutal border-accent hover:bg-white hover:text-black shrink-0 flex items-center space-x-2"
              >
                <Key size={14} />
                <span>CONFIGURE API KEY</span>
              </button>
            </div>

            <div className="flex justify-end pt-4">
              <button
                onClick={() => {
                  terminalAudio.playClick(600);
                  onClose();
                }}
                className="px-5 py-2.5 b-brutal bg-muted-surface text-xs font-mono font-bold hover:text-foreground"
              >
                CLOSE
              </button>
            </div>
          </div>
        )}

        {/* Success State: Real AI Structured Intelligence Result */}
        {!isProcessing && analysisResult && (
          <div className="py-6 space-y-6">
            {/* Real AI Verification Badge */}
            <div className="p-3 b-brutal bg-accent text-accent-foreground flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono font-bold">
              <div className="flex items-center space-x-2">
                <CheckCircle2 size={16} />
                <span>REAL LLM INFERENCE COMPLETED VIA {analysisResult.modelProvider.toUpperCase()} ({analysisResult.modelName})</span>
              </div>
              <span className="bg-black text-accent px-2 py-0.5">
                RUN RECORD: #{analysisResult.runRecord.id}
              </span>
            </div>

            {/* AI Scores Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3.5 b-brutal bg-muted-surface">
                <span className="text-muted-foreground uppercase text-[10px] block">Impact Score</span>
                <span className="font-display font-black text-3xl sm:text-4xl text-accent block mt-0.5">
                  {analysisResult.llmOutput.impact_score} <span className="text-xs font-mono text-muted-foreground">/ 100</span>
                </span>
              </div>
              <div className="p-3.5 b-brutal bg-muted-surface">
                <span className="text-muted-foreground uppercase text-[10px] block">Surprise Score</span>
                <span className="font-display font-black text-3xl sm:text-4xl text-foreground block mt-0.5">
                  {analysisResult.llmOutput.surprise_score} <span className="text-xs font-mono text-muted-foreground">/ 100</span>
                </span>
              </div>
              <div className="p-3.5 b-brutal bg-muted-surface">
                <span className="text-muted-foreground uppercase text-[10px] block">AI Confidence</span>
                <span className="font-display font-black text-3xl sm:text-4xl text-foreground block mt-0.5">
                  {analysisResult.llmOutput.confidence_score}%
                </span>
              </div>
              <div className="p-3.5 b-brutal bg-muted-surface">
                <span className="text-muted-foreground uppercase text-[10px] block">Direction Bias</span>
                <span className={`font-display font-black text-2xl uppercase block mt-1 ${
                  analysisResult.llmOutput.direction === 'bullish' ? 'text-accent' :
                  analysisResult.llmOutput.direction === 'bearish' ? 'text-red-400' : 'text-foreground'
                }`}>
                  {analysisResult.llmOutput.direction}
                </span>
              </div>
            </div>

            {/* Asset Exposure & Structured Summary */}
            <div className="p-5 b-brutal bg-muted-surface/30 space-y-3">
              <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
                <span className="text-muted-foreground">PRIMARY ASSET:</span>
                <span className="px-2.5 py-0.5 bg-white text-black font-display font-black text-sm">
                  {analysisResult.llmOutput.primary_asset}
                </span>
                <span className="text-muted-foreground ml-3">RELATED EXPOSURES:</span>
                {analysisResult.llmOutput.related_assets.map((a) => (
                  <span key={a} className="px-2 py-0.5 b-brutal bg-muted-surface font-bold text-foreground">
                    {a}
                  </span>
                ))}
              </div>

              <p className="text-sm font-sans text-foreground leading-relaxed pt-1">
                {analysisResult.llmOutput.event_summary}
              </p>
            </div>

            {/* Expected Reaction vs Deterministic Dislocation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 b-brutal bg-muted-surface space-y-2">
                <span className="text-xs font-mono text-muted-foreground uppercase block font-bold">
                  EXPECTED MOVE (DETERMINISTIC FORECAST)
                </span>
                <span className={`font-display font-black text-3xl block ${
                  analysisResult.deterministicCalculations.expectedMovePercent >= 0 ? 'text-accent' : 'text-red-400'
                }`}>
                  {analysisResult.deterministicCalculations.expectedMovePercent >= 0 ? `+` : ``}
                  {analysisResult.deterministicCalculations.expectedMovePercent}%
                </span>
                <p className="text-xs text-muted-foreground font-sans">
                  {analysisResult.llmOutput.expected_move_reason}
                </p>
              </div>

              <div className="p-5 b-brutal bg-accent text-accent-foreground space-y-2">
                <span className="text-xs font-mono uppercase block font-bold">
                  INFORMATION PRICING DISLOCATION: {analysisResult.deterministicCalculations.dislocationLevel}
                </span>
                <span className="font-display font-black text-3xl block">
                  +{analysisResult.deterministicCalculations.dislocationSpreadPercent}% SPREAD
                </span>
                <p className="text-xs font-sans font-medium">
                  {analysisResult.deterministicCalculations.dislocationSummary}
                </p>
              </div>
            </div>

            {/* Key Drivers & Invalidations */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              <div className="p-4 b-brutal bg-[#18181B] space-y-2">
                <span className="text-accent font-bold uppercase block">KEY CAUSAL DRIVERS:</span>
                <ul className="space-y-1 text-muted-foreground font-sans list-disc list-inside">
                  {analysisResult.llmOutput.key_drivers.map((kd, idx) => (
                    <li key={idx}><strong className="text-foreground">{kd}</strong></li>
                  ))}
                </ul>
              </div>

              <div className="p-4 b-brutal bg-[#18181B] space-y-2">
                <span className="text-red-400 font-bold uppercase block">WHAT COULD INVALIDATE THIS:</span>
                <ul className="space-y-1 text-muted-foreground font-sans list-disc list-inside">
                  {analysisResult.llmOutput.invalidations.map((inv, idx) => (
                    <li key={idx}><strong className="text-foreground">{inv}</strong></li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Footer Action Buttons */}
            <div className="pt-4 b-brutal-t flex flex-wrap items-center justify-between gap-3">
              <button
                onClick={() => {
                  terminalAudio.playClick(600);
                  onClose();
                }}
                className="px-5 py-2.5 b-brutal bg-muted-surface text-xs font-mono font-bold hover:text-foreground"
              >
                RETURN TO TERMINAL
              </button>

              <button
                onClick={() => {
                  terminalAudio.playClick(1000);
                  const runRec = analysisResult.runRecord as unknown as RunRecord;
                  onRunCreated(runRec);
                }}
                className="flex items-center space-x-2 px-6 py-3 bg-accent text-accent-foreground font-display font-black text-xs sm:text-sm tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all"
              >
                <ShieldCheck size={16} />
                <span>VIEW RUN RECORD & TIMELINE</span>
                <ArrowRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
