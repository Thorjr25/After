# AFTER®

> **“THE MARKET CLOSES. INFORMATION DOESN’T.”**
>
> AI-Powered After-Hours Information Pricing Agent for U.S. Equities & Tokenized-Equity Environments.

---

## ⚡ Overview

Traditional U.S. equity markets trade on rigid schedules. Global information, company earnings, SEC filings, central bank speeches, macro releases, Asian market moves, and 24/7 tokenized perpetual markets do not.

**AFTER** is an after-hours financial information intelligence terminal styled as an editorial kinetic poster meets a Bloomberg terminal, AI command center, and quantitative research lab.

It continuously:
1. **Ingests & Interprets** breaking information arriving outside regular trading hours (16:00–09:30 EST).
2. **Quantifies & Scores** fundamental impact, surprise, relevance, and AI certainty via server-side LLM inference.
3. **Cross-References** live 24/7 proxies (CME E-mini futures, sector ETFs, Asian session ADRs, and tokenized perpetuals).
4. **Isolates Asymmetric Pricing Gaps** (difference between expected fundamental repricing and extended-hours market drift).
5. **Audits Pre-Trade Safety** via an automated 8-point zero-trust risk gate.
6. **Simulates Paper Orders** and permanently commits the entire microsecond reasoning sequence to an immutable, replayable **Run Record**.

---

## 🚀 Key Features

- **Live After-Hours Terminal:** Constantly streaming event feed with category filters (Earnings, Macro, SEC, Geopolitical, Analyst, Corporate).
- **Real-Time Ingestion Desk:** Ingest and parse custom breaking news headlines or SEC 8-K filings on the fly.
- **Genuine Server-Side LLM Intelligence:** Supports Google Gemini (`gemini-2.5-flash`), OpenAI (`gpt-4o`), Groq (`llama-3.3`), and Anthropic with structured schema validation.
- **Opportunity Radar:** Giant numbered ranking (01, 02, 03...) surfacing asymmetric alpha opportunities with transparent *“Why Long/Short?”* and *“What Could Invalidate This?”* explainability.
- **Cognitive Storytelling (“HOW AFTER THINKS”):** 7 interactive stacked stages showcasing the complete causal reasoning chain.
- **Catalyst Calendar:** Editorial chronological timeline tracking overnight monetary speeches, Asian opens, and pre-market economic releases with live countdowns.
- **Pre-Trade 8-Point Risk Gate:** Evaluates book depth liquidity, volatility bounds, conflict checks, and hard structural stop-loss floors before order dispatch.
- **Interactive Run Replay & Comparison:** Scrub step-by-step through any past agent run or audit model accuracy side-by-side against post-market cash cross convergence.
- **Brutalist Kinetic Typography System:** Strict adherence to `#09090B` background, `#FAFAFA` text, `#DFE104` acid yellow accents, 2px structural borders, 0px radius geometry, Space Grotesk display typography, and active dual marquees.

---

## 🛠️ Tech Stack

- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS, Framer Motion, Lucide Icons
- **Backend / Middleware:** Node.js HTTP Connect Middleware (built into Vite dev & preview servers)
- **Audio:** Web Audio API Procedural Synthesizer (zero external audio assets)
- **AI / LLM Layer:** Multi-provider server-side client (Gemini / OpenAI / Groq / Anthropic)

---

## 💻 Quick Start

### 1. Clone & Install
```bash
git clone https://github.com/<your-username>/after.git
cd after
npm install
```

### 2. Configure Environment (Optional for Real AI mode)
Copy the example environment file:
```bash
cp .env.example .env
```
Edit `.env` and provide your API key:
```env
AI_PROVIDER=gemini
AI_MODEL=gemini-2.5-flash
AI_API_KEY=your_gemini_api_key_here
```
*(Note: If no API key is set, the terminal seamlessly runs in **Demo Mode** with realistic synthetic data).*

### 3. Run Development Server
```bash
npm run dev
```
Open **`http://localhost:3000/`** in your browser.

### 4. Build for Production
```bash
npm run build
npm run preview
```

---

## 🔒 Security & Safety Policy

- **No Key Leaks:** API keys are processed strictly server-side and never exposed to client bundles or browser logs.
- **Paper Trading Only:** Primary execution runs in simulated non-custodial paper mode with mandatory risk gating.

---

## 📄 License

MIT License. © 2026 AFTER Intelligence Agents Inc.
