import React, { useState } from 'react';
import { X, Play, CheckCircle2, ShieldCheck, ArrowRight, DollarSign, Lock } from 'lucide-react';
import { Opportunity, AfterEvent, RunRecord } from '../../types/after';
import { terminalAudio } from '../../services/audioService';
import { runStore } from '../../services/runStore';

interface PaperExecutionModalProps {
  target: Opportunity | AfterEvent | null;
  onClose: () => void;
  onRunCreated: (run: RunRecord) => void;
}

export const PaperExecutionModal: React.FC<PaperExecutionModalProps> = ({
  target,
  onClose,
  onRunCreated,
}) => {
  const [positionSize, setPositionSize] = useState<number>(10000);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [executedRun, setExecutedRun] = useState<RunRecord | null>(null);

  if (!target) return null;

  const symbol = 'symbol' in target ? target.symbol : target.asset;
  const name = 'name' in target ? target.name : target.assetName;
  const action = 'primaryAction' in target ? target.primaryAction : (target.expectedReaction?.direction === 'NEGATIVE' ? 'SHORT' : 'LONG');
  const expectedMove = 'expectedMove' in target ? target.expectedMove : (target.expectedReaction?.expectedMove || 4.1);
  const currentPrice = 'currentPrice' in target ? target.currentPrice : 228.40;
  const stopLossPrice = action === 'LONG' ? (currentPrice * 0.983).toFixed(2) : (currentPrice * 1.025).toFixed(2);
  const takeProfitPrice = action === 'LONG' ? (currentPrice * 1.041).toFixed(2) : (currentPrice * 0.962).toFixed(2);

  const handleExecute = () => {
    setIsExecuting(true);
    terminalAudio.playClick(1200);

    setTimeout(() => {
      terminalAudio.playSignalAlert();

      const newRunId = `AF-${Math.floor(10000 + Math.random() * 90000).toString().slice(0, 5)}`;
      const now = new Date();
      const timeStr = now.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' EST';

      const newRun: RunRecord = {
        id: newRunId,
        timestamp: Date.now(),
        timeStr,
        trigger: 'PAPER_EXECUTION',
        marketState: 'US CASH CLOSED // OVERNIGHT ELECTRONIC ACTIVE',
        eventId: target.id,
        eventHeadline: 'headline' in target ? target.headline : `Manual paper execution on ${symbol}`,
        primaryAsset: symbol,
        relatedAssets: 'relatedAssets' in target ? target.relatedAssets : ['QQQ', 'XLK'],
        impactScore: 'impact' in target ? target.impact : 91,
        surpriseScore: 'surprise' in target ? target.surprise : 82,
        relevanceScore: 'relevance' in target ? target.relevance : 96,
        confidenceScore: 'confidence' in target ? target.confidence : 88,
        expectedMove,
        observedReferenceMove: 1.1,
        currentImpliedMove: 0.8,
        detectedDislocation: '+0.6% to +0.9%',
        opportunityScore: 'opportunityScore' in target ? target.opportunityScore : 93,
        riskLevel: 'MEDIUM',
        riskStatus: 'PASSED',
        riskChecks: [
          { name: 'ECN Depth', status: 'PASSED', value: '$42M', threshold: '>$15M', notes: 'Liquid' },
          { name: 'Confidence', status: 'PASSED', value: '88%', threshold: '>=75%', notes: 'Valid' },
          { name: 'Stop Defined', status: 'PASSED', value: `$${stopLossPrice}`, threshold: 'Required', notes: 'Enforced' }
        ],
        agentDecision: `EXECUTE PAPER ${action} ${symbol}. Sized at $${positionSize.toLocaleString()} USD. Dislocation edge detected.`,
        executionMode: 'PAPER',
        executionDetails: {
          action: action as 'LONG' | 'SHORT',
          symbol,
          entryPrice: currentPrice,
          sizeUSD: positionSize,
          stopLoss: parseFloat(stopLossPrice),
          takeProfit: parseFloat(takeProfitPrice),
        },
        finalStatus: 'COMPLETED',
        outcome: {
          postEventMove: expectedMove * 0.9,
          pnlPercent: expectedMove * 0.9,
          accuracy: 'CONFIRMED',
          notes: 'Simulated position logged. Real-time convergence tracking initialized.'
        },
        steps: [
          { stepIndex: 1, timeStr, title: 'USER TRIGGER RECEIVED', detail: `Manual paper execution order dispatched for ${action} ${symbol}.`, phase: 'INPUT' },
          { stepIndex: 2, timeStr, title: 'RISK GATE RE-VERIFICATION', detail: 'Real-time liquidity and margin constraints re-validated.', phase: 'DECISION' },
          { stepIndex: 3, timeStr, title: 'SIMULATED ORDER FILLED', detail: `Paper Fill: ${action} ${(positionSize / currentPrice).toFixed(2)} ${symbol} @ $${currentPrice.toFixed(2)}.`, phase: 'ACTION' },
          { stepIndex: 4, timeStr, title: 'RUN RECORD SERIALIZED', detail: `Immutable Run Record ${newRunId} committed to persistent state.`, phase: 'OUTCOME' }
        ]
      };

      runStore.addRunRecord(newRun);
      setExecutedRun(newRun);
      setIsExecuting(false);
    }, 1200);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85"
      onClick={() => {
        if (!isExecuting) {
          terminalAudio.playClick(600);
          onClose();
        }
      }}
    >
      <div
        className="relative w-full max-w-2xl b-brutal bg-[#09090B] p-6 sm:p-8 text-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-start justify-between pb-4 b-brutal-b gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <span className="w-2 h-2 bg-accent inline-block" />
              <span>SIMULATED PAPER EXECUTION DESK</span>
              <span>/</span>
              <span className="text-accent font-bold">NON-CUSTODIAL PAPER MODE</span>
            </div>
            <h2 className="font-display font-black text-2xl sm:text-3xl uppercase tracking-tight">
              {action} {symbol} — ${currentPrice.toFixed(2)}
            </h2>
          </div>

          {!isExecuting && (
            <button
              onClick={() => {
                terminalAudio.playClick(600);
                onClose();
              }}
              className="p-2 b-brutal bg-muted-surface hover:bg-accent hover:text-accent-foreground transition-colors shrink-0"
              aria-label="Close modal"
            >
              <X size={20} />
            </button>
          )}
        </div>

        {/* Execution State Display */}
        {executedRun ? (
          <div className="py-8 text-center space-y-6">
            <div className="inline-flex p-4 b-brutal bg-accent text-accent-foreground">
              <CheckCircle2 size={40} />
            </div>

            <div>
              <span className="text-xs font-mono text-muted-foreground uppercase block">
                EXECUTION CONFIRMED
              </span>
              <h3 className="font-display font-black text-2xl sm:text-3xl uppercase mt-1">
                PAPER ORDER SUBMITTED
              </h3>
              <p className="text-sm font-mono text-accent mt-1 font-bold">
                RUN RECORD ID: #{executedRun.id}
              </p>
            </div>

            <div className="p-4 b-brutal bg-muted-surface text-left font-mono text-xs space-y-1 max-w-md mx-auto">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Action:</span>
                <span className="font-bold text-foreground">{executedRun.executionDetails.action} {symbol}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fill Price:</span>
                <span className="font-bold text-foreground">${executedRun.executionDetails.entryPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Notional Size:</span>
                <span className="font-bold text-foreground">${executedRun.executionDetails.sizeUSD.toLocaleString()} USD</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Hard Stop Loss:</span>
                <span className="font-bold text-red-400">${executedRun.executionDetails.stopLoss.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Take Profit:</span>
                <span className="font-bold text-accent">${executedRun.executionDetails.takeProfit.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
              <button
                onClick={() => {
                  terminalAudio.playClick(1000);
                  onRunCreated(executedRun);
                }}
                className="px-6 py-3 bg-accent text-accent-foreground font-display font-black text-xs sm:text-sm tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all flex items-center space-x-2"
              >
                <span>OPEN RUN TIMELINE & REPLAY</span>
                <ArrowRight size={15} />
              </button>

              <button
                onClick={() => {
                  terminalAudio.playClick(600);
                  onClose();
                }}
                className="px-5 py-3 b-brutal bg-muted-surface text-xs font-mono font-bold hover:text-foreground"
              >
                CLOSE DESK
              </button>
            </div>
          </div>
        ) : (
          <div className="py-6 space-y-6">
            {/* Architecture Separation Alert: SIGNAL vs ACTION */}
            <div className="p-3.5 b-brutal bg-muted-surface text-xs font-mono flex items-center justify-between">
              <div>
                <span className="text-muted-foreground uppercase text-[10px] block">Execution Guardrail</span>
                <span className="font-bold text-foreground">AI Signal ≠ Automated Live Trade</span>
              </div>
              <span className="px-2 py-1 bg-[#18181B] text-accent text-[10px] font-bold b-brutal">
                PAPER DESK ONLY
              </span>
            </div>

            {/* Position Size Selector */}
            <div>
              <label className="text-xs font-mono text-muted-foreground uppercase block mb-2 font-bold">
                SELECT POSITION SIZE (SIMULATED USD CAPITAL):
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[1000, 5000, 10000, 25000].map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => {
                      terminalAudio.playClick(850);
                      setPositionSize(size);
                    }}
                    className={`py-2.5 b-brutal font-mono text-xs font-bold transition-all ${
                      positionSize === size
                        ? 'bg-accent text-accent-foreground border-accent font-black'
                        : 'bg-muted-surface text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    ${size.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>

            {/* Order Parameters Grid */}
            <div className="grid grid-cols-2 gap-3 font-mono text-xs">
              <div className="p-3 b-brutal bg-muted-surface">
                <span className="text-muted-foreground text-[10px] uppercase block">Expected Reaction</span>
                <span className="font-display font-black text-xl text-accent block mt-1">
                  {expectedMove >= 0 ? `+${expectedMove}%` : `${expectedMove}%`}
                </span>
              </div>

              <div className="p-3 b-brutal bg-muted-surface">
                <span className="text-muted-foreground text-[10px] uppercase block">Hard Stop Floor</span>
                <span className="font-display font-black text-xl text-red-400 block mt-1">
                  ${stopLossPrice}
                </span>
              </div>
            </div>

            {/* Submit Paper Order Button */}
            <div className="pt-4 b-brutal-t flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  terminalAudio.playClick(600);
                  onClose();
                }}
                className="px-4 py-2.5 b-brutal bg-muted-surface text-xs font-mono font-bold hover:text-foreground"
              >
                ABORT
              </button>

              <button
                type="button"
                disabled={isExecuting}
                onClick={handleExecute}
                className="flex items-center space-x-2 px-6 py-3 bg-accent text-accent-foreground font-display font-black text-sm tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all active:scale-[0.98] disabled:opacity-50"
              >
                {isExecuting ? (
                  <>
                    <span className="w-3 h-3 border-2 border-black border-t-transparent animate-spin inline-block mr-2" />
                    <span>ROUTING PAPER ORDER...</span>
                  </>
                ) : (
                  <>
                    <Play size={16} fill="currentColor" />
                    <span>EXECUTE PAPER TRADE (${positionSize.toLocaleString()})</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
