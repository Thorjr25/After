import React, { useState } from 'react';
import { AfterEvent, EventCategory } from '../../types/after';
import { Filter, Zap, ArrowUpRight, Cpu } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';
import { BreakingNewsInput } from './BreakingNewsInput';
import { AnalyzeEventPayload } from '../../services/aiService';

interface LiveTerminalProps {
  events: AfterEvent[];
  isRealAiActive: boolean;
  onSelectEvent: (event: AfterEvent) => void;
  onAnalyzeWithAi: (payload: AnalyzeEventPayload) => void;
}

export const LiveTerminal: React.FC<LiveTerminalProps> = ({
  events,
  isRealAiActive,
  onSelectEvent,
  onAnalyzeWithAi,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const categories: ('ALL' | EventCategory)[] = [
    'ALL',
    'EARNINGS',
    'MACRO',
    'SEC',
    'GEOPOLITICAL',
    'ANALYST',
    'CORPORATE',
  ];

  const filteredEvents =
    selectedCategory === 'ALL'
      ? events
      : events.filter((e) => e.category === selectedCategory);

  return (
    <section id="terminal" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Terminal Title & Header */}
      <div className="mb-8 b-brutal bg-[#09090B] p-6 sm:p-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 b-brutal-b">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <span className="w-2 h-2 bg-red-500 animate-ping inline-block mr-1" />
              <span>US CASH EQUITIES: CLOSED</span>
              <span>/</span>
              <span className="text-accent font-bold">
                {isRealAiActive ? 'REAL LLM INFERENCE ONLINE' : 'OVERNIGHT SURVEILLANCE RUNNING (DEMO MODE)'}
              </span>
            </div>
            <h2 className="font-display font-black text-3xl sm:text-5xl text-foreground tracking-tighter uppercase">
              LIVE AFTER-HOURS TERMINAL
            </h2>
          </div>

          <div className="flex items-center space-x-3 text-xs font-mono">
            <span className="text-muted-foreground">SYSTEM MODE:</span>
            <span className={`px-2.5 py-1 font-black font-display tracking-wider ${
              isRealAiActive ? 'bg-accent text-accent-foreground' : 'bg-muted-surface text-foreground b-brutal'
            }`}>
              {isRealAiActive ? 'REAL AI MODE' : 'DEMO MODE'}
            </span>
          </div>
        </div>

        {/* State Display Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-6 text-xs font-mono">
          <div className="p-4 b-brutal bg-muted-surface">
            <span className="text-muted-foreground uppercase block text-[10px]">Market Status</span>
            <span className="font-display font-black text-xl sm:text-2xl text-foreground block mt-1">
              CLOSED (EXTENDED)
            </span>
            <span className="text-[10px] text-muted-foreground block mt-1">NYSE / NASDAQ / BATS</span>
          </div>

          <div className="p-4 b-brutal bg-muted-surface">
            <span className="text-muted-foreground uppercase block text-[10px]">Active Events Ingested</span>
            <span className="font-display font-black text-xl sm:text-2xl text-accent block mt-1">
              17 OVERNIGHT
            </span>
            <span className="text-[10px] text-muted-foreground block mt-1">SEC, Wire & News Crawlers</span>
          </div>

          <div className="p-4 b-brutal bg-muted-surface">
            <span className="text-muted-foreground uppercase block text-[10px]">Potential Pricing Gaps</span>
            <span className="font-display font-black text-xl sm:text-2xl text-accent block mt-1">
              04 UNCONVERGED
            </span>
            <span className="text-[10px] text-muted-foreground block mt-1">Expected vs Implied spread</span>
          </div>

          <div className="p-4 b-brutal bg-muted-surface">
            <span className="text-muted-foreground uppercase block text-[10px]">Offshore Pricing Proxy</span>
            <span className="font-display font-black text-xl sm:text-2xl text-foreground block mt-1">
              $1.42B 24/7 PERPS
            </span>
            <span className="text-[10px] text-muted-foreground block mt-1">Active tokenized order book</span>
          </div>
        </div>
      </div>

      {/* Real-Time Breaking News Input Console */}
      <BreakingNewsInput
        isRealAiActive={isRealAiActive}
        onAnalyze={onAnalyzeWithAi}
      />

      {/* Category Filter Pills */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-4 mb-4 text-xs font-mono select-none">
        <span className="text-muted-foreground flex items-center pr-2 uppercase font-bold shrink-0">
          <Filter size={14} className="mr-1" /> Filter:
        </span>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => {
              terminalAudio.playClick(950);
              setSelectedCategory(cat);
            }}
            className={`px-3 py-1.5 b-brutal uppercase font-bold transition-all shrink-0 ${
              selectedCategory === cat
                ? 'bg-accent text-accent-foreground border-accent font-black'
                : 'bg-muted-surface text-muted-foreground hover:text-foreground hover:border-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Information Stream Feed Table / Cards */}
      <div className="b-brutal bg-[#09090B] divide-y-2 divide-[#3F3F46]">
        {filteredEvents.map((evt) => {
          const isPositive = evt.expectedReaction?.direction === 'POSITIVE';
          const isNegative = evt.expectedReaction?.direction === 'NEGATIVE';

          return (
            <div
              key={evt.id}
              className="p-5 sm:p-6 hover:bg-muted-surface/40 transition-colors group"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* Left: Timestamp, Ticker & Headline */}
                <div
                  className="flex-1 space-y-2 cursor-pointer"
                  onClick={() => {
                    terminalAudio.playClick(1050);
                    onSelectEvent(evt);
                  }}
                >
                  <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
                    <span className="text-muted-foreground">{evt.timeStr}</span>
                    <span className="text-[#3F3F46]">•</span>
                    <span className="px-2 py-0.5 b-brutal bg-muted-surface text-[10px] font-bold uppercase text-muted-foreground">
                      {evt.category}
                    </span>
                    <span className="px-2 py-0.5 bg-white text-black font-display font-black text-xs">
                      {evt.asset}
                    </span>
                    <span className="text-muted-foreground hidden sm:inline">{evt.assetName}</span>
                    {evt.status === 'DISLOCATED' && (
                      <span className="px-2 py-0.5 bg-accent text-accent-foreground text-[10px] font-mono font-black animate-pulse">
                        GAP DETECTED
                      </span>
                    )}
                  </div>

                  <h3 className="font-display font-bold text-lg sm:text-xl text-foreground group-hover:text-accent transition-colors leading-snug">
                    {evt.headline}
                  </h3>

                  <p className="text-xs sm:text-sm text-muted-foreground font-sans line-clamp-2 max-w-4xl">
                    {evt.fullSummary}
                  </p>
                </div>

                {/* Right: Scores, Real AI Button & Inspect Arrow */}
                <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 sm:gap-4 shrink-0 b-brutal-t lg:b-brutal-t-0 pt-3 lg:pt-0">
                  {/* Impact */}
                  <div className="text-right p-2.5 b-brutal bg-muted-surface min-w-[76px]">
                    <span className="block text-[9px] font-mono text-muted-foreground uppercase">Impact</span>
                    <span className="font-display font-black text-xl sm:text-2xl text-accent leading-none block mt-0.5">
                      {evt.impact}
                    </span>
                  </div>

                  {/* Expected Move */}
                  {evt.expectedReaction && (
                    <div className="text-right p-2.5 b-brutal bg-[#18181B] min-w-[96px]">
                      <span className="block text-[9px] font-mono text-muted-foreground uppercase">Exp Move</span>
                      <span
                        className={`font-display font-black text-xl sm:text-2xl leading-none block mt-0.5 ${
                          isPositive ? 'text-accent' : isNegative ? 'text-red-400' : 'text-foreground'
                        }`}
                      >
                        {evt.expectedReaction.expectedMove >= 0
                          ? `+${evt.expectedReaction.expectedMove}%`
                          : `${evt.expectedReaction.expectedMove}%`}
                      </span>
                    </div>
                  )}

                  {/* Real AI Analysis Button */}
                  <button
                    onClick={() => {
                      terminalAudio.playClick(1100);
                      onAnalyzeWithAi({
                        headline: evt.headline,
                        summary: evt.fullSummary,
                        source: evt.sources[0] || 'Wire Crawler',
                        category: evt.category,
                        primaryAssetHint: evt.asset
                      });
                    }}
                    className="flex items-center space-x-1 px-3 py-2 bg-accent text-accent-foreground font-display font-black text-xs tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-colors"
                    title="Send to Real LLM Reasoning Engine"
                  >
                    <Zap size={13} fill="currentColor" />
                    <span className="hidden sm:inline">ANALYZE WITH AI</span>
                    <span className="sm:hidden">AI</span>
                  </button>

                  {/* Inspect Details Arrow */}
                  <button
                    onClick={() => {
                      terminalAudio.playClick(1050);
                      onSelectEvent(evt);
                    }}
                    className="p-2 b-brutal bg-muted-surface group-hover:bg-accent group-hover:text-black transition-colors"
                    title="View details"
                  >
                    <ArrowUpRight size={18} />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
