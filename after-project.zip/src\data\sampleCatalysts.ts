import { Catalyst } from '../types/after';

export const SAMPLE_CATALYSTS: Catalyst[] = [
  {
    id: 'cat-001',
    timeStr: '19:15 EST',
    title: 'Fed Governor Waller Fireside Chat on Global Financial Stability',
    category: 'FED / MONETARY',
    expectedImportance: 'HIGH',
    affectedAssets: ['SPY', 'QQQ', 'TLT', 'USD/JPY'],
    status: 'IMMINENT',
    countdownMinutes: 24,
    description: 'Q&A at Institute of International Bankers. Markets sensitive to commentary regarding bank capital surcharges and December terminal rate probabilities.'
  },
  {
    id: 'cat-002',
    timeStr: '20:30 EST',
    title: 'Japan Household Spending & Real Cash Earnings YoY',
    category: 'MACRO / ASIA',
    affectedAssets: ['NIKKEI', 'USD/JPY', 'EWJ', 'DXJ'],
    expectedImportance: 'HIGH',
    status: 'UPCOMING',
    countdownMinutes: 99,
    description: 'Crucial gauge for Bank of Japan rate path. Sharp wage gains trigger carry-trade unwinding across global equity index futures.'
  },
  {
    id: 'cat-003',
    timeStr: '22:00 EST',
    title: 'China Caixin Manufacturing PMI Release (Overnight Print)',
    category: 'MACRO / CHINA',
    affectedAssets: ['FXI', 'KWEB', 'BABA', 'PDD', 'AAPL'],
    expectedImportance: 'CRITICAL',
    status: 'UPCOMING',
    countdownMinutes: 189,
    description: 'First official read on post-stimulus factory activity. Directly affects Greater China consumer electronics demand and supply chain confidence.'
  },
  {
    id: 'cat-004',
    timeStr: '23:30 EST',
    title: 'Tokyo Stock Exchange Cash Open & TSMC Taipei Auction',
    category: 'SESSION OPEN',
    affectedAssets: ['TSM', 'NVDA', 'ARM', 'ASML', 'SMH'],
    expectedImportance: 'CRITICAL',
    status: 'UPCOMING',
    countdownMinutes: 279,
    description: 'Live physical trading begins across Asian semiconductor heavyweights, providing real-time pricing confirmation for US tech after-hours moves.'
  },
  {
    id: 'cat-005',
    timeStr: '03:00 EST',
    title: 'European Cash Markets Open (DAX / FTSE / CAC)',
    category: 'SESSION OPEN',
    affectedAssets: ['TSLA', 'DAX', 'EWG', 'VOW3.DE'],
    expectedImportance: 'HIGH',
    status: 'UPCOMING',
    countdownMinutes: 489,
    description: 'European auto and industrial conglomerates open for cash execution, testing Tesla delivery downgrade contagion in German equity markets.'
  },
  {
    id: 'cat-006',
    timeStr: '08:30 EST',
    title: 'US Core CPI YoY & Retail Sales Advance',
    category: 'MACRO / US',
    affectedAssets: ['SPY', 'QQQ', 'IWM', 'TNX'],
    expectedImportance: 'CRITICAL',
    status: 'UPCOMING',
    countdownMinutes: 819,
    description: 'Primary tier-1 macroeconomic print determining equity index pre-market gap direction prior to 09:30 cash opening bell.'
  }
];
