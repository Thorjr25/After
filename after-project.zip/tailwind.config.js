/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#09090B',
        foreground: '#FAFAFA',
        muted: {
          surface: '#27272A',
          foreground: '#A1A1AA'
        },
        accent: {
          DEFAULT: '#DFE104',
          foreground: '#000000'
        },
        border: {
          DEFAULT: '#3F3F46',
          bright: '#52525B'
        }
      },
      fontFamily: {
        mono: ['"Space Grotesk"', 'monospace'],
        display: ['"Space Grotesk"', 'sans-serif'],
        sans: ['Inter', 'sans-serif'],
      },
      borderWidth: {
        '2': '2px',
        '3': '3px',
      },
      borderRadius: {
        none: '0px',
      },
      animation: {
        'marquee-fast': 'marquee 16s linear infinite',
        'marquee-slow': 'marquee 32s linear infinite',
        'pulse-subtle': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(0%)' },
          '100%': { transform: 'translateX(-50%)' },
        }
      }
    },
  },
  plugins: [],
}
