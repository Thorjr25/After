import React, { useState } from 'react';
import { X, ShieldCheck, ShieldAlert, AlertTriangle, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Opportunity, AfterEvent, RiskCheck } from '../../types/after';
import { terminalAudio } from '../../services/audioService';

interface RiskGateModalProps {
  target: Opportunity | AfterEvent | null;
  onClose: () => void;
  onProceedToExecution: (item: Opportunity | AfterEvent) => void;
}

export const RiskGateModal: React.FC<RiskGateModalProps> = ({
  target,
  onClose,
  onProceedToExecution,
}) => {
  if (!target) return null;

  const symbol = 'symbol' in target ? target.symbol : target.asset;
  const name = 'name' in target ? target.name : target.assetName;
  const isHighRisk = 'riskLevel' in target ? target.riskLevel === 'HIGH' : false;

  // Realistic 8-point check
  const checks: RiskCheck[] = [
    {
      name: '1. After-Hours Liquidity Depth',
      status: 'PASSED',
      value: '$42.4M Top 5 Levels',
      threshold: 'Min $15.0M',
      notes: 'Sufficient book depth on ECN electronic order books to prevent slippage.'
    },
    {
      name: '2. AI Information Confidence',
      status: 'PASSED',
      value: `${'confidence' in target ? target.confidence : 88}%`,
      threshold: '>= 75.0%',
      notes: 'Multi-model validation exceeds minimum certainty threshold.'
    },
    {
      name: '3. Historical Volatility Envelope',
      status: isHighRisk ? 'WARNING' : 'PASSED',
      value: isHighRisk ? '2.3x 30d ATR' : '1.4x 30d ATR',
      threshold: '< 2.5x ATR',
      notes: isHighRisk ? 'Elevated volatility requires 50% max position scaling.' : 'Expected move is within normal post-shock parameters.'
    },
    {
      name: '4. Information Conflict Check',
      status: 'PASSED',
      value: '0 Conflicting Sources',
      threshold: '0 Contradictions',
      notes: 'Unanimous reporting across primary SEC filings and news wires.'
    },
    {
      name: '5. Reference Proxy Confirmation',
      status: 'PASSED',
      value: 'Positive Correlation Confirmed',
      threshold: 'Same Sign Direction',
      notes: 'Nasdaq futures and sector ETF overnight prints corroborate thesis.'
    },
    {
      name: '6. Position Size Allocation Cap',
      status: 'PASSED',
      value: '$10,000 Paper Capital',
      threshold: 'Max $25,000',
      notes: 'Within single-issuer overnight limit.'
    },
    {
      name: '7. Max Portfolio Overnight Exposure',
      status: 'PASSED',
      value: '14.2% Total Capital',
      threshold: '<= 25.0%',
      notes: 'Sufficient portfolio margin headroom available.'
    },
    {
      name: '8. Hard Invalidation Stop Defined',
      status: 'PASSED',
      value: 'Structural Stop Enforced',
      threshold: 'Must Be Defined',
      notes: 'Automated exit trigger set at prior session VWAP floor.'
    }
  ];

  const allPassed = checks.every(c => c.status === 'PASSED' || c.status === 'WARNING');

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85"
      onClick={() => {
        terminalAudio.playClick(600);
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto b-brutal bg-[#09090B] p-6 sm:p-8 text-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-start justify-between pb-4 b-brutal-b gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <span>PRE-TRADE SAFETY GATE</span>
              <span>/</span>
              <span className="text-accent font-bold">{symbol} RISK ENGINE AUDIT</span>
            </div>
            <h2 className="font-display font-black text-2xl sm:text-3xl uppercase tracking-tight flex items-center gap-3">
              <span className="px-2.5 py-0.5 bg-accent text-accent-foreground">
                RISK CHECK: {allPassed ? 'PASSED' : 'BLOCKED'}
              </span>
              <span className="text-muted-foreground text-xl sm:text-2xl font-normal">
                {name}
              </span>
            </h2>
          </div>

          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="p-2 b-brutal bg-muted-surface hover:bg-accent hover:text-accent-foreground transition-colors shrink-0"
            aria-label="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Safety Gate Banner */}
        <div className="py-4">
          <p className="text-xs sm:text-sm text-muted-foreground font-sans">
            AFTER enforces an automated zero-trust risk policy before proposing or simulating any paper order. 
            All 8 quantitative safety constraints must be validated.
          </p>
        </div>

        {/* 8 Checks Table / List */}
        <div className="b-brutal divide-y-2 divide-[#3F3F46] my-4 text-xs font-mono">
          {checks.map((chk, i) => (
            <div key={i} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-muted-surface/20">
              <div className="flex items-start space-x-3">
                <span className="mt-0.5">
                  {chk.status === 'PASSED' ? (
                    <CheckCircle2 size={16} className="text-accent" />
                  ) : chk.status === 'WARNING' ? (
                    <AlertTriangle size={16} className="text-amber-400" />
                  ) : (
                    <ShieldAlert size={16} className="text-red-500" />
                  )}
                </span>
                <div>
                  <span className="font-bold text-foreground block">{chk.name}</span>
                  <span className="text-muted-foreground text-[11px] font-sans">{chk.notes}</span>
                </div>
              </div>

              <div className="flex items-center space-x-4 shrink-0 sm:text-right text-xs">
                <div>
                  <span className="text-muted-foreground text-[10px] uppercase block">Observed Value</span>
                  <span className="font-bold text-foreground">{chk.value}</span>
                </div>
                <div className="p-1.5 b-brutal bg-muted-surface text-center min-w-[70px]">
                  <span
                    className={`font-black uppercase text-[10px] ${
                      chk.status === 'PASSED'
                        ? 'text-accent'
                        : chk.status === 'WARNING'
                        ? 'text-amber-400'
                        : 'text-red-400'
                    }`}
                  >
                    {chk.status}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal Actions */}
        <div className="pt-6 b-brutal-t flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="px-5 py-2.5 b-brutal bg-muted-surface text-xs font-mono font-bold hover:text-foreground"
          >
            CANCEL
          </button>

          <button
            onClick={() => {
              terminalAudio.playClick(1100);
              onProceedToExecution(target);
            }}
            className="flex items-center space-x-2 px-6 py-3 bg-accent text-accent-foreground font-display font-black text-xs sm:text-sm tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all active:scale-[0.98]"
          >
            <ShieldCheck size={16} />
            <span>CONFIRM & OPEN PAPER EXECUTION</span>
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};
