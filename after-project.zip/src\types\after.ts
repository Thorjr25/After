export type EventCategory = 
  | 'EARNINGS' 
  | 'MACRO' 
  | 'SEC' 
  | 'GEOPOLITICAL' 
  | 'ANALYST' 
  | 'CORPORATE' 
  | 'TOKENIZED';

export interface MarketReference {
  symbol: string;
  name: string;
  type: 'FUTURES' | 'ETF' | 'SECTOR' | 'TOKENIZED' | 'CRYPTO';
  movePercent: number;
  description: string;
}

export interface AfterEvent {
  id: string;
  timestamp: number;
  timeStr: string;
  asset: string;
  assetName: string;
  category: EventCategory;
  headline: string;
  fullSummary: string;
  impact: number;        // 0-100
  surprise: number;      // 0-100
  relevance: number;     // 0-100
  confidence: number;    // 0-100
  status: 'NEW' | 'ANALYZED' | 'DISLOCATED' | 'PRICED_IN';
  whyMatters: string;
  sources: string[];
  sector: string;
  relatedAssets: string[];
  indexExposure: string[];
  tokenizedExposure?: string;
  expectedReaction?: ExpectedReaction;
}

export interface ExpectedReaction {
  direction: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  expectedMove: number; // e.g. +4.1 or -2.5
  expectedMoveRange: [number, number];
  confidence: number;
  rationale: string;
  references: MarketReference[];
  dislocation: {
    level: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';
    minPercent: number;
    maxPercent: number;
    summary: string;
  };
}

export interface Opportunity {
  id: string;
  rank: number;
  symbol: string;
  name: string;
  opportunityScore: number;
  expectedMove: number;
  currentImpliedMove: number;
  confidence: number;
  informationStrength: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  dislocationRange: string;
  whyTrade: string;
  invalidationTriggers: string[];
  eventId: string;
  primaryAction: 'LONG' | 'SHORT';
  currentPrice: number;
}

export interface Catalyst {
  id: string;
  timeStr: string;
  title: string;
  category: string;
  expectedImportance: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  affectedAssets: string[];
  status: 'UPCOMING' | 'IMMINENT' | 'COMPLETED';
  countdownMinutes: number;
  description: string;
}

export interface RiskCheck {
  name: string;
  status: 'PASSED' | 'BLOCKED' | 'WARNING';
  value: string;
  threshold: string;
  notes: string;
}

export interface RunStep {
  stepIndex: number;
  timeStr: string;
  title: string;
  detail: string;
  phase: 'INPUT' | 'INTERPRETATION' | 'ANALYSIS' | 'DECISION' | 'ACTION' | 'OUTCOME';
  metricHighlight?: string;
}

export interface RunRecord {
  id: string;
  timestamp: number;
  timeStr: string;
  trigger: 'BREAKING_INFO' | 'SCHEDULED_CATALYST' | 'OPPORTUNITY_SCAN' | 'MANUAL_ANALYSIS' | 'PAPER_EXECUTION';
  marketState: string;
  eventId: string;
  eventHeadline: string;
  primaryAsset: string;
  relatedAssets: string[];
  impactScore: number;
  surpriseScore: number;
  relevanceScore: number;
  confidenceScore: number;
  expectedMove: number;
  observedReferenceMove: number;
  currentImpliedMove: number;
  detectedDislocation: string;
  opportunityScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  riskChecks: RiskCheck[];
  riskStatus: 'PASSED' | 'BLOCKED';
  agentDecision: string;
  executionMode: 'PAPER';
  executionDetails: {
    action: 'LONG' | 'SHORT' | 'NO_ACTION';
    symbol: string;
    entryPrice: number;
    sizeUSD: number;
    stopLoss: number;
    takeProfit: number;
  };
  finalStatus: 'COMPLETED' | 'BLOCKED' | 'PENDING';
  outcome?: {
    postEventMove: number;
    pnlPercent: number;
    accuracy: 'CONFIRMED' | 'PARTIAL' | 'INVALIDATED';
    notes: string;
  };
  steps: RunStep[];
}
