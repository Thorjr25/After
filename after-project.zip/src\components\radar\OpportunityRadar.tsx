import React from 'react';
import { Opportunity } from '../../types/after';
import { Radar, HelpCircle, ShieldAlert, ArrowUpRight, TrendingUp, TrendingDown, Target } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';

interface OpportunityRadarProps {
  opportunities: Opportunity[];
  onOpenWhyTrade: (opp: Opportunity) => void;
  onOpenRiskGate: (opp: Opportunity) => void;
}

export const OpportunityRadar: React.FC<OpportunityRadarProps> = ({
  opportunities,
  onOpenWhyTrade,
  onOpenRiskGate,
}) => {
  return (
    <section id="opportunities" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Section Header */}
      <div className="mb-8 b-brutal bg-[#09090B] p-6 sm:p-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 b-brutal-b">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <Radar size={15} className="text-accent animate-spin" />
              <span>RADAR SCAN: ACTIVE</span>
              <span>/</span>
              <span className="text-accent font-bold">CROSS-MARKET ASYMMETRY DETECTED</span>
            </div>
            <h2 className="font-display font-black text-3xl sm:text-5xl text-foreground tracking-tighter uppercase">
              OPPORTUNITY RADAR
            </h2>
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono">
            <span className="px-3 py-1 b-brutal bg-muted-surface text-foreground font-bold">
              RANKED BY DISLOCATION ALPHA
            </span>
          </div>
        </div>

        <p className="pt-4 text-sm text-muted-foreground font-sans max-w-3xl">
          AFTER cross-references overnight AI fundamental shock forecasts against observed price changes in futures, 
          sector ETFs, Asian ADRs, and 24/7 tokenized equities to rank highest-conviction mispricings.
        </p>
      </div>

      {/* Stack of Opportunities with Giant Numbers */}
      <div className="space-y-6">
        {opportunities.map((opp) => {
          const isPositive = opp.expectedMove >= 0;

          return (
            <div
              key={opp.id}
              className="b-brutal bg-[#09090B] p-6 sm:p-8 hover:border-accent transition-all group"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                {/* Left: Giant Rank Number & Asset Identification */}
                <div className="flex items-start sm:items-center space-x-4 sm:space-x-8">
                  {/* Giant Rank Number */}
                  <span className="font-display font-black text-6xl sm:text-8xl text-accent tracking-tighter select-none leading-none w-20 sm:w-28 shrink-0">
                    0{opp.rank}
                  </span>

                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-2 font-mono text-xs">
                      <span className="px-2 py-0.5 bg-white text-black font-display font-black text-sm">
                        {opp.symbol}
                      </span>
                      <span className="text-foreground font-bold text-sm">{opp.name}</span>
                      <span className="text-[#3F3F46]">•</span>
                      <span className="text-muted-foreground font-mono">PRICE: ${opp.currentPrice.toFixed(2)}</span>
                      <span
                        className={`px-2 py-0.5 text-[10px] font-bold b-brutal ${
                          opp.riskLevel === 'LOW'
                            ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                            : opp.riskLevel === 'MEDIUM'
                            ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                            : 'bg-red-950/60 text-red-300 border-red-800'
                        }`}
                      >
                        {opp.riskLevel} RISK
                      </span>
                    </div>

                    <div className="flex items-center space-x-2 mt-1">
                      <span className="px-2 py-0.5 bg-accent text-accent-foreground font-display font-black text-xs tracking-wider">
                        SIGNAL: {opp.primaryAction}
                      </span>
                      <span className="text-xs font-mono text-muted-foreground">
                        GAP: <strong className="text-accent">{opp.dislocationRange}</strong>
                      </span>
                    </div>

                    <p className="mt-3 text-xs sm:text-sm text-muted-foreground font-sans line-clamp-2 max-w-2xl">
                      {opp.whyTrade}
                    </p>
                  </div>
                </div>

                {/* Right: Score Metrics & CTA Buttons */}
                <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 lg:gap-4 shrink-0 b-brutal-t lg:b-brutal-t-0 pt-4 lg:pt-0">
                  {/* Opportunity Score */}
                  <div className="p-3 b-brutal bg-accent text-accent-foreground text-center min-w-[90px]">
                    <span className="block text-[9px] font-mono uppercase font-bold">OPP SCORE</span>
                    <span className="font-display font-black text-3xl sm:text-4xl leading-none block mt-1">
                      {opp.opportunityScore}
                    </span>
                  </div>

                  {/* Expected Move */}
                  <div className="p-3 b-brutal bg-muted-surface text-center min-w-[100px]">
                    <span className="block text-[9px] font-mono text-muted-foreground uppercase">Expected Move</span>
                    <span
                      className={`font-display font-black text-2xl sm:text-3xl leading-none block mt-1 ${
                        isPositive ? 'text-accent' : 'text-red-400'
                      }`}
                    >
                      {opp.expectedMove >= 0 ? `+${opp.expectedMove}%` : `${opp.expectedMove}%`}
                    </span>
                  </div>

                  {/* Current Implied Move */}
                  <div className="p-3 b-brutal bg-muted-surface text-center min-w-[100px]">
                    <span className="block text-[9px] font-mono text-muted-foreground uppercase">Implied Move</span>
                    <span className="font-display font-black text-2xl sm:text-3xl text-foreground leading-none block mt-1">
                      {opp.currentImpliedMove >= 0 ? `+${opp.currentImpliedMove}%` : `${opp.currentImpliedMove}%`}
                    </span>
                  </div>

                  {/* Buttons */}
                  <div className="flex flex-col gap-2 w-full sm:w-auto">
                    <button
                      onClick={() => {
                        terminalAudio.playClick();
                        onOpenWhyTrade(opp);
                      }}
                      className="px-4 py-2 b-brutal bg-muted-surface text-foreground hover:bg-white hover:text-black transition-colors text-xs font-mono font-bold flex items-center justify-center space-x-1"
                    >
                      <HelpCircle size={13} />
                      <span>WHY THIS TRADE?</span>
                    </button>

                    <button
                      onClick={() => {
                        terminalAudio.playClick(1100);
                        onOpenRiskGate(opp);
                      }}
                      className="px-4 py-2 bg-accent text-accent-foreground b-brutal border-accent hover:bg-white hover:text-black transition-colors font-display font-black text-xs tracking-wider flex items-center justify-center space-x-1"
                    >
                      <ShieldAlert size={13} />
                      <span>RISK & EXECUTE</span>
                      <ArrowUpRight size={13} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
