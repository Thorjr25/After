import React from 'react';
import { X, ArrowUpRight, ArrowDownRight, ShieldCheck, AlertTriangle, ExternalLink, Zap, CheckCircle2 } from 'lucide-react';
import { AfterEvent } from '../../types/after';
import { terminalAudio } from '../../services/audioService';

interface EventDetailModalProps {
  event: AfterEvent | null;
  onClose: () => void;
  onExecuteTrade: (event: AfterEvent) => void;
}

export const EventDetailModal: React.FC<EventDetailModalProps> = ({
  event,
  onClose,
  onExecuteTrade,
}) => {
  if (!event) return null;

  const reaction = event.expectedReaction;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-none"
      onClick={() => {
        terminalAudio.playClick(600);
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto b-brutal bg-[#09090B] p-5 sm:p-8 text-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="flex items-start justify-between pb-4 b-brutal-b gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2 font-mono text-xs">
              <span className="px-2 py-0.5 b-brutal bg-muted-surface text-muted-foreground uppercase">
                {event.category}
              </span>
              <span className="text-muted-foreground">{event.timeStr}</span>
              <span className="text-[#3F3F46]">•</span>
              <span className="text-muted-foreground">EVENT ID: #{event.id}</span>
              {event.status === 'DISLOCATED' && (
                <span className="px-2 py-0.5 bg-accent text-accent-foreground font-black font-display text-[10px] tracking-wider">
                  PRICING GAP DETECTED
                </span>
              )}
            </div>
            <h2 className="font-display font-black text-xl sm:text-3xl tracking-tight leading-tight">
              {event.headline}
            </h2>
          </div>

          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="p-2 b-brutal bg-muted-surface hover:bg-accent hover:text-accent-foreground transition-colors shrink-0"
            aria-label="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* AI Scores Grid - Giant Numbers */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 py-6 b-brutal-b">
          <div className="p-3.5 b-brutal bg-muted-surface/40">
            <span className="block text-[11px] font-mono text-muted-foreground uppercase">Impact Score</span>
            <span className="font-display font-black text-3xl sm:text-4xl text-accent tracking-tighter block mt-0.5">
              {event.impact} <span className="text-sm text-muted-foreground font-mono">/ 100</span>
            </span>
            <span className="text-[10px] font-mono text-muted-foreground block mt-1">Fundamental deviation</span>
          </div>

          <div className="p-3.5 b-brutal bg-muted-surface/40">
            <span className="block text-[11px] font-mono text-muted-foreground uppercase">Surprise Score</span>
            <span className="font-display font-black text-3xl sm:text-4xl text-foreground tracking-tighter block mt-0.5">
              {event.surprise} <span className="text-sm text-muted-foreground font-mono">/ 100</span>
            </span>
            <span className="text-[10px] font-mono text-muted-foreground block mt-1">Consensus delta</span>
          </div>

          <div className="p-3.5 b-brutal bg-muted-surface/40">
            <span className="block text-[11px] font-mono text-muted-foreground uppercase">Relevance</span>
            <span className="font-display font-black text-3xl sm:text-4xl text-foreground tracking-tighter block mt-0.5">
              {event.relevance} <span className="text-sm text-muted-foreground font-mono">/ 100</span>
            </span>
            <span className="text-[10px] font-mono text-muted-foreground block mt-1">Entity exposure</span>
          </div>

          <div className="p-3.5 b-brutal bg-muted-surface/40">
            <span className="block text-[11px] font-mono text-muted-foreground uppercase">AI Confidence</span>
            <span className="font-display font-black text-3xl sm:text-4xl text-foreground tracking-tighter block mt-0.5">
              {event.confidence}%
            </span>
            <span className="text-[10px] font-mono text-muted-foreground block mt-1">Model consensus</span>
          </div>
        </div>

        {/* Asset Identification & Sector Mapping */}
        <div className="py-5 b-brutal-b grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div>
            <span className="text-muted-foreground block mb-1">PRIMARY ASSET IDENTIFIED:</span>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-1 bg-white text-black font-display font-black text-base">
                {event.asset}
              </span>
              <span className="text-foreground font-bold text-sm">{event.assetName}</span>
            </div>
            <span className="text-muted-foreground block mt-2">SECTOR: <strong className="text-foreground">{event.sector}</strong></span>
          </div>

          <div>
            <span className="text-muted-foreground block mb-1">CORRELATED EXPOSURES & INDICES:</span>
            <div className="flex flex-wrap gap-1.5 mt-1">
              {event.relatedAssets.map((rel) => (
                <span key={rel} className="px-2 py-0.5 b-brutal bg-muted-surface text-foreground font-bold">
                  {rel}
                </span>
              ))}
              {event.indexExposure.map((idx) => (
                <span key={idx} className="px-2 py-0.5 b-brutal bg-[#18181B] text-muted-foreground">
                  {idx}
                </span>
              ))}
            </div>
            {event.tokenizedExposure && (
              <div className="mt-2 text-accent">
                24/7 PERPETUAL: <strong>{event.tokenizedExposure}</strong>
              </div>
            )}
          </div>
        </div>

        {/* Why This Matters Explainer */}
        <div className="py-6 b-brutal-b">
          <div className="flex items-center space-x-2 mb-2 font-display font-black text-sm tracking-wider uppercase text-accent">
            <Zap size={16} />
            <span>WHY THIS MATTERS (AGENT INTELLIGENCE)</span>
          </div>
          <p className="text-sm sm:text-base text-foreground leading-relaxed font-sans font-normal bg-muted-surface/20 p-4 b-brutal">
            {event.whyMatters}
          </p>

          <div className="mt-4 text-xs font-mono text-muted-foreground">
            <span className="font-bold text-foreground block mb-1">VERIFIED SOURCES INGESTED:</span>
            <ul className="list-disc list-inside space-y-0.5">
              {event.sources.map((src, i) => (
                <li key={i}>{src}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Expected Reaction vs Relative Pricing Engine */}
        {reaction && (
          <div className="py-6 b-brutal-b">
            <div className="flex items-center justify-between mb-4">
              <span className="font-display font-black text-base tracking-wider uppercase text-foreground">
                EXPECTED REACTION VS MARKET PROXIES
              </span>
              <span className="text-xs font-mono text-accent font-bold">
                DIRECTION: {reaction.direction}
              </span>
            </div>

            {/* Main Reaction Box */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="p-4 b-brutal bg-muted-surface">
                <span className="text-[11px] font-mono text-muted-foreground uppercase block">Expected Reaction Move</span>
                <span className={`font-display font-black text-3xl sm:text-4xl block mt-1 ${
                  reaction.expectedMove >= 0 ? 'text-accent' : 'text-red-400'
                }`}>
                  {reaction.expectedMove >= 0 ? `+${reaction.expectedMove}%` : `${reaction.expectedMove}%`}
                </span>
                <span className="text-xs font-mono text-muted-foreground block mt-1">
                  Range: {reaction.expectedMoveRange[0]}% to {reaction.expectedMoveRange[1]}%
                </span>
              </div>

              <div className="p-4 b-brutal bg-muted-surface md:col-span-2">
                <span className="text-[11px] font-mono text-muted-foreground uppercase block">AI Forecasting Rationale</span>
                <p className="text-xs sm:text-sm text-foreground leading-relaxed mt-1 font-sans">
                  {reaction.rationale}
                </p>
              </div>
            </div>

            {/* Reference Market Breakdown Table */}
            <div className="b-brutal overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-muted-surface b-brutal-b text-muted-foreground">
                  <tr>
                    <th className="p-2.5">REFERENCE PROXY</th>
                    <th className="p-2.5">TYPE</th>
                    <th className="p-2.5">OVERNIGHT MOVE</th>
                    <th className="p-2.5 hidden sm:table-cell">OBSERVATION</th>
                  </tr>
                </thead>
                <tbody className="divide-y-2 divide-[#3F3F46]">
                  {reaction.references.map((ref, idx) => (
                    <tr key={idx} className="hover:bg-muted-surface/30">
                      <td className="p-2.5 font-bold text-foreground">{ref.symbol}</td>
                      <td className="p-2.5 text-muted-foreground">{ref.type}</td>
                      <td className={`p-2.5 font-black ${ref.movePercent >= 0 ? 'text-accent' : 'text-red-400'}`}>
                        {ref.movePercent >= 0 ? `+${ref.movePercent}%` : `${ref.movePercent}%`}
                      </td>
                      <td className="p-2.5 text-muted-foreground hidden sm:table-cell">{ref.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Dislocation Summary Banner */}
            <div className="mt-4 p-4 b-brutal bg-accent text-accent-foreground flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="font-mono font-bold text-[11px] uppercase tracking-wider block">
                  INFORMATION-PRICING GAP: {reaction.dislocation.level}
                </span>
                <p className="font-sans text-xs sm:text-sm font-semibold mt-0.5">
                  {reaction.dislocation.summary}
                </p>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[10px] font-mono uppercase block">Estimated Dislocation</span>
                <span className="font-display font-black text-xl">
                  +{reaction.dislocation.minPercent}% to +{reaction.dislocation.maxPercent}%
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Modal Bottom CTA Footer */}
        <div className="pt-6 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="px-5 py-3 b-brutal bg-muted-surface text-xs font-mono font-bold hover:text-foreground transition-colors"
          >
            RETURN TO FEED
          </button>

          <button
            onClick={() => {
              terminalAudio.playClick(1100);
              onExecuteTrade(event);
            }}
            className="flex items-center space-x-2 px-6 py-3 bg-accent text-accent-foreground font-display font-black text-xs sm:text-sm tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all active:scale-[0.98]"
          >
            <ShieldCheck size={16} />
            <span>RUN RISK CHECK & PAPER EXECUTION</span>
            <ArrowUpRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};
