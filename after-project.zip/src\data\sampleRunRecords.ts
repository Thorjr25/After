import { RunRecord } from '../types/after';

export const SAMPLE_RUN_RECORDS: RunRecord[] = [
  {
    id: 'AF-00291',
    timestamp: Date.now() - 1000 * 60 * 22,
    timeStr: '18:32:04 EST',
    trigger: 'BREAKING_INFO',
    marketState: 'US EQUITY MARKETS CLOSED / OVERNIGHT ELECTRONIC ACTIVE',
    eventId: 'evt-001',
    eventHeadline: 'Apple Q4 Services Revenue Beats by 14.2%; Greater China Margin Expands 210 bps',
    primaryAsset: 'AAPL',
    relatedAssets: ['QQQ', 'XLK', 'TSM', 'QCOM'],
    impactScore: 91,
    surpriseScore: 82,
    relevanceScore: 96,
    confidenceScore: 88,
    expectedMove: 4.1,
    observedReferenceMove: 1.1,
    currentImpliedMove: 0.8,
    detectedDislocation: '+0.6% to +0.9% (Fair Value Mispricing)',
    opportunityScore: 93,
    riskLevel: 'MEDIUM',
    riskStatus: 'PASSED',
    riskChecks: [
      { name: 'After-Hours Liquidity Depth', status: 'PASSED', value: '$42M Top 5 Levels', threshold: '>$15M', notes: 'Sufficient book depth on ECNs' },
      { name: 'AI Confidence Threshold', status: 'PASSED', value: '88%', threshold: '>=75%', notes: 'Multi-source model agreement' },
      { name: 'Expected Volatility Bound', status: 'PASSED', value: '1.4x 30d ATR', threshold: '<2.5x ATR', notes: 'Within normal post-earnings envelope' },
      { name: 'Information Conflict Check', status: 'PASSED', value: '0 Conflicting Sources', threshold: '0 Flags', notes: 'Unanimous reporting from SEC 8-K & IR' },
      { name: 'Reference Market Confirmation', status: 'PASSED', value: 'NQ1! +1.1% / XLK +0.8%', threshold: 'Same Sign Direction', notes: 'Broad tech proxies corroborating upward bias' },
      { name: 'Position Size Cap', status: 'PASSED', value: '$10,000 Paper Capital', threshold: '<=$25,000', notes: 'Within tier-1 capital allocation guidelines' },
      { name: 'Max Portfolio Overnight Exposure', status: 'PASSED', value: '14.2% Total Portfolio', threshold: '<=25.0%', notes: 'Risk capacity available' },
      { name: 'Hard Invalidation Stop Defined', status: 'PASSED', value: '$224.50 (-1.7%)', threshold: 'Stop Specified', notes: 'Structural stop below session VWAP' }
    ],
    agentDecision: 'EXECUTE PAPER LONG AAPL. Dislocation between confirmed fundamental beat and sluggish off-exchange book creates asymmetric expected positive drift into cash open.',
    executionMode: 'PAPER',
    executionDetails: {
      action: 'LONG',
      symbol: 'AAPL',
      entryPrice: 228.40,
      sizeUSD: 10000,
      stopLoss: 224.50,
      takeProfit: 237.75
    },
    finalStatus: 'COMPLETED',
    outcome: {
      postEventMove: 3.7,
      pnlPercent: 3.7,
      accuracy: 'CONFIRMED',
      notes: 'Cash market opened at $236.90 (+3.7% vs entry). Dislocation converged at 09:35 EST cash cross.'
    },
    steps: [
      {
        stepIndex: 1,
        timeStr: '18:32:04',
        title: 'INFORMATION RECEIVED',
        detail: 'Inbound SEC EDGAR Form 8-K ingested and parsed across 3 redundant crawler nodes in 210ms.',
        phase: 'INPUT',
        metricHighlight: 'SEC 8-K FILING #0000320193'
      },
      {
        stepIndex: 2,
        timeStr: '18:32:07',
        title: 'EVENT CLASSIFIED',
        detail: 'NLP categorization identified quarterly earnings release with anomalous revenue line item deviation in Services.',
        phase: 'INTERPRETATION',
        metricHighlight: 'CATEGORY: EARNINGS'
      },
      {
        stepIndex: 3,
        timeStr: '18:32:11',
        title: 'AAPL IDENTIFIED',
        detail: 'Primary entity mapped to Apple Inc. (AAPL.US). Secondary exposures linked: QQQ, XLK, TSM, ARM.',
        phase: 'INTERPRETATION',
        metricHighlight: 'PRIMARY: AAPL'
      },
      {
        stepIndex: 4,
        timeStr: '18:32:15',
        title: 'IMPACT SCORED',
        detail: 'Multi-factor information pricing model generated: Impact 91/100, Surprise 82/100, Relevance 96/100, Confidence 88%.',
        phase: 'ANALYSIS',
        metricHighlight: 'IMPACT: 91 / 100'
      },
      {
        stepIndex: 5,
        timeStr: '18:32:19',
        title: 'REFERENCE MARKET ANALYZED',
        detail: 'Evaluated E-mini Nasdaq futures (+1.1%), XLK ETF (+0.8%), and offshore tokenized perpetuals (+0.2%).',
        phase: 'ANALYSIS',
        metricHighlight: 'NQ FUTURES +1.1%'
      },
      {
        stepIndex: 6,
        timeStr: '18:32:23',
        title: 'MISPRICING DETECTED',
        detail: 'Expected move of +4.1% vs implied market move of +0.8% revealed high information dislocation of +0.6% to +0.9%.',
        phase: 'ANALYSIS',
        metricHighlight: 'DISLOCATION: HIGH'
      },
      {
        stepIndex: 7,
        timeStr: '18:32:25',
        title: 'RISK CHECK PASSED',
        detail: 'Evaluated 8 safety gates: Liquidity, Confidence, ATR Volatility, Source Conflict, Proxy Confirmation, Max Sizing all cleared.',
        phase: 'DECISION',
        metricHighlight: '8/8 CHECKS PASSED'
      },
      {
        stepIndex: 8,
        timeStr: '18:32:27',
        title: 'LONG SIGNAL GENERATED',
        detail: 'Synthesized Opportunity Rank #1 with overall Score 93/100. Signal dispatched to Paper Execution engine.',
        phase: 'DECISION',
        metricHighlight: 'OPPORTUNITY SCORE 93'
      },
      {
        stepIndex: 9,
        timeStr: '18:32:32',
        title: 'PAPER ORDER SUBMITTED',
        detail: 'Simulated market order dispatched: BUY 43.78 AAPL @ $228.40 ($10,000 notional). Defined hard stop at $224.50.',
        phase: 'ACTION',
        metricHighlight: 'ORDER #PAP-99420 SUBMITTED'
      },
      {
        stepIndex: 10,
        timeStr: '18:32:39',
        title: 'RUN COMPLETE',
        detail: 'Run Record serialized, cryptographic hash committed to audit ledger, telemetry broadcast to terminal radar.',
        phase: 'OUTCOME',
        metricHighlight: 'RUN #AF-00291 PERSISTED'
      }
    ]
  },
  {
    id: 'AF-00287',
    timestamp: Date.now() - 1000 * 60 * 95,
    timeStr: '17:19:12 EST',
    trigger: 'BREAKING_INFO',
    marketState: 'US EQUITY MARKETS CLOSED',
    eventId: 'evt-003',
    eventHeadline: 'Tier-1 Brokerage Cuts Tesla Q1 Delivery Target by 19%',
    primaryAsset: 'TSLA',
    relatedAssets: ['XLY', 'RIVN', 'LCID'],
    impactScore: 79,
    surpriseScore: 68,
    relevanceScore: 89,
    confidenceScore: 76,
    expectedMove: -3.8,
    observedReferenceMove: -0.6,
    currentImpliedMove: -0.9,
    detectedDislocation: '-0.5% to -0.8%',
    opportunityScore: 74,
    riskLevel: 'HIGH',
    riskStatus: 'PASSED',
    riskChecks: [
      { name: 'After-Hours Liquidity Depth', status: 'PASSED', value: '$18M Top 5 Levels', threshold: '>$15M', notes: 'Acceptable but wide spreads' },
      { name: 'AI Confidence Threshold', status: 'PASSED', value: '76%', threshold: '>=75%', notes: 'Borderline confidence' },
      { name: 'Expected Volatility Bound', status: 'WARNING', value: '2.3x 30d ATR', threshold: '<2.5x ATR', notes: 'Elevated intraday beta' },
      { name: 'Information Conflict Check', status: 'PASSED', value: '0 Contradictions', threshold: '0 Flags', notes: 'Single tier-1 research desk' },
      { name: 'Reference Market Confirmation', status: 'PASSED', value: 'European autos -1.8%', threshold: 'Same Sign Direction', notes: 'German auto basket confirming weakness' },
      { name: 'Position Size Cap', status: 'PASSED', value: '$5,000 Scaled Down', threshold: '<=$25,000', notes: 'Reduced size due to high risk' },
      { name: 'Max Portfolio Overnight Exposure', status: 'PASSED', value: '8.4%', threshold: '<=25.0%', notes: 'Adequate headroom' },
      { name: 'Hard Invalidation Stop Defined', status: 'PASSED', value: '$222.00 (+2.5%)', threshold: 'Stop Specified', notes: 'Tight stop against short squeeze risk' }
    ],
    agentDecision: 'EXECUTE REDUCED-SIZE PAPER SHORT TSLA ($5,000). Delivery cut fundamentals outweigh headline noise.',
    executionMode: 'PAPER',
    executionDetails: {
      action: 'SHORT',
      symbol: 'TSLA',
      entryPrice: 216.50,
      sizeUSD: 5000,
      stopLoss: 222.00,
      takeProfit: 208.20
    },
    finalStatus: 'COMPLETED',
    outcome: {
      postEventMove: -0.8,
      pnlPercent: 0.8,
      accuracy: 'PARTIAL',
      notes: 'Stock dropped -0.8% before overnight retail dip-buyers absorbed liquidity. Model expected -3.8%.'
    },
    steps: [
      { stepIndex: 1, timeStr: '17:19:12', title: 'INFORMATION RECEIVED', detail: 'Research note parsed from institutional aggregator.', phase: 'INPUT' },
      { stepIndex: 2, timeStr: '17:19:15', title: 'EVENT CLASSIFIED', detail: 'Analyst estimate revision on automotive deliveries.', phase: 'INTERPRETATION' },
      { stepIndex: 3, timeStr: '17:19:18', title: 'TSLA IDENTIFIED', detail: 'Primary asset mapped to Tesla, Inc.', phase: 'INTERPRETATION' },
      { stepIndex: 4, timeStr: '17:19:22', title: 'IMPACT SCORED', detail: 'Impact 79, Surprise 68, Confidence 76%.', phase: 'ANALYSIS' },
      { stepIndex: 5, timeStr: '17:19:26', title: 'REFERENCE MARKETS ANALYZED', detail: 'European autos down -1.8%, synthetic perpetual down -0.9%.', phase: 'ANALYSIS' },
      { stepIndex: 6, timeStr: '17:19:30', title: 'DISLOCATION DETECTED', detail: 'Identified downward lag of -0.5% to -0.8%.', phase: 'ANALYSIS' },
      { stepIndex: 7, timeStr: '17:19:33', title: 'RISK GATE EVALUATION', detail: 'Elevated volatility triggered 50% position scaling to $5,000.', phase: 'DECISION' },
      { stepIndex: 8, timeStr: '17:19:37', title: 'SHORT SIGNAL GENERATED', detail: 'Rank #3 Opportunity dispatched to paper desk.', phase: 'DECISION' },
      { stepIndex: 9, timeStr: '17:19:42', title: 'PAPER ORDER SUBMITTED', detail: 'SHORT 23.09 TSLA @ $216.50.', phase: 'ACTION' },
      { stepIndex: 10, timeStr: '17:19:48', title: 'RUN COMPLETE', detail: 'Lifecycle closed and persisted.', phase: 'OUTCOME' }
    ]
  },
  {
    id: 'AF-00284',
    timestamp: Date.now() - 1000 * 60 * 180,
    timeStr: '15:48:00 EST',
    trigger: 'OPPORTUNITY_SCAN',
    marketState: 'PRE-CLOSE AUCTION TRANSITION',
    eventId: 'evt-002',
    eventHeadline: 'NVIDIA Blackwell Yield Exceeds 92%; Competitor ASIC Program Delayed',
    primaryAsset: 'NVDA',
    relatedAssets: ['SMH', 'AMD', 'AVGO'],
    impactScore: 86,
    surpriseScore: 74,
    relevanceScore: 94,
    confidenceScore: 84,
    expectedMove: 3.4,
    observedReferenceMove: 1.6,
    currentImpliedMove: 1.1,
    detectedDislocation: '+0.4% to +0.7%',
    opportunityScore: 78,
    riskLevel: 'MEDIUM',
    riskStatus: 'PASSED',
    riskChecks: [
      { name: 'After-Hours Liquidity Depth', status: 'PASSED', value: '$84M Top 5 Levels', threshold: '>$15M', notes: 'Prime tier liquidity' },
      { name: 'AI Confidence Threshold', status: 'PASSED', value: '84%', threshold: '>=75%', notes: 'Strong semiconductor model confidence' },
      { name: 'Expected Volatility Bound', status: 'PASSED', value: '1.2x 30d ATR', threshold: '<2.5x ATR', notes: 'Orderly supply update' },
      { name: 'Information Conflict Check', status: 'PASSED', value: 'Consistent', threshold: '0 Flags', notes: 'Foundry reports aligned' },
      { name: 'Reference Market Confirmation', status: 'PASSED', value: 'SOXX +1.6%', threshold: 'Same Sign Direction', notes: 'Semiconductor ETF firm' },
      { name: 'Position Size Cap', status: 'PASSED', value: '$10,000', threshold: '<=$25,000', notes: 'Standard book allocation' },
      { name: 'Max Portfolio Overnight Exposure', status: 'PASSED', value: '12.0%', threshold: '<=25.0%', notes: 'Pass' },
      { name: 'Hard Invalidation Stop Defined', status: 'PASSED', value: '$139.80 (-1.6%)', threshold: 'Stop Specified', notes: 'Below intraday floor' }
    ],
    agentDecision: 'EXECUTE PAPER LONG NVDA. Structural supply validation removes ASIC substitution discount.',
    executionMode: 'PAPER',
    executionDetails: {
      action: 'LONG',
      symbol: 'NVDA',
      entryPrice: 142.15,
      sizeUSD: 10000,
      stopLoss: 139.80,
      takeProfit: 147.00
    },
    finalStatus: 'COMPLETED',
    outcome: {
      postEventMove: 3.1,
      pnlPercent: 3.1,
      accuracy: 'CONFIRMED',
      notes: 'TSMC Taipei session opened strongly, driving NVDA cash open to $146.50 (+3.1%).'
    },
    steps: [
      { stepIndex: 1, timeStr: '15:48:00', title: 'INFORMATION RECEIVED', detail: 'Taiwan supply chain intelligence feed parsed.', phase: 'INPUT' },
      { stepIndex: 2, timeStr: '15:48:04', title: 'EVENT CLASSIFIED', detail: 'Semiconductor hardware manufacturing yield report.', phase: 'INTERPRETATION' },
      { stepIndex: 3, timeStr: '15:48:08', title: 'NVDA IDENTIFIED', detail: 'NVIDIA mapped as principal beneficiary.', phase: 'INTERPRETATION' },
      { stepIndex: 4, timeStr: '15:48:12', title: 'IMPACT SCORED', detail: 'Impact 86, Confidence 84%.', phase: 'ANALYSIS' },
      { stepIndex: 5, timeStr: '15:48:16', title: 'REFERENCE MARKETS CHECKED', detail: 'SOXX semiconductor proxy checked at +1.6%.', phase: 'ANALYSIS' },
      { stepIndex: 6, timeStr: '15:48:20', title: 'DISLOCATION CONFIRMED', detail: '+0.4% to +0.7% spread between spot and fair value.', phase: 'ANALYSIS' },
      { stepIndex: 7, timeStr: '15:48:23', title: 'RISK GATE CLEARED', detail: 'All 8 risk constraints verified.', phase: 'DECISION' },
      { stepIndex: 8, timeStr: '15:48:26', title: 'SIGNAL EMISSION', detail: 'Dispatched Opportunity Score 78.', phase: 'DECISION' },
      { stepIndex: 9, timeStr: '15:48:30', title: 'PAPER TRADE DISPATCH', detail: 'BUY 70.35 NVDA @ $142.15 ($10,000).', phase: 'ACTION' },
      { stepIndex: 10, timeStr: '15:48:35', title: 'RECORD COMMITTED', detail: 'Run #AF-00284 stored.', phase: 'OUTCOME' }
    ]
  },
  {
    id: 'AF-00279',
    timestamp: Date.now() - 1000 * 60 * 320,
    timeStr: '13:20:15 EST',
    trigger: 'MANUAL_ANALYSIS',
    marketState: 'REGULAR HOURS CLOSE TRANSITION',
    eventId: 'evt-004',
    eventHeadline: 'Unverified Rumor Regarding Anti-Monopoly Investigation in Cloud Infrastructure',
    primaryAsset: 'AMZN',
    relatedAssets: ['MSFT', 'GOOGL'],
    impactScore: 65,
    surpriseScore: 84,
    relevanceScore: 72,
    confidenceScore: 48, // Below 75% threshold!
    expectedMove: -2.9,
    observedReferenceMove: -0.1,
    currentImpliedMove: 0.0,
    detectedDislocation: 'Unconfirmed',
    opportunityScore: 42,
    riskLevel: 'HIGH',
    riskStatus: 'BLOCKED',
    riskChecks: [
      { name: 'After-Hours Liquidity Depth', status: 'PASSED', value: '$31M', threshold: '>$15M', notes: 'Liquid' },
      { name: 'AI Confidence Threshold', status: 'BLOCKED', value: '48%', threshold: '>=75%', notes: 'CONFIDENCE TOO LOW (48% < 75%). Single anonymous social source.' },
      { name: 'Expected Volatility Bound', status: 'PASSED', value: '1.5x ATR', threshold: '<2.5x ATR', notes: 'Normal' },
      { name: 'Information Conflict Check', status: 'BLOCKED', value: 'Conflicting Retractions', threshold: '0 Flags', notes: 'DOJ spokesperson declined comment; source blog retracted post within 10 mins.' },
      { name: 'Reference Market Confirmation', status: 'BLOCKED', value: 'Cloud ETFs flat', threshold: 'Same Sign Direction', notes: 'Zero confirmation in IGV or SOFR markets.' },
      { name: 'Position Size Cap', status: 'PASSED', value: '$0', threshold: '<=$25,000', notes: 'N/A' },
      { name: 'Max Portfolio Overnight Exposure', status: 'PASSED', value: '0.0%', threshold: '<=25.0%', notes: 'N/A' },
      { name: 'Hard Invalidation Stop Defined', status: 'BLOCKED', value: 'Undefined', threshold: 'Stop Specified', notes: 'No valid structural level.' }
    ],
    agentDecision: 'BLOCKED BY RISK GATE. Confidence is below minimum threshold (48% vs 75% required) and reference markets are sending zero confirmation. Execution halted.',
    executionMode: 'PAPER',
    executionDetails: {
      action: 'NO_ACTION',
      symbol: 'AMZN',
      entryPrice: 188.20,
      sizeUSD: 0,
      stopLoss: 0,
      takeProfit: 0
    },
    finalStatus: 'BLOCKED',
    outcome: {
      postEventMove: 0.2,
      pnlPercent: 0.0,
      accuracy: 'CONFIRMED',
      notes: 'Rumor was officially debunked 45 minutes later. The risk gate successfully prevented a false short liquidation.'
    },
    steps: [
      { stepIndex: 1, timeStr: '13:20:15', title: 'INFORMATION RECEIVED', detail: 'Social media headline crawler triggered on regulatory leak keyword.', phase: 'INPUT' },
      { stepIndex: 2, timeStr: '13:20:18', title: 'EVENT CLASSIFIED', detail: 'Regulatory investigation rumor on cloud hosting.', phase: 'INTERPRETATION' },
      { stepIndex: 3, timeStr: '13:20:21', title: 'AMZN IDENTIFIED', detail: 'Target entity mapped.', phase: 'INTERPRETATION' },
      { stepIndex: 4, timeStr: '13:20:24', title: 'LOW CONFIDENCE DETECTED', detail: 'Model confidence evaluated at 48% due to unverified provenance.', phase: 'ANALYSIS' },
      { stepIndex: 5, timeStr: '13:20:27', title: 'REFERENCE MARKETS CHECKED', detail: 'Cloud proxies completely unresponsive.', phase: 'ANALYSIS' },
      { stepIndex: 6, timeStr: '13:20:30', title: 'RISK GATE TRIGGERED', detail: 'Confidence below 75% & conflict flags raised.', phase: 'DECISION' },
      { stepIndex: 7, timeStr: '13:20:33', title: 'ACTION BLOCKED', detail: 'Execution halted by safety policy rule #4.', phase: 'DECISION' },
      { stepIndex: 8, timeStr: '13:20:36', title: 'REPORT RECORDED', detail: 'Near-miss event recorded for audit ledger.', phase: 'OUTCOME' }
    ]
  }
];
