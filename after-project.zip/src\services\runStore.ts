import { SAMPLE_EVENTS, SAMPLE_OPPORTUNITIES } from '../data/sampleEvents';
import { SAMPLE_CATALYSTS } from '../data/sampleCatalysts';
import { SAMPLE_RUN_RECORDS } from '../data/sampleRunRecords';
import { AfterEvent, Opportunity, Catalyst, RunRecord } from '../types/after';

// Local storage key for persistent runs
const STORAGE_KEY = 'AFTER_RUN_RECORDS_V1';

class RunStore {
  private events: AfterEvent[] = [...SAMPLE_EVENTS];
  private opportunities: Opportunity[] = [...SAMPLE_OPPORTUNITIES];
  private catalysts: Catalyst[] = [...SAMPLE_CATALYSTS];
  private runRecords: RunRecord[] = [];
  private listeners: (() => void)[] = [];

  constructor() {
    this.initRecords();
  }

  private initRecords() {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        try {
          this.runRecords = JSON.parse(saved);
        } catch {
          this.runRecords = [...SAMPLE_RUN_RECORDS];
        }
      } else {
        this.runRecords = [...SAMPLE_RUN_RECORDS];
      }
    } else {
      this.runRecords = [...SAMPLE_RUN_RECORDS];
    }
  }

  private saveRecords() {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.runRecords));
      } catch {}
    }
    this.notify();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(l => l());
  }

  public getEvents(): AfterEvent[] {
    return this.events;
  }

  public getEventById(id: string): AfterEvent | undefined {
    return this.events.find(e => e.id === id);
  }

  public getOpportunities(): Opportunity[] {
    return this.opportunities;
  }

  public getOpportunityById(id: string): Opportunity | undefined {
    return this.opportunities.find(o => o.id === id);
  }

  public getCatalysts(): Catalyst[] {
    return this.catalysts;
  }

  public getRunRecords(): RunRecord[] {
    return this.runRecords;
  }

  public getRunById(id: string): RunRecord | undefined {
    return this.runRecords.find(r => r.id === id);
  }

  public addRunRecord(record: RunRecord) {
    this.runRecords = [record, ...this.runRecords];
    this.saveRecords();
  }

  public addEvent(event: AfterEvent) {
    this.events = [event, ...this.events];
    this.notify();
  }

  public resetToDefaults() {
    this.runRecords = [...SAMPLE_RUN_RECORDS];
    this.events = [...SAMPLE_EVENTS];
    this.saveRecords();
  }
}

export const runStore = new RunStore();
