import React, { useState } from 'react';
import { Send, Zap, Sparkles, Cpu } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';
import { AnalyzeEventPayload } from '../../services/aiService';

interface BreakingNewsInputProps {
  onAnalyze: (payload: AnalyzeEventPayload) => void;
  isRealAiActive: boolean;
}

export const BreakingNewsInput: React.FC<BreakingNewsInputProps> = ({
  onAnalyze,
  isRealAiActive,
}) => {
  const [headline, setHeadline] = useState('');
  const [summary, setSummary] = useState('');

  const samplePresets = [
    {
      title: 'AMZN Sovereign AI Deal',
      headline: 'Amazon Web Services Enters $14B Sovereign Cloud Partnership with Singapore & UAE',
      summary: 'Binding 10-year public sector compute contract guarantee. Enterprise operating margins modeled at 38% with zero capex dilution.',
      asset: 'AMZN',
      category: 'CORPORATE'
    },
    {
      title: 'TSMC 2nm Yield Surprise',
      headline: 'TSMC Commercial Pilot Yield for 2nm GAAFET Nodes Surpasses 72% Ahead of H2 Schedule',
      summary: 'Taiwan packaging report confirms accelerated wafer throughput. Lead customers Apple and Nvidia secure 85% of initial allocation.',
      asset: 'TSM',
      category: 'CORPORATE'
    },
    {
      title: 'Tesla Robotaxi Regulatory Leak',
      headline: 'California DMV Approves Commercial Driverless Fleet License for Tesla Autonomous Network',
      summary: 'Unscheduled state regulatory docket clears Cybercab commercial ridesharing in San Francisco and Los Angeles corridors.',
      asset: 'TSLA',
      category: 'SEC'
    },
    {
      title: 'Fed Emergency Facility',
      headline: 'Federal Reserve Announces Calibrated Standing Repo Facility Backstop for Primary Dealers',
      summary: 'Central bank liquidity window removes year-end collateral funding pressures across SOFR and Treasury markets.',
      asset: 'SPY',
      category: 'MACRO'
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!headline.trim()) return;
    terminalAudio.playClick(1100);
    onAnalyze({
      headline: headline.trim(),
      summary: summary.trim() || undefined,
      source: 'User Terminal Ingestion',
      category: 'BREAKING'
    });
  };

  const handleSelectPreset = (p: typeof samplePresets[0]) => {
    terminalAudio.playClick(900);
    setHeadline(p.headline);
    setSummary(p.summary);
    onAnalyze({
      headline: p.headline,
      summary: p.summary,
      primaryAssetHint: p.asset,
      category: p.category,
      source: 'Preset Ingestion'
    });
  };

  return (
    <div className="mb-8 b-brutal bg-[#09090B] p-6 sm:p-8 border-accent">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 b-brutal-b">
        <div className="flex items-center space-x-2">
          <div className="p-2 b-brutal bg-accent text-accent-foreground">
            <Cpu size={18} />
          </div>
          <div>
            <span className="text-[11px] font-mono text-accent font-bold uppercase block">
              REAL-TIME INGESTION DESK
            </span>
            <h3 className="font-display font-black text-xl sm:text-2xl text-foreground uppercase tracking-tight">
              ANALYZE CUSTOM BREAKING NEWS WITH LLM
            </h3>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className={`px-2.5 py-1 b-brutal font-black ${isRealAiActive ? 'bg-accent text-accent-foreground' : 'bg-muted-surface text-muted-foreground'}`}>
            {isRealAiActive ? 'REAL LLM ONLINE' : 'DEMO MODE'}
          </span>
        </div>
      </div>

      {/* Form Input */}
      <form onSubmit={handleSubmit} className="pt-5 space-y-4">
        <div>
          <label className="text-xs font-mono text-muted-foreground uppercase block mb-1 font-bold">
            ENTER BREAKING HEADLINE / SEC FILING / MACRO DEVELOPMENT:
          </label>
          <input
            type="text"
            value={headline}
            onChange={(e) => setHeadline(e.target.value)}
            placeholder="e.g. Meta Announces $25B Custom Silicon TPU Deployment with Broadcom..."
            className="w-full p-3 b-brutal bg-muted-surface text-foreground font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:border-accent"
          />
        </div>

        <div>
          <label className="text-xs font-mono text-muted-foreground uppercase block mb-1">
            OPTIONAL EVENT DETAILS / REVENUE NUMBERS / FILING EXCERPT:
          </label>
          <textarea
            rows={2}
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            placeholder="e.g. Q3 revenue beat consensus by 11%, gross margin expanded 180 bps, guidance raised..."
            className="w-full p-3 b-brutal bg-muted-surface text-foreground font-sans text-xs placeholder:text-muted-foreground focus:outline-none focus:border-accent resize-none"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          {/* Quick Preset Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono">
            <span className="text-muted-foreground mr-1 text-[11px] uppercase">TEST PRESETS:</span>
            {samplePresets.map((pr) => (
              <button
                key={pr.title}
                type="button"
                onClick={() => handleSelectPreset(pr)}
                className="px-2.5 py-1 b-brutal bg-muted-surface text-foreground hover:bg-white hover:text-black transition-colors text-[11px] font-bold"
              >
                {pr.title}
              </button>
            ))}
          </div>

          <button
            type="submit"
            disabled={!headline.trim()}
            className="flex items-center space-x-2 px-6 py-3 bg-accent text-accent-foreground font-display font-black text-xs sm:text-sm tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Zap size={15} />
            <span>ANALYZE WITH REAL AI</span>
            <Send size={14} />
          </button>
        </div>
      </form>
    </div>
  );
};
