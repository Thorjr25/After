import React, { useEffect, useState } from 'react';
import { Play, ArrowDownRight, Compass, ShieldCheck, Zap } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';

interface AfterHeroProps {
  onOpenTerminal: () => void;
  onOpenSampleRun: () => void;
  onOpenDemo: () => void;
}

export const AfterHero: React.FC<AfterHeroProps> = ({
  onOpenTerminal,
  onOpenSampleRun,
  onOpenDemo,
}) => {
  const [scrollY, setScrollY] = useState(0);
  const [liveSecs, setLiveSecs] = useState(42);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setLiveSecs((prev) => (prev >= 59 ? 0 : prev + 1));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Parallax calculations
  const heroScale = Math.max(0.85, 1 - scrollY * 0.0003);
  const bgTranslateY = scrollY * 0.25;
  const contentOpacity = Math.max(0, 1 - scrollY * 0.0018);

  return (
    <section className="relative min-h-[92vh] flex flex-col justify-between pt-12 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden b-brutal-b bg-[#09090B]">
      {/* Massive Background Poster Numerical / State Element (hidden from screen reader) */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 flex items-center justify-center select-none overflow-hidden"
        style={{
          transform: `translateY(${bgTranslateY}px)`,
          willChange: 'transform',
        }}
      >
        <div className="text-center">
          <div className="font-display font-black text-[18vw] leading-none text-[#18181B] tracking-tighter opacity-60">
            18:{liveSecs < 10 ? `0${liveSecs}` : liveSecs}
          </div>
          <div className="font-display font-bold text-[6vw] tracking-[0.2em] text-[#1D1D20] uppercase mt-[-2vw]">
            MARKET CLOSED
          </div>
        </div>
      </div>

      {/* Top Status Header */}
      <div className="relative z-10 max-w-7xl mx-auto w-full flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="flex items-center px-3 py-1 b-brutal bg-muted-surface text-xs font-mono font-bold text-foreground">
            <span className="w-2 h-2 bg-accent inline-block mr-2 animate-ping" />
            <span className="w-2 h-2 bg-accent inline-block mr-2" />
            AFTER-HOURS INTELLIGENCE // SYSTEM ONLINE
          </div>
          <div className="hidden md:flex items-center px-2 py-1 b-brutal bg-[#09090B] text-xs font-mono text-muted-foreground">
            LATENCY: <span className="text-foreground ml-1 font-bold">14ms</span>
          </div>
        </div>

        <div className="flex items-center space-x-4 text-xs font-mono text-muted-foreground">
          <span>MONITORING: <strong className="text-foreground">S&P 500 / NASDAQ / 24-7 PERPS</strong></span>
        </div>
      </div>

      {/* Main Kinetic Headline Block */}
      <div
        className="relative z-10 max-w-7xl mx-auto w-full my-auto pt-8 pb-12 transition-transform duration-75 ease-out"
        style={{
          transform: `scale(${heroScale})`,
          opacity: contentOpacity,
          willChange: 'transform, opacity',
        }}
      >
        <div className="space-y-0 sm:space-y-1">
          {/* First Line */}
          <div className="overflow-hidden">
            <h1 className="font-display font-black tracking-tighter text-foreground uppercase text-[clamp(2.8rem,9.5vw,9.5rem)] leading-[0.9]">
              THE MARKET
            </h1>
          </div>

          <div className="overflow-hidden">
            <h1 className="font-display font-black tracking-tighter text-foreground uppercase text-[clamp(2.8rem,9.5vw,9.5rem)] leading-[0.9]">
              CLOSES.
            </h1>
          </div>

          {/* Second Line: INFORMATION DOESN'T */}
          <div className="pt-2 sm:pt-4 flex flex-col sm:flex-row sm:items-center sm:space-x-4">
            <div className="inline-block bg-accent text-accent-foreground px-3 sm:px-6 py-1 sm:py-2 b-brutal border-accent">
              <span className="font-display font-black tracking-tighter uppercase text-[clamp(2.6rem,9.2vw,9.2rem)] leading-[0.9] block">
                INFORMATION
              </span>
            </div>
            <div className="mt-2 sm:mt-0">
              <span className="font-display font-black tracking-tighter text-foreground uppercase text-[clamp(2.6rem,9.2vw,9.2rem)] leading-[0.9] block">
                DOESN'T.
              </span>
            </div>
          </div>
        </div>

        {/* Editorial Subheadline & Concept */}
        <div className="mt-8 sm:mt-12 max-w-3xl">
          <p className="text-base sm:text-xl text-muted-foreground leading-relaxed font-sans font-normal">
            Traditional U.S. equities trade on rigid schedules. Global information, earnings, macro shocks, 
            and tokenized markets do not. <strong className="text-foreground font-semibold">AFTER</strong> continuously 
            prices overnight information, detects cross-market pricing gaps, performs automated risk gating, and surfaces 
            explainable opportunities before the opening bell.
          </p>
        </div>

        {/* Action Controls */}
        <div className="mt-10 flex flex-wrap items-center gap-4">
          <button
            onClick={() => {
              terminalAudio.playClick(1100);
              onOpenDemo();
            }}
            className="flex items-center space-x-3 px-6 sm:px-8 py-4 bg-accent text-accent-foreground font-display font-black text-sm sm:text-base tracking-wider b-brutal border-accent hover:bg-white hover:text-black transition-all active:scale-[0.98]"
          >
            <Play size={18} fill="currentColor" />
            <span>RUN AFTER (DEMO)</span>
          </button>

          <button
            onClick={() => {
              terminalAudio.playClick();
              onOpenTerminal();
            }}
            className="flex items-center space-x-2 px-6 sm:px-8 py-4 b-brutal bg-muted-surface text-foreground font-display font-bold text-sm sm:text-base tracking-wider hover:bg-white hover:text-black hover:border-white transition-all active:scale-[0.98]"
          >
            <Compass size={18} />
            <span>OPEN TERMINAL</span>
            <ArrowDownRight size={18} />
          </button>

          <button
            onClick={() => {
              terminalAudio.playClick();
              onOpenSampleRun();
            }}
            className="flex items-center space-x-2 px-5 py-4 b-brutal bg-transparent text-muted-foreground font-mono text-xs sm:text-sm tracking-wider hover:text-foreground hover:border-accent transition-all"
          >
            <ShieldCheck size={16} />
            <span>VIEW SAMPLE RUN (#AF-00291)</span>
          </button>
        </div>
      </div>

      {/* Bottom Telemetry Bar */}
      <div className="relative z-10 max-w-7xl mx-auto w-full pt-8 b-brutal-t grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
        <div>
          <span className="block text-[11px] font-mono text-muted-foreground uppercase">US Cash Market</span>
          <span className="font-display font-black text-xl sm:text-2xl text-foreground flex items-center mt-0.5">
            <span className="w-2 h-2 bg-red-500 mr-2" />
            CLOSED
          </span>
        </div>
        <div>
          <span className="block text-[11px] font-mono text-muted-foreground uppercase">Overnight Information Flow</span>
          <span className="font-display font-black text-xl sm:text-2xl text-accent flex items-center mt-0.5">
            <Zap size={18} className="mr-1.5" />
            ACTIVE (17 EVTS)
          </span>
        </div>
        <div>
          <span className="block text-[11px] font-mono text-muted-foreground uppercase">Pricing Gaps Detected</span>
          <span className="font-display font-black text-xl sm:text-2xl text-foreground mt-0.5 block">
            04 ASYMMETRIC
          </span>
        </div>
        <div>
          <span className="block text-[11px] font-mono text-muted-foreground uppercase">Execution Mode</span>
          <span className="font-display font-black text-xl sm:text-2xl text-foreground flex items-center mt-0.5">
            <span className="w-2 h-2 bg-accent mr-2" />
            PAPER AGENT
          </span>
        </div>
      </div>
    </section>
  );
};
