import React, { useState } from 'react';
import { Catalyst } from '../../types/after';
import { Calendar, Clock, AlertCircle, ArrowUpRight, Flame } from 'lucide-react';
import { terminalAudio } from '../../services/audioService';

interface CatalystCalendarProps {
  catalysts: Catalyst[];
  onSelectAsset?: (symbol: string) => void;
}

export const CatalystCalendar: React.FC<CatalystCalendarProps> = ({
  catalysts,
  onSelectAsset,
}) => {
  const [filterImportance, setFilterImportance] = useState<string>('ALL');

  const filtered =
    filterImportance === 'ALL'
      ? catalysts
      : catalysts.filter((c) => c.expectedImportance === filterImportance);

  return (
    <section id="catalysts" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Section Header */}
      <div className="mb-8 b-brutal bg-[#09090B] p-6 sm:p-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 b-brutal-b">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <Calendar size={15} className="text-accent" />
              <span>CHRONOLOGICAL OVERNIGHT SEQUENCE</span>
              <span>/</span>
              <span className="text-accent font-bold">ANTICIPATED SHOCK TIMELINE</span>
            </div>
            <h2 className="font-display font-black text-3xl sm:text-5xl text-foreground tracking-tighter uppercase">
              CATALYST CALENDAR
            </h2>
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono">
            {['ALL', 'CRITICAL', 'HIGH'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => {
                  terminalAudio.playClick(900);
                  setFilterImportance(lvl);
                }}
                className={`px-3 py-1.5 b-brutal uppercase font-bold transition-colors ${
                  filterImportance === lvl
                    ? 'bg-accent text-accent-foreground border-accent'
                    : 'bg-muted-surface text-muted-foreground hover:text-foreground'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        <p className="pt-4 text-sm text-muted-foreground font-sans max-w-3xl">
          Scheduled macroeconomic releases, central bank speaking engagements, foreign exchange auctions, 
          and foreign equity market openings occurring before the next 09:30 EST cash open.
        </p>
      </div>

      {/* Editorial Chronological Timeline */}
      <div className="space-y-4">
        {filtered.map((cat, idx) => {
          const isCritical = cat.expectedImportance === 'CRITICAL';
          const isImminent = cat.status === 'IMMINENT';

          return (
            <div
              key={cat.id}
              className={`b-brutal bg-[#09090B] p-5 sm:p-6 transition-all hover:bg-muted-surface/30 ${
                isImminent ? 'border-accent' : ''
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* Time & Countdown */}
                <div className="flex items-center space-x-4 sm:space-x-6 shrink-0">
                  <div className="p-3 b-brutal bg-muted-surface text-center min-w-[110px]">
                    <span className="font-display font-black text-xl sm:text-2xl text-foreground block">
                      {cat.timeStr.split(' ')[0]}
                    </span>
                    <span className="text-[10px] font-mono text-muted-foreground uppercase">
                      {cat.timeStr.split(' ')[1] || 'EST'}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center space-x-2 text-xs font-mono mb-1">
                      <span className="px-2 py-0.5 b-brutal bg-muted-surface text-[10px] font-bold text-muted-foreground uppercase">
                        {cat.category}
                      </span>
                      {isImminent && (
                        <span className="px-2 py-0.5 bg-accent text-accent-foreground font-black text-[10px] font-mono animate-pulse">
                          IMMINENT ({cat.countdownMinutes}M)
                        </span>
                      )}
                      {!isImminent && (
                        <span className="text-muted-foreground">T-{Math.floor(cat.countdownMinutes / 60)}h {cat.countdownMinutes % 60}m</span>
                      )}
                    </div>

                    <h3 className="font-display font-bold text-base sm:text-xl text-foreground">
                      {cat.title}
                    </h3>
                  </div>
                </div>

                {/* Affected Assets & Importance Badge */}
                <div className="flex flex-wrap items-center gap-3 shrink-0 lg:justify-end">
                  <div className="text-left lg:text-right">
                    <span className="text-[10px] font-mono text-muted-foreground uppercase block mb-1">
                      AFFECTED ASSETS & INDICES:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {cat.affectedAssets.map((sym) => (
                        <button
                          key={sym}
                          onClick={() => {
                            terminalAudio.playClick(1000);
                            onSelectAsset?.(sym);
                          }}
                          className="px-2 py-0.5 b-brutal bg-muted-surface text-xs font-mono font-bold text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                        >
                          {sym}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="p-2.5 b-brutal bg-muted-surface min-w-[90px] text-center">
                    <span className="text-[9px] font-mono text-muted-foreground uppercase block">
                      IMPACT
                    </span>
                    <span
                      className={`font-display font-black text-sm uppercase block mt-0.5 ${
                        isCritical ? 'text-accent' : 'text-foreground'
                      }`}
                    >
                      {cat.expectedImportance}
                    </span>
                  </div>
                </div>
              </div>

              {/* Description line */}
              <p className="mt-3 text-xs sm:text-sm text-muted-foreground font-sans pt-3 b-brutal-t">
                {cat.description}
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
};
