// Client-Side Service for communicating with Server-Side LLM Intelligence Engine

import { CompleteAfterAnalysisResult } from '../../server/ai/analyzer';

export interface SystemAiStatus {
  mode: 'REAL_AI' | 'DEMO';
  configured: boolean;
  provider: string;
  model: string;
  message: string;
}

export interface AnalyzeEventPayload {
  headline: string;
  summary?: string;
  source?: string;
  category?: string;
  primaryAssetHint?: string;
  currentPriceHint?: number;
}

class AiService {
  private status: SystemAiStatus = {
    mode: 'DEMO',
    configured: false,
    provider: 'gemini',
    model: 'gemini-2.5-flash',
    message: 'Checking system status...'
  };

  private listeners: ((status: SystemAiStatus) => void)[] = [];

  constructor() {
    this.refreshStatus();
  }

  public subscribe(listener: (status: SystemAiStatus) => void): () => void {
    this.listeners.push(listener);
    listener(this.status);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(l => l(this.status));
  }

  public async refreshStatus(): Promise<SystemAiStatus> {
    try {
      const resp = await fetch('/api/status');
      if (resp.ok) {
        const data = await resp.json();
        this.status = {
          mode: data.mode || 'DEMO',
          configured: Boolean(data.configured),
          provider: data.provider || 'gemini',
          model: data.model || 'gemini-2.5-flash',
          message: data.message || ''
        };
      }
    } catch {
      // Offline fallback
      this.status = {
        mode: 'DEMO',
        configured: false,
        provider: 'gemini',
        model: 'gemini-2.5-flash',
        message: 'Server unreachable. Running in offline demo mode.'
      };
    }
    this.notify();
    return this.status;
  }

  public getStatus(): SystemAiStatus {
    return this.status;
  }

  public async configureAi(config: { apiKey: string; provider?: string; model?: string }): Promise<{ success: boolean; configured: boolean; error?: string }> {
    try {
      const resp = await fetch('/api/configure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      const data = await resp.json();
      if (resp.ok && data.success) {
        await this.refreshStatus();
        return { success: true, configured: data.configured };
      }
      return { success: false, configured: false, error: data.error || 'Configuration failed' };
    } catch (err: unknown) {
      return { success: false, configured: false, error: (err as Error).message };
    }
  }

  public async analyzeEvent(payload: AnalyzeEventPayload): Promise<{
    success: boolean;
    data?: CompleteAfterAnalysisResult;
    error?: string;
  }> {
    try {
      const resp = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!resp.ok) {
        return {
          success: false,
          error: `Server responded with status ${resp.status}`
        };
      }

      const res = await resp.json();
      return res;
    } catch (err: unknown) {
      return {
        success: false,
        error: `AI ANALYSIS UNAVAILABLE: ${(err as Error).message}. Market data remains available, but no AI interpretation was generated.`
      };
    }
  }
}

export const aiService = new AiService();
