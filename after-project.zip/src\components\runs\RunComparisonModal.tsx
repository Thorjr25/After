import React, { useState } from 'react';
import { X, ArrowLeftRight, CheckCircle2, ShieldAlert } from 'lucide-react';
import { RunRecord } from '../../types/after';
import { terminalAudio } from '../../services/audioService';

interface RunComparisonModalProps {
  runs: RunRecord[];
  initialRunA?: RunRecord | null;
  onClose: () => void;
}

export const RunComparisonModal: React.FC<RunComparisonModalProps> = ({
  runs,
  initialRunA,
  onClose,
}) => {
  const [runAId, setRunAId] = useState<string>(initialRunA?.id || runs[0]?.id || '');
  const [runBId, setRunBId] = useState<string>(
    runs.find((r) => r.id !== runAId)?.id || runs[1]?.id || runs[0]?.id || ''
  );

  const runA = runs.find((r) => r.id === runAId) || runs[0];
  const runB = runs.find((r) => r.id === runBId) || runs[1] || runs[0];

  if (!runA || !runB) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85"
      onClick={() => {
        terminalAudio.playClick(600);
        onClose();
      }}
    >
      <div
        className="relative w-full max-w-5xl max-h-[92vh] overflow-y-auto b-brutal bg-[#09090B] p-6 sm:p-8 text-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-start justify-between pb-4 b-brutal-b gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-muted-foreground mb-1">
              <ArrowLeftRight size={14} className="text-accent" />
              <span>AGENT PERFORMANCE COMPARISON</span>
              <span>/</span>
              <span className="text-accent font-bold">CROSS-RUN FORECAST AUDIT</span>
            </div>
            <h2 className="font-display font-black text-2xl sm:text-3xl uppercase tracking-tight">
              RUN COMPARISON: #{runA.id} VS #{runB.id}
            </h2>
          </div>

          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="p-2 b-brutal bg-muted-surface hover:bg-accent hover:text-accent-foreground transition-colors shrink-0"
            aria-label="Close modal"
          >
            <X size={20} />
          </button>
        </div>

        {/* Selector Header Bar */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-6 b-brutal-b">
          <div>
            <label className="text-xs font-mono text-muted-foreground uppercase block mb-1">
              SELECT RUN A:
            </label>
            <select
              value={runAId}
              onChange={(e) => {
                terminalAudio.playClick();
                setRunAId(e.target.value);
              }}
              className="w-full p-2.5 b-brutal bg-muted-surface text-foreground font-mono text-xs font-bold focus:outline-none focus:border-accent"
            >
              {runs.map((r) => (
                <option key={r.id} value={r.id}>
                  #{r.id} — {r.primaryAsset} ({r.trigger})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-mono text-muted-foreground uppercase block mb-1">
              SELECT RUN B:
            </label>
            <select
              value={runBId}
              onChange={(e) => {
                terminalAudio.playClick();
                setRunBId(e.target.value);
              }}
              className="w-full p-2.5 b-brutal bg-muted-surface text-foreground font-mono text-xs font-bold focus:outline-none focus:border-accent"
            >
              {runs.map((r) => (
                <option key={r.id} value={r.id}>
                  #{r.id} — {r.primaryAsset} ({r.trigger})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Side-by-Side Comparison Table */}
        <div className="py-6 b-brutal-b overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-muted-surface b-brutal text-muted-foreground">
              <tr>
                <th className="p-3">METRIC / VECTOR</th>
                <th className="p-3 text-accent font-bold">RUN A: #{runA.id} ({runA.primaryAsset})</th>
                <th className="p-3 text-white font-bold">RUN B: #{runB.id} ({runB.primaryAsset})</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-[#3F3F46] b-brutal">
              <tr>
                <td className="p-3 text-muted-foreground font-bold">EVENT HEADLINE</td>
                <td className="p-3 text-foreground font-sans">{runA.eventHeadline}</td>
                <td className="p-3 text-foreground font-sans">{runB.eventHeadline}</td>
              </tr>
              <tr>
                <td className="p-3 text-muted-foreground font-bold">IMPACT / SURPRISE</td>
                <td className="p-3 text-accent font-black text-sm">
                  {runA.impactScore} / {runA.surpriseScore}
                </td>
                <td className="p-3 text-foreground font-black text-sm">
                  {runB.impactScore} / {runB.surpriseScore}
                </td>
              </tr>
              <tr>
                <td className="p-3 text-muted-foreground font-bold">AI CONFIDENCE</td>
                <td className="p-3 font-bold text-foreground">{runA.confidenceScore}%</td>
                <td className="p-3 font-bold text-foreground">{runB.confidenceScore}%</td>
              </tr>
              <tr>
                <td className="p-3 text-muted-foreground font-bold">OPPORTUNITY SCORE</td>
                <td className="p-3 font-black text-accent text-base">{runA.opportunityScore} / 100</td>
                <td className="p-3 font-black text-foreground text-base">{runB.opportunityScore} / 100</td>
              </tr>
              <tr>
                <td className="p-3 text-muted-foreground font-bold">EXPECTED MOVE</td>
                <td className="p-3 font-black text-accent text-base">
                  {runA.expectedMove >= 0 ? `+${runA.expectedMove}%` : `${runA.expectedMove}%`}
                </td>
                <td className="p-3 font-black text-foreground text-base">
                  {runB.expectedMove >= 0 ? `+${runB.expectedMove}%` : `${runB.expectedMove}%`}
                </td>
              </tr>
              <tr>
                <td className="p-3 text-muted-foreground font-bold">OBSERVED PROXY MOVE</td>
                <td className="p-3 text-muted-foreground">+{runA.observedReferenceMove}%</td>
                <td className="p-3 text-muted-foreground">{runB.observedReferenceMove}%</td>
              </tr>
              <tr>
                <td className="p-3 text-muted-foreground font-bold">RISK STATUS</td>
                <td className="p-3">
                  <span className={`px-2 py-0.5 font-bold ${runA.riskStatus === 'PASSED' ? 'bg-accent text-accent-foreground' : 'bg-red-500 text-white'}`}>
                    {runA.riskStatus}
                  </span>
                </td>
                <td className="p-3">
                  <span className={`px-2 py-0.5 font-bold ${runB.riskStatus === 'PASSED' ? 'bg-accent text-accent-foreground' : 'bg-red-500 text-white'}`}>
                    {runB.riskStatus}
                  </span>
                </td>
              </tr>
              <tr>
                <td className="p-3 text-muted-foreground font-bold">AGENT DECISION</td>
                <td className="p-3 text-xs text-foreground font-sans">{runA.agentDecision}</td>
                <td className="p-3 text-xs text-foreground font-sans">{runB.agentDecision}</td>
              </tr>
              <tr>
                <td className="p-3 text-muted-foreground font-bold">POST-EVENT ACCURACY</td>
                <td className="p-3 font-bold text-accent">
                  {runA.outcome?.accuracy || 'PENDING'} ({runA.outcome?.postEventMove ? `${runA.outcome.postEventMove}%` : 'N/A'})
                </td>
                <td className="p-3 font-bold text-foreground">
                  {runB.outcome?.accuracy || 'PENDING'} ({runB.outcome?.postEventMove ? `${runB.outcome.postEventMove}%` : 'N/A'})
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Close Button */}
        <div className="pt-6 flex justify-end">
          <button
            onClick={() => {
              terminalAudio.playClick(600);
              onClose();
            }}
            className="px-6 py-2.5 b-brutal bg-accent text-accent-foreground font-display font-bold text-xs tracking-wider hover:bg-white hover:text-black"
          >
            DONE COMPARING
          </button>
        </div>
      </div>
    </div>
  );
};
