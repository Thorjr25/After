import React from 'react';

interface MarqueeProps {
  speed?: 'fast' | 'slow';
  reverse?: boolean;
  className?: string;
  items: { label: string; value?: string; highlight?: boolean; type?: string }[];
}

export const KineticMarquee: React.FC<MarqueeProps> = ({
  speed = 'fast',
  reverse = false,
  className = '',
  items,
}) => {
  // Duplicate array 3 times for continuous seamless scrolling
  const duplicated = [...items, ...items, ...items, ...items];

  const durationClass = speed === 'fast' ? 'animate-marquee-fast' : 'animate-marquee-slow';

  return (
    <div
      className={`overflow-hidden whitespace-nowrap select-none b-brutal-y bg-[#09090B] relative py-2 ${className}`}
      style={{ willChange: 'transform' }}
    >
      <div
        className={`inline-flex items-center space-x-6 sm:space-x-8 ${durationClass} ${
          reverse ? 'direction-reverse' : ''
        } hover:[animation-play-state:paused]`}
      >
        {duplicated.map((item, idx) => (
          <div
            key={idx}
            className="inline-flex items-center space-x-2.5 text-xs sm:text-sm font-mono tracking-tight"
          >
            {item.type && (
              <span className="px-1.5 py-0.5 text-[10px] font-bold b-brutal bg-muted-surface text-muted-foreground uppercase">
                {item.type}
              </span>
            )}
            <span
              className={`font-bold ${
                item.highlight ? 'text-accent bg-black px-1.5 py-0.5' : 'text-foreground'
              }`}
            >
              {item.label}
            </span>
            {item.value && (
              <span
                className={`font-black ${
                  item.value.startsWith('+')
                    ? 'text-accent'
                    : item.value.startsWith('-')
                    ? 'text-red-400'
                    : 'text-muted-foreground'
                }`}
              >
                {item.value}
              </span>
            )}
            <span className="text-[#3F3F46] font-mono px-2">/</span>
          </div>
        ))}
      </div>
    </div>
  );
};
